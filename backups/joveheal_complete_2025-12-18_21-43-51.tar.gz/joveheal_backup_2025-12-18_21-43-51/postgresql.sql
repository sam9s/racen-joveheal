--
-- PostgreSQL database dump
--

\restrict vomfTflGBTsKDQrmq5ilv0FYtCcflWstoeSgd2qo7mDPwGZTC3K7GTdI0vHAMHf

-- Dumped from database version 16.11 (b740647)
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.response_feedback DROP CONSTRAINT IF EXISTS response_feedback_conversation_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_conversation_id_fkey;
ALTER TABLE IF EXISTS ONLY public.feedback DROP CONSTRAINT IF EXISTS feedback_message_id_fkey;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_session_id_fkey;
ALTER TABLE IF EXISTS ONLY public.conversation_summaries DROP CONSTRAINT IF EXISTS conversation_summaries_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.chat_sessions DROP CONSTRAINT IF EXISTS chat_sessions_user_id_fkey;
DROP INDEX IF EXISTS public.ix_user_accounts_external_id;
DROP INDEX IF EXISTS public.ix_user_accounts_email;
DROP INDEX IF EXISTS public.ix_user_accounts_channel;
DROP INDEX IF EXISTS public.ix_response_feedback_id;
DROP INDEX IF EXISTS public.ix_grest_products_sku;
DROP INDEX IF EXISTS public.ix_grest_products_name;
DROP INDEX IF EXISTS public.ix_grest_products_in_stock;
DROP INDEX IF EXISTS public.ix_grest_products_id;
DROP INDEX IF EXISTS public.ix_grest_products_category;
DROP INDEX IF EXISTS public.ix_conversations_timestamp;
DROP INDEX IF EXISTS public.ix_conversations_session_id;
DROP INDEX IF EXISTS public.ix_conversations_safety_flagged;
DROP INDEX IF EXISTS public.ix_conversations_id;
DROP INDEX IF EXISTS public.ix_chat_sessions_user_id;
DROP INDEX IF EXISTS public.ix_chat_sessions_session_id;
DROP INDEX IF EXISTS public.ix_chat_sessions_id;
DROP INDEX IF EXISTS public.ix_analytics_daily_id;
DROP INDEX IF EXISTS public.ix_analytics_daily_date;
DROP INDEX IF EXISTS public.idx_products_price;
DROP INDEX IF EXISTS public.idx_products_name;
DROP INDEX IF EXISTS public.idx_products_model;
DROP INDEX IF EXISTS public.idx_products_category;
DROP INDEX IF EXISTS public.idx_messages_conversation;
DROP INDEX IF EXISTS public.idx_conversations_user;
DROP INDEX IF EXISTS public.idx_conversations_session;
DROP INDEX IF EXISTS public.idx_conversation_summaries_user_id;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_accounts DROP CONSTRAINT IF EXISTS user_accounts_pkey;
ALTER TABLE IF EXISTS ONLY public.user_accounts DROP CONSTRAINT IF EXISTS uq_channel_external_id;
ALTER TABLE IF EXISTS ONLY public.response_feedback DROP CONSTRAINT IF EXISTS response_feedback_pkey;
ALTER TABLE IF EXISTS ONLY public.response_feedback DROP CONSTRAINT IF EXISTS response_feedback_conversation_id_key;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_pkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS ONLY public.grest_products DROP CONSTRAINT IF EXISTS grest_products_pkey;
ALTER TABLE IF EXISTS ONLY public.flagged_conversations DROP CONSTRAINT IF EXISTS flagged_conversations_pkey;
ALTER TABLE IF EXISTS ONLY public.feedback DROP CONSTRAINT IF EXISTS feedback_pkey;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_pkey;
ALTER TABLE IF EXISTS ONLY public.conversation_summaries DROP CONSTRAINT IF EXISTS conversation_summaries_user_id_key;
ALTER TABLE IF EXISTS ONLY public.conversation_summaries DROP CONSTRAINT IF EXISTS conversation_summaries_pkey;
ALTER TABLE IF EXISTS ONLY public.chat_sessions DROP CONSTRAINT IF EXISTS chat_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.analytics_daily DROP CONSTRAINT IF EXISTS analytics_daily_pkey;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_accounts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.response_feedback ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.products ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.messages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.grest_products ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.flagged_conversations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.feedback ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.conversations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.conversation_summaries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.chat_sessions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.analytics_daily ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.user_accounts_id_seq;
DROP TABLE IF EXISTS public.user_accounts;
DROP SEQUENCE IF EXISTS public.response_feedback_id_seq;
DROP TABLE IF EXISTS public.response_feedback;
DROP SEQUENCE IF EXISTS public.products_id_seq;
DROP TABLE IF EXISTS public.products;
DROP SEQUENCE IF EXISTS public.messages_id_seq;
DROP TABLE IF EXISTS public.messages;
DROP SEQUENCE IF EXISTS public.grest_products_id_seq;
DROP TABLE IF EXISTS public.grest_products;
DROP SEQUENCE IF EXISTS public.flagged_conversations_id_seq;
DROP TABLE IF EXISTS public.flagged_conversations;
DROP SEQUENCE IF EXISTS public.feedback_id_seq;
DROP TABLE IF EXISTS public.feedback;
DROP SEQUENCE IF EXISTS public.conversations_id_seq;
DROP TABLE IF EXISTS public.conversations;
DROP SEQUENCE IF EXISTS public.conversation_summaries_id_seq;
DROP TABLE IF EXISTS public.conversation_summaries;
DROP SEQUENCE IF EXISTS public.chat_sessions_id_seq;
DROP TABLE IF EXISTS public.chat_sessions;
DROP SEQUENCE IF EXISTS public.analytics_daily_id_seq;
DROP TABLE IF EXISTS public.analytics_daily;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: analytics_daily; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.analytics_daily (
    id integer NOT NULL,
    date timestamp without time zone,
    total_conversations integer,
    unique_sessions integer,
    safety_flags integer,
    avg_response_time_ms double precision,
    positive_feedback integer,
    negative_feedback integer
);


--
-- Name: analytics_daily_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.analytics_daily_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: analytics_daily_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.analytics_daily_id_seq OWNED BY public.analytics_daily.id;


--
-- Name: chat_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_sessions (
    id integer NOT NULL,
    session_id character varying(100) NOT NULL,
    created_at timestamp without time zone,
    last_activity timestamp without time zone,
    channel character varying(50),
    user_id integer
);


--
-- Name: chat_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chat_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: chat_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.chat_sessions_id_seq OWNED BY public.chat_sessions.id;


--
-- Name: conversation_summaries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversation_summaries (
    id integer NOT NULL,
    user_id integer NOT NULL,
    emotional_themes text,
    recommended_programs text,
    last_topics text,
    conversation_status text,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: conversation_summaries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.conversation_summaries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: conversation_summaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.conversation_summaries_id_seq OWNED BY public.conversation_summaries.id;


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversations (
    id integer NOT NULL,
    session_id character varying(100),
    "timestamp" timestamp without time zone,
    user_question text NOT NULL,
    bot_answer text NOT NULL,
    safety_flagged boolean,
    safety_category character varying(100),
    sources_used text,
    response_time_ms integer,
    user_id integer
);


--
-- Name: conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.conversations_id_seq OWNED BY public.conversations.id;


--
-- Name: feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback (
    id integer NOT NULL,
    message_id integer,
    session_id character varying(255),
    rating character varying(20),
    comment text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.feedback_id_seq OWNED BY public.feedback.id;


--
-- Name: flagged_conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flagged_conversations (
    id integer NOT NULL,
    session_id character varying(255),
    user_message text,
    flag_reason character varying(100),
    severity character varying(20),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: flagged_conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.flagged_conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: flagged_conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.flagged_conversations_id_seq OWNED BY public.flagged_conversations.id;


--
-- Name: grest_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grest_products (
    id integer NOT NULL,
    sku character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    category character varying(100) NOT NULL,
    variant character varying(255),
    storage character varying(50),
    color character varying(100),
    condition character varying(100),
    price numeric(10,2) NOT NULL,
    original_price numeric(10,2),
    discount_percent integer,
    in_stock boolean,
    warranty_months integer,
    product_url character varying(500),
    image_url character varying(500),
    description text,
    specifications text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: grest_products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.grest_products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: grest_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.grest_products_id_seq OWNED BY public.grest_products.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    conversation_id integer,
    role character varying(20) NOT NULL,
    content text NOT NULL,
    sources text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id integer NOT NULL,
    product_name character varying(255) NOT NULL,
    model character varying(100),
    storage character varying(50),
    condition character varying(50),
    color character varying(100),
    price_inr numeric(10,2) NOT NULL,
    mrp_inr numeric(10,2),
    product_url text,
    variant_id character varying(100),
    in_stock boolean DEFAULT true,
    last_updated timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: response_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.response_feedback (
    id integer NOT NULL,
    conversation_id integer,
    rating integer NOT NULL,
    comment text,
    created_at timestamp without time zone
);


--
-- Name: response_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.response_feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: response_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.response_feedback_id_seq OWNED BY public.response_feedback.id;


--
-- Name: user_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_accounts (
    id integer NOT NULL,
    channel character varying(50) NOT NULL,
    external_id character varying(255) NOT NULL,
    email character varying(255),
    display_name character varying(255),
    profile_image character varying(500),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_seen timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: user_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_accounts_id_seq OWNED BY public.user_accounts.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    name character varying(255),
    image text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: analytics_daily id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_daily ALTER COLUMN id SET DEFAULT nextval('public.analytics_daily_id_seq'::regclass);


--
-- Name: chat_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions ALTER COLUMN id SET DEFAULT nextval('public.chat_sessions_id_seq'::regclass);


--
-- Name: conversation_summaries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_summaries ALTER COLUMN id SET DEFAULT nextval('public.conversation_summaries_id_seq'::regclass);


--
-- Name: conversations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations ALTER COLUMN id SET DEFAULT nextval('public.conversations_id_seq'::regclass);


--
-- Name: feedback id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback ALTER COLUMN id SET DEFAULT nextval('public.feedback_id_seq'::regclass);


--
-- Name: flagged_conversations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flagged_conversations ALTER COLUMN id SET DEFAULT nextval('public.flagged_conversations_id_seq'::regclass);


--
-- Name: grest_products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grest_products ALTER COLUMN id SET DEFAULT nextval('public.grest_products_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: response_feedback id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.response_feedback ALTER COLUMN id SET DEFAULT nextval('public.response_feedback_id_seq'::regclass);


--
-- Name: user_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_accounts ALTER COLUMN id SET DEFAULT nextval('public.user_accounts_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: analytics_daily; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.analytics_daily (id, date, total_conversations, unique_sessions, safety_flags, avg_response_time_ms, positive_feedback, negative_feedback) FROM stdin;
\.


--
-- Data for Name: chat_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_sessions (id, session_id, created_at, last_activity, channel, user_id) FROM stdin;
1	4899da78-0435-4830-a33a-55b9a91f0241	2025-12-01 08:03:57.637656	2025-12-01 08:03:57.637661	web	\N
2	api_test_test123_20251201081612	2025-12-01 08:16:16.880357	2025-12-01 08:16:16.880368	api_test	\N
3	api_test_test_user_20251201082053	2025-12-01 08:21:00.398881	2025-12-01 08:21:09.236373	api_test	\N
4	410377dd-2d3b-48d6-9a91-6a40556b30a1	2025-12-01 08:27:59.115906	2025-12-01 08:27:59.115911	web	\N
36	widget_1765437473959_j1h9txyv1	2025-12-11 07:18:24.021006	2025-12-11 07:19:33.299518	web	\N
5	468c3529-639b-4bf7-8242-95aad6438b11	2025-12-01 09:33:55.215563	2025-12-01 09:43:39.896307	web	\N
6	302d0dfd-9320-4d5f-ad92-0f3a175d8c00	2025-12-01 09:58:15.534748	2025-12-01 09:58:54.132359	web	\N
7	568b4563-8ccf-4738-bca0-b09d0e1a3fd3	2025-12-01 10:05:37.356767	2025-12-01 10:07:46.648509	web	\N
8	eed23f1c-3d2e-4388-8078-a65d690c4f94	2025-12-01 10:24:47.581072	2025-12-01 10:24:47.581077	web	\N
9	860cab47-d476-44dc-af24-f3dda296dcc6	2025-12-01 11:03:38.128583	2025-12-01 11:03:38.128589	web	\N
10	7606ae71-395d-45d0-bafb-d5d39fc79661	2025-12-01 11:31:51.270514	2025-12-01 11:33:30.613827	web	\N
11	user_sammy_test	2025-12-04 05:57:18.117433	2025-12-04 05:57:21.517687	web	2
12	user_sammy_new_session	2025-12-04 05:57:48.317146	2025-12-04 05:57:50.712431	web	2
13	guest_1764828759834_sw15y6o92	2025-12-04 06:13:57.013803	2025-12-04 06:14:17.218976	web	\N
14	test_shed_shine	2025-12-04 06:22:56.980015	2025-12-04 06:23:00.363407	web	\N
15	user_sammy@test.com	2025-12-04 07:34:48.839801	2025-12-04 07:34:51.741275	web	2
16	user_newuser@example.com	2025-12-04 07:35:04.045349	2025-12-04 07:35:06.483148	web	3
73	guest_1765816735790_g0zx97uib	2025-12-15 16:39:04.031708	2025-12-15 16:39:07.192276	web	\N
17	guest_1764833832077_yp756jiqr	2025-12-04 07:37:21.212577	2025-12-04 07:37:42.348515	web	\N
37	guest_1765437466934_bpzixcb5n	2025-12-11 07:19:22.766306	2025-12-11 07:21:58.005284	web	\N
18	user_test@summary.com	2025-12-04 07:53:18.826703	2025-12-04 07:54:01.616512	web	4
19	user_test@summary.com_new_session	2025-12-04 07:54:27.424807	2025-12-04 07:54:31.946787	web	4
20	user_test@summary.com_session2	2025-12-04 07:55:25.912271	2025-12-04 07:55:29.529123	web	4
21	user_test@summary.com_session3	2025-12-04 07:56:18.275274	2025-12-04 07:56:21.78469	web	4
22	user_test@summary.com_session4	2025-12-04 07:57:19.242471	2025-12-04 07:57:22.235995	web	4
23	user_test@summary.com_session5	2025-12-04 07:58:06.508994	2025-12-04 07:58:10.860553	web	4
24	user_test@summary.com_session6	2025-12-04 07:59:12.626003	2025-12-04 07:59:17.282743	web	4
25	test_123	2025-12-04 11:25:34.165165	2025-12-04 11:25:34.16517	web	\N
26	test_456	2025-12-04 11:26:50.976058	2025-12-04 11:26:52.797945	web	\N
27	test_789	2025-12-04 11:27:02.814055	2025-12-04 11:27:05.509923	web	\N
38	guest_1765438454208_nejh7kjn5	2025-12-11 07:34:20.422211	2025-12-11 07:34:24.38333	web	\N
28	manychat_insta_12345	2025-12-10 03:41:57.097113	2025-12-10 03:43:51.374179	instagram	\N
29	manychat_test123	2025-12-10 04:11:15.374622	2025-12-10 04:11:16.940096	instagram	\N
30	widget_1765353094047_v5ueg562z	2025-12-10 07:52:00.907655	2025-12-10 07:52:06.180847	web	\N
31	widget_1765353332794_h56duugt7	2025-12-10 07:56:02.846998	2025-12-10 07:56:06.969576	web	\N
32	guest_1765360643640_nl7idovap	2025-12-10 09:57:49.577917	2025-12-10 09:57:52.663927	web	\N
33	guest_1765436537649_mp6r1efp3	2025-12-11 07:03:11.337986	2025-12-11 07:03:18.538454	web	\N
74	guest_1765817388046_28zpp9sh4	2025-12-15 16:49:53.196468	2025-12-15 16:49:56.77985	web	\N
34	guest_1765436789488_tqadnrc3c	2025-12-11 07:10:51.678354	2025-12-11 07:14:28.687653	web	\N
35	widget_1765437289627_ttdtyw4pj	2025-12-11 07:15:22.98306	2025-12-11 07:15:30.382417	web	\N
64	guest_1765533455804_7dcg8qc39	2025-12-12 09:57:43.583286	2025-12-12 09:58:15.272493	web	\N
53	stress_test_11	2025-12-11 10:15:06.655251	2025-12-11 10:29:56.374411	web	\N
51	stress_test_12	2025-12-11 10:15:06.47544	2025-12-11 10:29:59.327235	web	\N
39	guest_1765438484407_96s7qm87l	2025-12-11 07:34:48.20375	2025-12-11 07:37:56.618678	web	\N
52	stress_test_13	2025-12-11 10:15:06.579937	2025-12-11 10:30:00.139352	web	\N
54	stress_test_10	2025-12-11 10:15:06.92079	2025-12-11 10:30:00.432475	web	\N
50	stress_test_14	2025-12-11 10:15:06.466505	2025-12-11 10:30:00.90392	web	\N
68	guest_1765780284395_9dkpz2v4p	2025-12-15 06:32:03.417123	2025-12-15 06:32:59.817597	web	\N
69	guest_1765793928478_2684tvwzy	2025-12-15 10:19:41.276861	2025-12-15 10:19:48.534716	web	\N
65	guest_1765548645708_fhwunxsga	2025-12-12 14:11:41.557519	2025-12-12 14:17:01.088214	web	\N
56	stress_test_16	2025-12-11 10:15:23.690444	2025-12-11 10:30:07.260024	web	\N
59	stress_test_19	2025-12-11 10:15:24.200966	2025-12-11 10:30:08.998202	web	\N
70	guest_1765794197733_7y06zuc6d	2025-12-15 10:23:36.250316	2025-12-15 10:23:45.130609	web	\N
66	guest_1765603737321_wg66dx7ww	2025-12-13 05:29:29.60087	2025-12-13 05:32:47.027072	web	\N
55	stress_test_15	2025-12-11 10:15:23.372342	2025-12-11 10:30:09.151734	web	\N
42	stress_test_0	2025-12-11 10:14:38.756634	2025-12-11 10:29:36.414254	web	\N
40	stress_test_1	2025-12-11 10:14:38.754334	2025-12-11 10:29:39.523601	web	\N
44	stress_test_2	2025-12-11 10:14:38.755241	2025-12-11 10:29:40.836578	web	\N
41	stress_test_3	2025-12-11 10:14:38.756093	2025-12-11 10:29:40.895342	web	\N
43	stress_test_4	2025-12-11 10:14:38.753187	2025-12-11 10:29:40.999254	web	\N
57	stress_test_18	2025-12-11 10:15:23.749971	2025-12-11 10:30:12.046872	web	\N
58	stress_test_17	2025-12-11 10:15:24.003649	2025-12-11 10:30:13.203155	web	\N
60	guest_1765451865245_ikr5yipxx	2025-12-11 11:17:56.720125	2025-12-11 11:18:05.659976	web	\N
48	stress_test_5	2025-12-11 10:14:49.400872	2025-12-11 10:29:45.811209	web	\N
46	stress_test_7	2025-12-11 10:14:49.094651	2025-12-11 10:29:48.218762	web	\N
45	stress_test_6	2025-12-11 10:14:49.027902	2025-12-11 10:29:49.305248	web	\N
47	stress_test_9	2025-12-11 10:14:49.242444	2025-12-11 10:29:49.383688	web	\N
49	stress_test_8	2025-12-11 10:14:49.486074	2025-12-11 10:29:51.642289	web	\N
67	guest_1765604634749_atl3y5g12	2025-12-13 05:43:58.885541	2025-12-13 05:44:00.7381	web	\N
63	guest_1765532526825_0o345z1jq	2025-12-12 09:42:33.660191	2025-12-12 09:46:33.694243	web	\N
61	guest_1765521802876_1s9jl0uvd	2025-12-12 06:43:30.58465	2025-12-12 06:43:41.875754	web	\N
62	guest_1765521493208_968l2s3y4	2025-12-12 07:18:47.242867	2025-12-12 07:19:00.193809	web	\N
71	guest_1765796866310_ia3defcq8	2025-12-15 11:08:05.181932	2025-12-15 11:08:11.406028	web	\N
72	guest_1765813919562_20vt0n0ni	2025-12-15 16:14:25.142389	2025-12-15 16:14:30.480749	web	\N
76	guest_1765818660499_1mo3u98xn	2025-12-15 17:11:07.39298	2025-12-15 17:11:26.633645	web	\N
75	guest_1765817953721_mgdgetvkq	2025-12-15 16:59:21.863711	2025-12-15 16:59:48.706021	web	\N
79	guest_1765822839334_c8e1zqaxa	2025-12-15 18:20:48.71224	2025-12-15 18:37:55.219329	web	\N
78	guest_1765820803887_gpr7wcuqr	2025-12-15 17:46:53.527616	2025-12-15 17:48:41.764361	web	\N
77	guest_1765820352596_tuxh4x7ba	2025-12-15 17:39:20.922678	2025-12-15 17:39:51.833132	web	\N
80	guest_1765824912586_raryfoi3z	2025-12-15 18:55:21.176336	2025-12-15 18:55:43.052947	web	\N
81	test123	2025-12-15 18:58:33.340511	2025-12-18 20:06:17.402026	web	\N
82	guest_1765825622650_3ucc9mbjx	2025-12-15 19:07:24.227072	2025-12-15 19:07:44.620569	web	\N
83	debug_test_1765825820	2025-12-15 19:10:23.721513	2025-12-15 19:10:29.066147	web	\N
84	final_test_1765825978	2025-12-15 19:13:04.348379	2025-12-15 19:13:09.540972	web	\N
85	guest_1765826102529_dyhrrh2zo	2025-12-15 19:16:30.129303	2025-12-15 19:16:53.688354	web	\N
86	authority_test_1765826677	2025-12-15 19:24:43.870134	2025-12-15 19:24:48.747583	web	\N
87	guest_1765826834545_3yw36gift	2025-12-15 19:27:24.564347	2025-12-15 19:27:48.643788	web	\N
88	quick_test	2025-12-15 19:38:40.649008	2025-12-15 19:38:40.649012	web	\N
89	final_check	2025-12-15 19:39:14.189572	2025-12-15 19:39:18.023187	web	\N
90	guest_1765828544577_2djanmznz	2025-12-15 19:55:49.574685	2025-12-15 19:56:17.815315	web	\N
91	guest_1765857346414_q61wmlet3	2025-12-16 03:59:03.434381	2025-12-16 04:00:56.325565	web	\N
96	guest_1765994278475_vk06nl2p3	2025-12-17 17:58:35.382486	2025-12-17 18:04:10.980128	web	\N
97	guest_1766029537617_3x33dsr03	2025-12-18 03:46:02.101551	2025-12-18 03:46:15.528053	web	\N
98	price_test_1766033240	2025-12-18 04:47:26.555989	2025-12-18 04:47:44.017538	web	\N
99	price_test2	2025-12-18 04:47:58.926245	2025-12-18 04:48:15.681388	web	\N
100	hindi_test	2025-12-18 04:48:35.738158	2025-12-18 04:48:48.506345	web	\N
101	trust_test	2025-12-18 04:50:59.341099	2025-12-18 04:51:23.161492	web	\N
102	competitor_test	2025-12-18 04:51:43.445258	2025-12-18 04:51:49.066959	web	\N
103	final_warranty	2025-12-18 04:53:42.458656	2025-12-18 04:53:46.473965	web	\N
104	final_price	2025-12-18 04:54:02.271004	2025-12-18 04:54:09.398352	web	\N
105	spec_test	2025-12-18 05:05:18.677378	2025-12-18 05:05:25.570986	web	\N
106	specs_test	2025-12-18 12:40:40.187363	2025-12-18 12:40:46.591083	web	\N
107	compare_test	2025-12-18 12:41:01.304112	2025-12-18 12:41:10.562406	web	\N
108	specs_test2	2025-12-18 12:42:08.390285	2025-12-18 12:42:13.275337	web	\N
109	guest_1766073474797_kv9usdrdp	2025-12-18 15:58:09.455886	2025-12-18 15:58:25.07789	web	\N
110	guest_1766073447974_55bpcb5ov	2025-12-18 15:58:19.221047	2025-12-18 15:58:29.57953	web	\N
92	guest_1765858817878_fxk2jcg5t	2025-12-16 04:22:32.13137	2025-12-16 04:36:19.68873	web	\N
93	guest_1765868478331_3ftm9nfgx	2025-12-16 07:01:53.078862	2025-12-16 07:01:58.296489	web	\N
111	guest_1766074384821_zv1xzy396	2025-12-18 16:16:52.990692	2025-12-18 16:17:10.277972	web	\N
94	guest_1765880230771_wqwf9z26g	2025-12-16 10:17:44.13186	2025-12-16 10:18:22.838518	web	\N
112	guest_1766076411960_ztqpofiqs	2025-12-18 16:46:58.663864	2025-12-18 16:51:17.254275	web	\N
113	guest_1766076987507_46oar2tvx	2025-12-18 16:56:32.181396	2025-12-18 16:56:34.745801	web	\N
114	guest_1766088387693_e2w998unt	2025-12-18 20:06:40.845106	2025-12-18 20:06:42.573446	web	\N
115	guest_1766089140079_k8r2fcomp	2025-12-18 20:19:03.225265	2025-12-18 20:19:04.755594	web	\N
116	guest_1766089379910_j5v5a0qhs	2025-12-18 20:23:02.712041	2025-12-18 20:23:04.577748	web	\N
117	guest_1766089922150_xk410c207	2025-12-18 20:32:26.29085	2025-12-18 20:36:45.92061	web	\N
118	guest_1766091230108_sso302sg2	2025-12-18 20:54:19.623475	2025-12-18 20:54:22.320957	web	\N
95	guest_1765880806658_v4bmv3779	2025-12-16 10:27:02.744573	2025-12-16 10:37:40.728526	web	\N
\.


--
-- Data for Name: conversation_summaries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversation_summaries (id, user_id, emotional_themes, recommended_programs, last_topics, conversation_status, updated_at) FROM stdin;
1	4	["feeling disconnected from society", "stressed about career"]	["Beyond the Hustle"]	The user greeted the assistant multiple times, and the assistant acknowledged the user's previous feelings of disconnection and stress while suggesting a program for further exploration.	"exploring programs"	2025-12-04 07:59:19.244676
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversations (id, session_id, "timestamp", user_question, bot_answer, safety_flagged, safety_category, sources_used, response_time_ms, user_id) FROM stdin;
1	4899da78-0435-4830-a33a-55b9a91f0241	2025-12-01 08:03:57.409036	What services does JoveHeal offer?	JoveHeal offers a variety of wellness coaching services aimed at personal transformation and holistic well-being. Here are the main services we provide:\n\n1. **Balance Mastery+ Program**: \n   - A signature coaching experience designed to help you develop clarity about life goals, build sustainable routines, and master your mindset.\n\n2. **Inner Mastery Lounge**:\n   - An exclusive membership community that includes weekly group coaching sessions, access to guided meditations and exercises, community support, and monthly masterclasses on personal development.\n\n3. **Healing Sessions**:\n   - Available in both individual and group formats, these sessions focus on energy alignment, stress relief, emotional release, and mindfulness practices.\n\n4. **Workshops**:\n   - Regular workshops on topics like goal setting, mindset transformation, stress management, and confidence building, available both in-person and online.\n\nFeel free to reach out if you have more specific questions about any of these services!	f	\N	["joveheal_sample.txt"]	\N	\N
2	api_test_test123_20251201081612	2025-12-01 08:16:15.749417	What programs does JoveHeal offer?	JoveHeal offers several programs and services, including:\n\n1. **Balance Mastery+ Program**: This is the signature coaching experience designed to help individuals develop clarity about their life goals, build sustainable daily routines, master their mindset, create work-life balance, and develop confidence and self-leadership skills. The program typically runs for 8-12 weeks.\n\n2. **Inner Mastery Lounge**: This is an exclusive membership community that includes weekly group coaching sessions, access to guided meditations and exercises, community support, monthly masterclasses on personal development topics, and exclusive resources for members.\n\nAdditionally, JoveHeal offers individual and group healing sessions focused on energy alignment, stress relief, emotional release, and mindfulness practices. Regular workshops on topics such as goal setting, mindset transformation, and self-care are also available.\n\nFor more information about joining any of these programs, you can visit their website at www.joveheal.com.	f	\N	["joveheal_sample.txt"]	\N	\N
3	api_test_test_user_20251201082053	2025-12-01 08:20:57.046012	What is Balance Mastery?	The Balance Mastery+ program is JoveHeal's signature coaching experience designed to help individuals achieve personal transformation and clarity. This program focuses on several key areas, including:\n\n- Developing clarity about your life goals and direction\n- Building sustainable daily routines for success\n- Mastering your mindset and overcoming limiting beliefs\n- Creating a work-life balance that truly works\n- Developing confidence and self-leadership skills\n\nThe program typically runs for 8-12 weeks and provides personalized guidance and support to help participants unlock their potential and create lasting positive change in their lives. If you're interested in this program, I recommend visiting the JoveHeal website for more details.	f	\N	["joveheal_sample.txt"]	\N	\N
4	api_test_test_user_20251201082053	2025-12-01 08:21:09.043818	What is Balance Mastery?	The Balance Mastery+ program is JoveHeal's signature coaching experience aimed at helping individuals achieve personal transformation and clarity. Key focuses of this program include:\n\n- Developing clarity about life goals and direction\n- Building sustainable daily routines for success\n- Mastering mindset and overcoming limiting beliefs\n- Creating effective work-life balance\n- Developing confidence and self-leadership skills\n\nTypically, the program runs for 8-12 weeks and offers personalized guidance and support. For more information, you can check the JoveHeal website.	f	\N	["joveheal_sample.txt"]	\N	\N
5	410377dd-2d3b-48d6-9a91-6a40556b30a1	2025-12-01 08:27:58.896119	What programs does JoveHeal offer?	JoveHeal offers several programs focused on wellness coaching and personal transformation:\n\n1. **Balance Mastery+ Program**: This is our signature coaching experience designed to help you:\n   - Develop clarity about your life goals and direction\n   - Build sustainable daily routines for success\n   - Master your mindset and overcome limiting beliefs\n   - Create work-life balance that actually works\n   - Develop confidence and self-leadership skills\n\n2. **Inner Mastery Lounge**: This is an exclusive membership community that includes:\n   - Weekly group coaching sessions\n   - Access to guided meditations and exercises\n   - Community support and networking\n   - Monthly masterclasses on personal development topics\n   - Exclusive resources and tools for members\n\nWe also offer healing sessions, both individual and group, focusing on energy alignment, stress relief, and mindfulness practices.\n\nIf you have more specific questions about these programs or how to get started, feel free to ask!	f	\N	["joveheal_sample.txt"]	\N	\N
6	468c3529-639b-4bf7-8242-95aad6438b11	2025-12-01 09:33:54.99065	hi what programms yo uoffer?	At JoveHeal, we offer several programs designed to support your wellness journey:\n\n1. **Balance Mastery+ Program**: This is our signature coaching experience that helps you:\n   - Develop clarity about your life goals and direction\n   - Build sustainable daily routines for success\n   - Master your mindset and overcome limiting beliefs\n   - Create work-life balance that actually works\n   - Develop confidence and self-leadership skills\n\n2. **Inner Mastery Lounge**: This is our exclusive membership community that includes:\n   - Weekly group coaching sessions\n   - Access to guided meditations and exercises\n   - Community support and networking\n   - Monthly masterclasses on personal development topics\n   - Exclusive resources and tools for members\n\nAdditionally, we offer individual and group healing sessions focused on energy alignment, stress relief, emotional clarity, and mindfulness practices.\n\nIf you would like more details about a specific program, feel free to ask!	f	\N	["joveheal_sample.txt"]	\N	\N
7	468c3529-639b-4bf7-8242-95aad6438b11	2025-12-01 09:36:53.714989	can you tell me how do I increase my confidence?	While I can't provide specific advice, I can share general concepts that might be helpful in boosting confidence. \n\nParticipating in workshops, such as our **Confidence and Self-Leadership** workshop at JoveHeal, can provide valuable strategies and insights for building self-confidence. Additionally, consistent practice of setting and achieving small goals can help create a sense of accomplishment.\n\nJoining a supportive community, like the **Inner Mastery Lounge**, can offer encouragement and shared experiences that foster confidence. Engaging in regular self-reflection and mindfulness practices may also contribute to a stronger sense of self-worth.\n\nIf you’re interested in exploring these options as a way to build your confidence, feel free to ask about our programs or workshops!	f	\N	["joveheal_sample.txt"]	\N	\N
8	468c3529-639b-4bf7-8242-95aad6438b11	2025-12-01 09:37:37.446233	what program do you offer specifically for this purpose?	For building confidence, the **Balance Mastery+ Program** includes components that focus on developing confidence and self-leadership skills. This program guides you in mastering your mindset and overcoming limiting beliefs, which are crucial for increasing self-confidence.\n\nAdditionally, our **Confidence and Self-Leadership** workshop specifically targets skills and strategies to enhance your confidence. Participating in this workshop can provide practical tools and insights to help you on your confidence journey.\n\nIf you’d like more information on how to join these programs, just let me know!	f	\N	["joveheal_sample.txt"]	\N	\N
9	468c3529-639b-4bf7-8242-95aad6438b11	2025-12-01 09:43:36.96863	do you offer relationship healing ... if yes share details?	Currently, JoveHeal focuses on wellness coaching and healing sessions that primarily include energy alignment, stress relief, emotional clarity, and mindfulness practices. While our services can support personal growth and emotional wellness, we do not specifically offer relationship healing programs.\n\nIf you're interested in personal development or healing, our individual and group healing sessions may provide benefits that can contribute to overall emotional well-being. Feel free to explore our programs or ask about any other topics that may interest you!	f	\N	["joveheal_sample.txt"]	\N	\N
10	302d0dfd-9320-4d5f-ad92-0f3a175d8c00	2025-12-01 09:58:15.305637	What is relationship healing?	Relationship Healing at JoveHeal is a 3-hour deep healing session designed for individuals, particularly women, who seek to enhance intimacy and fulfillment in their relationships. It goes beyond surface-level solutions, focusing on root-level healing to dissolve old wounds and facilitate real transformation.\n\nKey components of Relationship Healing include:\n\n- **Guided Wound Release:** This helps to dissolve emotional pain associated with past experiences.\n- **The Mirror Principle:** This technique transforms relationship triggers into deeper connections.\n- **The 5 Core Wounds Map:** This tool enables participants to understand recurring patterns in their relationships and learn how to overcome them.\n\nThis healing space aims to help you turn conflicts into opportunities for deeper connection, rebuild trust, and reconnect with yourself, allowing you to show up with love and clarity in all your relationships. \n\nIf you're interested or have more questions, feel free to ask!	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt"]	\N	\N
11	302d0dfd-9320-4d5f-ad92-0f3a175d8c00	2025-12-01 09:58:53.933678	Tell me about Balance Mastery	Balance Mastery is a signature 3-month program at JoveHeal specifically designed for high-performing leaders who are seeking to restore balance in their lives. This program is aimed at those who may feel successful externally but are experiencing internal stress and misalignment.\n\nKey features of the Balance Mastery program include:\n\n- **Premium One-on-One Coaching:** You will have personalized sessions where you can uncover root causes, clear emotional and energetic blocks, and realign your inner landscape for a more harmonious outer life.\n- **Deep Root Healing:** This component helps you to identify and release limiting patterns.\n- **Blueprint Shift Work:** A focus on creating lasting transformation.\n- **Tools and Practices for Sustainable Change:** You will receive methodologies to support ongoing growth and balance.\n- **Personalized Support:** Throughout your journey, you will have access to dedicated support to help you achieve your goals.\n\nThis program is ideal for high-achieving professionals who want to deepen their relationships, lead with impact, and live with inner peace while overcoming the feelings of disconnection that often accompany success.\n\nIf you'd like more information or have specific questions about the program, feel free to ask!	f	\N	["website_services.txt", "website_balance_mastery.txt", "joveheal_sample.txt"]	\N	\N
12	568b4563-8ccf-4738-bca0-b09d0e1a3fd3	2025-12-01 10:05:37.137451	do you offer relationship healing ... if yes share details?	Yes, JoveHeal offers a Relationship Healing session designed for individuals seeking to enhance intimacy and fulfillment in their relationships. \n\n**Details of the Relationship Healing session:**\n- **Duration:** 3 hours\n- **Focus:** This deep healing session goes beyond quick fixes, guiding you into root-level healing where old wounds can dissolve and true transformation occurs.\n- **Key Components:**\n  - **Guided Wound Release:** Helps dissolve emotional pain.\n  - **The Mirror Principle:** Teaches how to transform relationship triggers into deeper connections.\n  - **The 5 Core Wounds Map:** Aids in understanding why patterns repeat in relationships and how to stop them.\n\nThis session is an opportunity to heal wounds that impact all your relationships, allowing you to show up with love and clarity.\n\nIf you have any more questions or need further information, feel free to ask!	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt", "website_balance_mastery.txt"]	\N	\N
13	568b4563-8ccf-4738-bca0-b09d0e1a3fd3	2025-12-01 10:07:43.746671	thank you .. ok my issue is I feel sad disconnected, weighed down, whats the best program do you offer for this ?	For feelings of sadness, disconnection, and being weighed down, the **Inner Reset** course would be a great fit for you. \n\n**Details about the Inner Reset:**\n- **Focus:** This self-paced healing course is designed for high-performing individuals who feel soul-tired, disconnected, or burdened by emotions that rest and busyness can't seem to fix.\n- **Key Features:**\n  - Guides you through powerful practices such as inner child healing, emotional release, energetic clearing, and self-love activation.\n  - Allows you to move through the material at your own rhythm, providing lifetime access so you can revisit the process whenever needed.\n\nThis course invites you to pause and reconnect with who you truly are, beneath the pressures and survival patterns. \n\nIf this sounds like a good fit for you or if you have any other questions, feel free to ask!	f	\N	["website_elevate360.txt", "website_inner_mastery_lounge.txt", "website_services.txt"]	\N	\N
14	eed23f1c-3d2e-4388-8078-a65d690c4f94	2025-12-01 10:24:47.233988	any membership you provide?	Yes, JoveHeal offers the **Inner Mastery Lounge**, which is our exclusive membership community. Membership includes the following benefits:\n\n- Weekly group coaching sessions\n- Access to guided meditations and exercises\n- Community support and networking\n- Monthly masterclasses on personal development topics\n- Exclusive resources and tools for members\n\nMembers also have access to all recorded sessions, allowing for a comprehensive experience in a supportive community of like-minded individuals. If you're interested in joining, please visit our website for more details!	f	\N	["joveheal_sample.txt", "website_elevate360.txt", "website_balance_mastery.txt"]	\N	\N
15	860cab47-d476-44dc-af24-f3dda296dcc6	2025-12-01 11:03:37.905214	Who is the coach behind JoveHeal and what is their background?	The coach behind JoveHeal has over 20 years of experience in corporate leadership, specializing in Agile transformation and executive delivery. They went through a profound healing journey that reshaped their approach to coaching. Traditionally focused on strategy, this coach realized that emotional and energetic healing is essential for true transformation. \n\nTheir work now emphasizes guiding high-achieving executives and entrepreneurs to uncover and clear emotional patterns that may lead to burnout and decision fatigue, helping them lead from a place of wholeness. This unique blend of coaching integrates modern techniques with holistic wellness principles to foster profound personal transformation. \n\nIf you have any more questions about JoveHeal's services or programs, feel free to ask!	f	\N	["website_homepage.txt", "joveheal_sample.txt"]	\N	\N
39	manychat_test123	2025-12-10 04:11:16.747538	hello	Hi Sam! I'm RACEN, your guide for exploring JoveHeal's healing and coaching programs. What’s on your mind today? I'm here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Balance Mastery](https://joveheal.com/balance-mastery/) | [Services](https://joveheal.com/services/) | [Healing Sessions](https://joveheal.com/healing-sessions/)	f	\N	["website_balance_mastery.txt", "https://www.joveheal.com/contact", "website_elevate360.txt"]	\N	\N
16	7606ae71-395d-45d0-bafb-d5d39fc79661	2025-12-01 11:31:50.924017	I have a broken marriage .. and I am depressed, what course do you suggest?	I'm sorry to hear that you're going through such a difficult time. While I can't provide advice on healing your marriage or addressing feelings of depression, I can share information about JoveHeal's programs that may be helpful.\n\nYou might consider the **Relationship Healing** session, which is designed to help you work through core relationship wounds and enhance connection in your relationships. It's a deep healing session that focuses on transformative healing rather than quick fixes.\n\nIf you're looking for a more comprehensive approach, the **Inner Mastery Lounge** membership is also available. This program supports those who have outgrown surface-level solutions and are ready for deeper shifts in their relationships and personal well-being.\n\nFor personalized support specific to your situation, I encourage reaching out to a licensed therapist or counselor. If you have any more questions about the programs or how to get involved, feel free to ask!	f	\N	["website_balance_mastery.txt", "website_inner_mastery_lounge.txt", "website_elevate360.txt"]	\N	\N
17	7606ae71-395d-45d0-bafb-d5d39fc79661	2025-12-01 11:32:15.789454	ok how do I enroll to this course ..	To enroll in the Relationship Healing course or any other program at JoveHeal, you can visit our website at www.joveheal.com. Once there, please use the contact form for inquiries about specific courses, membership options, and any enrollment processes.\n\nIf you have further questions about the courses or need assistance, feel free to ask!	f	\N	["website_inner_mastery_lounge.txt", "joveheal_sample.txt", "website_services.txt"]	\N	\N
18	7606ae71-395d-45d0-bafb-d5d39fc79661	2025-12-01 11:33:30.420205	I some times feel to take my own life can you help?	I'm really sorry to hear that you're feeling this way. It's very important to speak with someone who can help you, like a licensed therapist or mental health professional. If you're in immediate distress, please reach out to a crisis hotline or local support services in your area. You don't have to go through this alone—there are people who want to help you.\n\nPlease take care of yourself, and I encourage you to seek the support you deserve.	f	\N	["website_elevate360.txt", "website_balance_mastery.txt", "website_beyond_the_hustle.txt"]	\N	\N
19	user_sammy_test	2025-12-04 05:57:21.326436	What programs do you offer?	At JoveHeal, we offer several transformative programs designed to support personal growth and healing. Our key offerings include:\n\n1. **1:1 Private Coaching** - A personalized program for high achievers seeking deep transformational work.\n   \n2. **Transformational Course Library** - This includes courses like [Inner Reset](https://joveheal.com/inner-reset/), [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/), [Career Healing](https://joveheal.com/career-healing/), and [Relationship Healing](https://joveheal.com/relationship-healing/), covering various aspects of personal and professional growth.\n\nIf you're interested in a specific program or want to know more, feel free to ask!	f	\N	["website_inner_mastery_lounge.txt", "website_about.txt", "website_homepage.txt"]	\N	\N
20	user_sammy_new_session	2025-12-04 05:57:50.521872	Tell me more about the first one you mentioned	The **1:1 Private Coaching** program at JoveHeal is a deeply personalized experience designed for high achievers and leaders who might feel successful in their careers but are struggling with internal challenges. This coaching aims to facilitate profound transformation by addressing emotional blocks and restoring balance in life.\n\nCoaching sessions guide you through uncovering the roots of stress, enhancing self-awareness, and implementing strategies that culminate in lasting change. Each session is tailored to your unique journey, allowing for a safe space to heal and grow.\n\nWould you like more information about how to get started with this program or connect with our team?\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Career Healing](https://joveheal.com/career-healing/) | [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt"]	\N	\N
21	guest_1764828759834_sw15y6o92	2025-12-04 06:13:59.133056	I am suffering from a self low esteem what should I do?	I'm really sorry to hear that you're feeling this way. It's completely understandable to struggle with self-esteem sometimes. While I can't provide specific advice or solutions, I encourage you to consider exploring JoveHeal's programs, like "[Shed & Shine](https://joveheal.com/shed-and-shine/)," which focuses on releasing emotional weight and enhancing self-worth. If you're interested, I can share more details or help connect you with JoveHeal's team.	f	\N	["website_elevate360.txt", "website_shed_and_shine.txt", "website_testimonials.txt"]	\N	\N
22	guest_1764828759834_sw15y6o92	2025-12-04 06:14:17.029972	please provide me the details for this ..	"[Shed & Shine](https://joveheal.com/shed-and-shine/)" is a self-paced digital course designed to help you let go of emotional weight and unlock a lighter you. It offers lifetime access to meditations and digital recordings, which can support your journey toward greater self-worth and freedom from emotional patterns.\n\nThis course is particularly beneficial if you feel stuck in cycles of emotional eating, self-sabotage, or guilt around self-care. It's about addressing not just physical challenges but also the emotional ones that can hold you back.\n\nIf you'd like to learn more about enrolling in the course or have other questions about JoveHeal's offerings, I can help connect you with their team!	f	\N	["website_inner_mastery_lounge.txt", "website_shed_and_shine.txt", "website_homepage.txt"]	\N	\N
23	test_shed_shine	2025-12-04 06:23:00.175464	Tell me about Shed and Shine program	The [Shed & Shine](https://joveheal.com/shed-and-shine/) program is a 5-week self-paced digital course designed to help you understand and release the emotional weight you're carrying, both physically and mentally. Throughout the course, you'll explore the root emotional causes behind your weight, reprogram your mindset for a healthier relationship with yourself, and build sustainable habits to support your well-being. You'll gain lifetime access to meditations and digital recordings to revisit whenever you need. It's all about addressing what's in your heart, mind, and soul rather than just the scale. Would you like more details on how to get started or something else?	f	\N	["website_inner_mastery_lounge.txt", "website_shed_and_shine.txt", "website_services.txt"]	\N	\N
24	user_sammy@test.com	2025-12-04 07:34:51.550947	hi	Hi Sammy! It’s great to see you back here! How can I support you today? If you have more questions about our programs or anything else, I’m all ears!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
25	user_newuser@example.com	2025-12-04 07:35:06.292902	hi	Hi Priya! I’m RACEN, your guide for exploring JoveHeal's healing and coaching programs. What brings you here today? Whether you have questions about our offerings or are just curious, I'm here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Balance Mastery](https://joveheal.com/balance-mastery/) | [Services](https://joveheal.com/services/) | [Healing Sessions](https://joveheal.com/healing-sessions/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
26	guest_1764833832077_yp756jiqr	2025-12-04 07:37:24.393672	what programs does JoveHeal offer?	JoveHeal offers several programs focused on wellness coaching and personal transformation. One of the key offerings is the [Balance Mastery](https://joveheal.com/balance-mastery/)+ program, designed to help participants develop clarity about their goals, build sustainable routines, master their mindset, and achieve work-life balance. There’s also the [Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/), which is an ongoing membership option. If you'd like more details or specific information about any program, feel free to ask!	f	\N	["joveheal_sample.txt", "website_contact.txt", "website_homepage.txt"]	\N	\N
27	guest_1764833832077_yp756jiqr	2025-12-04 07:37:42.157292	tell me more about Balance Mastery	[Balance Mastery](https://joveheal.com/balance-mastery/) is a 3-month coaching program tailored for high-performing leaders who may feel successful externally but struggle internally. This program combines one-on-one sessions focused on uncovering the root causes of stress, clearing emotional blocks, and realigning one's internal landscape.\n\nParticipants can expect to gain sustainable calm, clarity in their decisions, and a revitalized energy to support both their leadership and personal lives. The program includes deep root healing, a blueprint shift for lasting transformation, and personalized support throughout the journey. It’s a great option for those looking to reclaim joy and alignment within themselves. \n\nIf you’d like more specifics or have any questions, just let me know!	f	\N	["website_services.txt", "joveheal_sample.txt", "website_balance_mastery.txt"]	\N	\N
28	user_test@summary.com	2025-12-04 07:53:23.834091	I feel disconnected from society and stressed about my career	I'm really sorry to hear that you're feeling this way, Test. It's tough to feel disconnected and stressed, especially regarding something as important as your career. JoveHeal offers a program called "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" that helps uncover emotional patterns that might be impacting your well-being and career satisfaction. Would you like to learn more about that or connect with someone from our team for support?	f	\N	["website_beyond_the_hustle.txt", "website_career_healing.txt", "website_elevate360.txt"]	\N	\N
29	user_test@summary.com	2025-12-04 07:54:01.42505	yes tell me more about Beyond the Hustle	Absolutely, Test! "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" is a soul-shifting masterclass designed for those who appear successful on the outside but feel drained and disconnected on the inside. It focuses on uncovering the emotional roots behind feelings of exhaustion and stuckness.\n\nIn the program, you'll learn about the invisible patterns shaping your career and relationships, and why traditional mindset work often falls short. It includes a guided healing shift to help you release one limiting belief in real time, and provides practical insights on rebuilding your life from your inner truth.\n\nParticipants often leave feeling lighter, clearer, and more seen, equipped with tools that truly make a difference. If you're interested, I can help connect you further with the JoveHeal team!	f	\N	["website_services.txt", "website_beyond_the_hustle.txt", "website_inner_mastery_lounge.txt"]	\N	\N
30	user_test@summary.com_new_session	2025-12-04 07:54:31.753761	hi	Hi again, Test! It’s great to hear from you. How can I assist you today? Whether you have more questions about our programs or something else on your mind, I’m here to help!	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
31	user_test@summary.com_session2	2025-12-04 07:55:29.336616	hi	Hi Test! I’m here and ready to help. What would you like to chat about today?	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
32	user_test@summary.com_session3	2025-12-04 07:56:21.594792	hi	Hi Test! It looks like you might be trying to connect again. Is there something specific you'd like to discuss or ask about? I'm all ears!	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
33	user_test@summary.com_session4	2025-12-04 07:57:22.043668	hi	Hi Test! It's wonderful to see you back. If there's anything on your mind or something you'd like to explore today, just let me know. I'm here to help!	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
34	user_test@summary.com_session5	2025-12-04 07:58:10.668354	hi	Hi Test! It's lovely to have you here again. If there's anything you'd like to talk about or ask, feel free to share. I'm here for you!	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
35	user_test@summary.com_session6	2025-12-04 07:59:17.093107	hi	Hi Test! Great to see you back! I remember you mentioned feeling disconnected from society and stressed about your career. Would you like to continue exploring these feelings or discuss the "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" program we talked about? I'm here to help!	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
36	test_456	2025-12-04 11:26:52.607878	hello there	Hello! I’m RACEN, your guide for exploring JoveHeal's healing and coaching programs. What’s on your mind today? I'm here to help with any questions you have!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Balance Mastery](https://joveheal.com/balance-mastery/) | [Services](https://joveheal.com/services/) | [Healing Sessions](https://joveheal.com/healing-sessions/)	f	\N	["website_balance_mastery.txt", "website_testimonials.txt", "https://www.joveheal.com/balance-mastery"]	\N	\N
37	test_789	2025-12-04 11:27:05.320738	tell me about beyond the hustle program	"[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" is a transformative masterclass designed for individuals who seem successful on the outside but feel drained and disconnected internally. This program helps participants uncover the hidden emotional patterns that impact their careers, relationships, and overall well-being. You'll engage in guided healing work to address limiting beliefs, gain clarity, and learn how to rebuild your life based on your inner truth rather than external pressures. \n\nIt's a deep, soul-shifting experience that goes beyond traditional mindset work, providing tools to feel lighter and more aligned with your true self. Would you like more details or to connect with the JoveHeal team?	f	\N	["website_services.txt", "website_beyond_the_hustle.txt", "website_inner_mastery_lounge.txt"]	\N	\N
38	manychat_insta_12345	2025-12-10 03:43:51.185699	What is Beyond the Hustle?	[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) is a transformative masterclass for those who appear successful on the outside but feel drained and disconnected on the inside. It helps break the cycle of overgiving, exhaustion, and silent suffering, allowing participants to uncover the emotional roots behind their struggles and create meaningful change. You'll gain awareness of hidden patterns, experience guided healing shifts, and learn how to rebuild your life from inner truth rather than pressure. If you're feeling stuck or unfulfilled, this might be the right fit for you! Would you like to know more about the program?	f	\N	["website_services.txt", "website_beyond_the_hustle.txt", "website_inner_mastery_lounge.txt"]	\N	\N
40	widget_1765353094047_v5ueg562z	2025-12-10 07:52:05.989813	Tell me about JoveHeal	JoveHeal is a wellness coaching business focused on helping individuals achieve balance, clarity, and personal transformation through mindset coaching and healing practices. With a mission that emphasizes everyone’s right to a purposeful and peaceful life, JoveHeal combines modern coaching techniques with holistic wellness principles. They offer programs such as the [Balance Mastery](https://joveheal.com/balance-mastery/)+ program, designed to help high-performing leaders develop clarity about their life goals, create sustainable daily routines, and build self-leadership skills. If you’re curious about specific programs or services, feel free to ask!	f	\N	["website_homepage.txt", "joveheal_sample.txt"]	\N	\N
41	widget_1765353332794_h56duugt7	2025-12-10 07:56:06.778024	What is Beyond the Hustle program? (no changes needed)	[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) is a transformative masterclass designed for those who appear successful on the outside but feel drained and disconnected on the inside. It focuses on uncovering the emotional roots behind exhaustion and patterns of overgiving, providing a guided healing experience to release limiting beliefs. Participants learn about the hidden patterns affecting their lives, gaining practical insights to rebuild from their inner truth. If you're interested in exploring this program further, let me know!	f	\N	["website_services.txt", "website_beyond_the_hustle.txt", "website_inner_mastery_lounge.txt"]	\N	\N
42	guest_1765360643640_nl7idovap	2025-12-10 09:57:52.442908	hi	Hi there! I'm RACEN, your guide for exploring JoveHeal's healing and coaching programs. What brings you here today? Whether you're curious about our offerings or looking for support, I'm happy to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Balance Mastery](https://joveheal.com/balance-mastery/) | [Services](https://joveheal.com/services/) | [Healing Sessions](https://joveheal.com/healing-sessions/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
43	guest_1765436537649_mp6r1efp3	2025-12-11 07:03:17.866718	hi	Hi there! We're NIRA, your guide here at Nature Mania. What brings you here today? Whether you're looking for information about our Ayurvedic products or need help choosing the right solution, we're happy to help!\n\n---\n\n*If you'd like to learn more, these might interest you:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "naturemania_company.txt"]	\N	\N
44	guest_1765436789488_tqadnrc3c	2025-12-11 07:10:56.410279	hi	Hi there! We're NIRA, your guide here at Nature Mania. What brings you here today? Whether you're looking for information about our Ayurvedic products or need help choosing the right solution, we're happy to assist you!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "naturemania_company.txt"]	\N	\N
45	guest_1765436789488_tqadnrc3c	2025-12-11 07:14:28.050056	which product will you suggest for sex enhancements	For sexual enhancement, we recommend the following Ayurvedic products that have been designed to support performance and stamina:\n\n1. **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)**:\n   - **Price**: Rs. 999 (originally Rs. 1,799 - 44% off)\n   - **Description**: A natural massage oil formulated to promote blood circulation and support natural enlargement.\n   - **Key Ingredients**: Ashwagandha, Safed Musli, Shatavari.\n   - **How to Use**: Apply and massage gently for 10-15 minutes daily.\n   - [Check it out here](https://naturemania.in/products/lift-up-oil).\n\n2. **[Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule)**:\n   - **Price**: Rs. 1,312 (originally Rs. 1,399 - 6% off)\n   - **Description**: These capsules are designed to enhance performance and support overall sexual health.\n   - [More info here](https://naturemania.in/products/perm-up-capsule).\n\n3. **[Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule)**:\n   - **Price**: Rs. 1,031 (originally Rs. 1,099 - 6% off)\n   - **Description**: Formulated to help improve testosterone levels, aiding in sexual health and stamina.\n   - [Explore here](https://naturemania.in/products/tes-up-capsule).\n\n4. **[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)**:\n   - **Price**: Rs. 1,218 (originally Rs. 1,299 - 6% off)\n   - **Description**: These capsules are aimed at enhancing vitality and stamina in men.\n   - [Learn more here](https://naturemania.in/products/vit-up-capsule).\n\nExtra 5% Off on Prepaid Orders! We also offer Free Shipping across India!\n\nIf you need further assistance or have specific concerns, feel free to reach out to us!	f	\N	["blog_articles.txt", "products_lift_up.txt", "products_women_wellness.txt"]	\N	\N
46	widget_1765437289627_ttdtyw4pj	2025-12-11 07:15:30.194519	Hello, what programs do you offer? (no changes needed)	Hi there! We have a variety of transformative programs at JoveHeal. Our main offerings include:\n\n1. **[Balance Mastery](https://joveheal.com/balance-mastery/)**: A 3-month 1:1 coaching program designed for high-achieving professionals seeking to uncover emotional blocks and restore balance in their lives.\n\n2. **[Elevate 360](https://joveheal.com/elevate-360/)**: A 5-month program focusing on healing and rebuilding your emotional foundation to enhance your life across all dimensions.\n\nWe also provide access to high-frequency transformation tools, exclusive member discounts, and a supportive private community. If you’d like more details on any specific program, just let me know!	f	\N	["website_homepage.txt", "website_inner_mastery_lounge.txt", "website_contact.txt"]	\N	\N
47	widget_1765437473959_j1h9txyv1	2025-12-11 07:18:26.275902	What is Balance Mastery?	[Balance Mastery](https://joveheal.com/balance-mastery/) is our 3-month 1:1 coaching program tailored for high-performing leaders who feel successful on the outside but are struggling internally. The program focuses on uncovering stress roots, releasing emotional blocks, and restoring balance in your life. You'll receive personalized support, deep root healing, and tools for lasting transformation so you can lead with impact and live with inner peace. If you'd like more details or have specific questions, feel free to ask!	f	\N	["website_services.txt", "website_balance_mastery.txt", "joveheal_sample.txt"]	\N	\N
48	guest_1765437466934_bpzixcb5n	2025-12-11 07:19:26.102906	hi	Hi there! We're glad to see you here at Nature Mania. How can we assist you today? Whether you have questions about our Ayurvedic products or need help choosing the right solution, feel free to ask!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "naturemania_company.txt"]	\N	\N
49	widget_1765437473959_j1h9txyv1	2025-12-11 07:19:33.103406	How much does it cost? (no changes needed)	You can see the pricing for [Balance Mastery](https://joveheal.com/balance-mastery/) and enroll at [this link](https://www.joveheal.com/offers/osL3L3qG/checkout). If you'd prefer a personalized one-to-one session with Shaveta, you can also book a complimentary Discovery Call instead. Would you like me to help you with that?	f	\N	["website_services.txt", "website_balance_mastery.txt", "joveheal_sample.txt"]	\N	\N
50	guest_1765437466934_bpzixcb5n	2025-12-11 07:19:53.306864	what product do you suggest for sex enhancements?	For sex enhancement, we recommend the following Ayurvedic products that can support performance and overall wellbeing:\n\n1. **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)**  \n   - **Price:** Rs. 999 (was Rs. 1,799 - 44% off!)\n   - A natural men's massage oil designed to promote blood circulation and support natural enhancement.  \n   - [Check it out here](https://naturemania.in/products/lift-up-oil)\n\n2. **[Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule)**  \n   - **Price:** Rs. 1,312 (was Rs. 1,399 - 6% off!)\n   - These capsules help improve stamina and performance.  \n   - [Explore here](https://naturemania.in/products/perm-up-capsule)\n\n3. **[Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule)**  \n   - **Price:** Rs. 1,031 (was Rs. 1,099 - 6% off!)\n   - Effective for enhancing testosterone levels and sexual performance.  \n   - [Learn more here](https://naturemania.in/products/tes-up-capsule)\n\n4. **[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)**  \n   - **Price:** Rs. 1,218 (was Rs. 1,299 - 6% off!)\n   - Useful for boosting overall vitality and stamina.  \n   - [View details here](https://naturemania.in/products/vit-up-capsule)\n\nWe recommend using these products in combination for the best results. Remember, it's important to consult a healthcare professional for any specific health concerns.\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["blog_articles.txt", "products_lift_up.txt", "products_women_wellness.txt"]	\N	\N
51	guest_1765437466934_bpzixcb5n	2025-12-11 07:20:28.804156	do you offer any discounts	For information about discounts, special offers, or bulk orders, please contact our team directly:\n\n**Phone:** 75092-76000\n**Email:** enquiry@naturemania.in\n\nOur team will be happy to assist you with any pricing inquiries!\n\nIn the meantime, you can also enjoy **Extra 5% Off on Prepaid Orders** on all products. Would you like to know more about any of our products?	t	\N	\N	\N	\N
52	guest_1765437466934_bpzixcb5n	2025-12-11 07:21:04.794355	what is prepaid orders?	Prepaid orders refer to purchases where the payment is completed at the time of placing the order, rather than at the time of delivery. When you choose to pay in advance, you can enjoy **Extra 5% Off on Prepaid Orders** at Nature Mania.\n\nHere’s how it works:\n- You place your order online for any of our products.\n- At checkout, you select a prepaid payment option (like credit/debit card, net banking, or UPI).\n- Once the payment is processed, your order is confirmed, and you may receive the discount.\n\nThis payment method also assists in quicker processing and shipping of your orders. If you have any more questions or need help with the ordering process, feel free to ask!	f	\N	["products_lift_up.txt", "products_sexual_health.txt", "naturemania_company.txt"]	\N	\N
53	guest_1765437466934_bpzixcb5n	2025-12-11 07:21:57.328367	koi herbal oil hai aapke paas?	Haan, humare paas ek herbal oil hai jo aapko zaroor pasand aayega:\n\n### **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)**  \n- **Price:** Rs. 999 (pehle Rs. 1,799 tha - 44% off!)\n- **Size:** 30ml\n\n**Fayde:**\n- Blood circulation badhata hai\n- Natural enlargement mein madad karta hai\n- Stamina aur performance improve karta hai\n- 100% Ayurvedic aur AYUSH Certified hai\n\n**Kaise use karein:** Rozana 10-15 minute tak halka sa massage karein.\n\n**Yahan dekhein:** [Lift-Up Oil](https://naturemania.in/products/lift-up-oil)\n\nPrepaid orders par Extra 5% Off! Free Shipping across India! Agar aapko aur koi madad chahiye ho toh zaroor batayen!	f	\N	["products_lift_up.txt", "products_general_wellness.txt", "products_sexual_health.txt"]	\N	\N
54	guest_1765438454208_nejh7kjn5	2025-12-11 07:34:23.70132	hi	Hi there! I'm NIRA, your guide here at Nature Mania. What brings you here today? Whether you're looking for information about our Ayurvedic products or need help choosing the right solution, I'm happy to help!\n\n---\n\n*If you'd like to learn more, these might interest you:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "naturemania_company.txt"]	\N	\N
55	guest_1765438484407_96s7qm87l	2025-12-11 07:34:51.116764	hi	Hi there! We're NIRA, your friendly assistant at Nature Mania. What brings you here today? If you have any questions about our Ayurvedic products or need help with anything specific, just let us know!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "naturemania_company.txt"]	\N	\N
56	guest_1765438484407_96s7qm87l	2025-12-11 07:36:31.103656	erection ke liye koi medicine hai aapke paas?	Haan, hamaare paas kuch Ayurvedic products hain jo aapke liye madadgar ho sakte hain. Aapko [Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule) aur [Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule) dekhne chahiye.\n\n1. **Perm-Up Capsules**: Ye capsules premature discharge me madad karte hain aur intimacy ke doran timing aur control improve karte hain.\n   - **Price**: Rs. 1,312 (pehle Rs. 1,399 - 6% off)\n   - [Perm-Up Capsules dekhein](https://naturemania.in/products/perm-up-capsule)\n\n2. **Tes-Up Capsules**: Ye stamina aur endurance boost karne me madad karte hain, jo intimate performance ko improve kar sakta hai.\n   - **Price**: Rs. 1,031 (pehle Rs. 1,099 - 6% off)\n   - [Tes-Up Capsules dekhein](https://naturemania.in/products/tes-up-capsule)\n\nInhe daily use karna chahiye for best results. Agar aapko aur jaanana hai ya kisi aur product ke liye madad chahiye, to humein zaroor batayein! \n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_general_wellness.txt", "products_sexual_health.txt", "blog_articles.txt"]	\N	\N
57	guest_1765438484407_96s7qm87l	2025-12-11 07:37:55.986649	mein aapna sex stamina kaise badha sakta hun?	Aap apne sex stamina ko badhane ke liye kuch natural tarike aur Ayurvedic supplements istemal kar sakte hain. Yahan kuch tips aur remedies hain jo madadgar ho sakti hain:\n\n1. **Ayurvedic Herbs**: Ashwagandha, Shilajit, aur Safed Musli jaise herbs ka istemal karein, jo stamina aur energy ko badhane me madad karte hain.\n\n2. **Regular Exercise**: Cardio aur strength training se stamina improve hota hai. Kegel exercises bhi pelvic floor muscles ko majboot karne me madadgar hain.\n\n3. **Healthy Diet**: Protein-rich foods, fruits, aur vegetables khayen. Yeh aapki overall health aur stamina ko sudharega.\n\n4. **Adequate Sleep**: Har raat 7-8 ghante ka achha neend lena zaroori hai, kyunki yeh hormone balance aur energy levels ke liye important hai.\n\n5. **Stress Reduction**: Yoga aur meditation se stress kam karne se aapki stamina aur performance improve hoti hai.\n\n6. **Natural Supplements**: Aap hamaare Ayurvedic products jaise **[Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule)** aur **[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)** ko bhi consider kar sakte hain:\n   - **Tes-Up Capsules**: Rs. 1,031 - [Tes-Up Capsules dekhein](https://naturemania.in/products/tes-up-capsule)\n   - **Vit-Up Capsules**: Rs. 1,218 - [Vit-Up Capsules dekhein](https://naturemania.in/products/vit-up-capsule)\n\nInhe regular use karne se aapke stamina mein sudhar dekha ja sakta hai. Yadi aapko aur jaankari chahiye ya kisi specific product ke bare mein poochna hai, to humein zaroor batayein!\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["blog_articles.txt", "products_general_wellness.txt", "products_sexual_health.txt"]	\N	\N
58	stress_test_0	2025-12-11 10:14:39.198919	What products does Naturemania offer? (no changes needed)	For information about discounts, special offers, or bulk orders, please contact our team directly:\n\n**Phone:** 75092-76000\n**Email:** enquiry@naturemania.in\n\nOur team will be happy to assist you with any pricing inquiries!\n\nIn the meantime, you can also enjoy **Extra 5% Off on Prepaid Orders** on all products. Would you like to know more about any of our products?	t	safety_redirect	\N	\N	\N
59	stress_test_1	2025-12-11 10:14:42.686278	How much does Lift-Up Oil cost? (no changes needed)	[Lift-Up Oil](https://naturemania.in/products/lift-up-oil) costs Rs. 999 (originally Rs. 1,799 - 44% off!). \n\nYou can check it out here: https://naturemania.in/products/lift-up-oil\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_lift_up.txt", "products_women_wellness.txt"]	\N	\N
60	stress_test_4	2025-12-11 10:14:43.97761	Which products are for women? (no changes needed)	We have a great selection of products specifically designed for women's wellness:\n\n1. **[Cup-Up Capsules](https://naturemania.in/products/cup-up-capsules)**\n   - Purpose: Breast enhancement, shaping, and uplifting.\n   - Price: Rs. 843 (was Rs. 899 - 6% off)\n   - URL: [Cup-Up Capsules](https://naturemania.in/products/cup-up-capsules)\n\nYou can explore our entire range of products here: [All Products](https://naturemania.in/collections/all).\n\nIf you need more information, feel free to contact us!	f	\N	["blog_articles.txt", "products_women_wellness.txt", "products_lift_up.txt"]	\N	\N
61	stress_test_3	2025-12-11 10:14:44.089933	What are the benefits of Perm-Up Capsules? (no changes needed)	[Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule) are formulated to help men with premature discharge issues. The Ayurvedic formula works naturally to improve timing and control during intimacy.\n\n**Key Benefits:**\n- Helps control premature discharge\n- Improves timing and duration\n- Boosts confidence during intimacy\n- Reduces performance anxiety\n- Enhances stamina and endurance\n- 100% Ayurvedic Ingredients\n- AYUSH Certified\n- No side effects\n\nFor more information, check out the product here: [Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule).\n\n**Price:** Rs. 1,312 (Discounted from Rs. 1,399 - 6% off!)  \nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_sexual_health.txt", "products_lift_up.txt", "products_women_wellness.txt"]	\N	\N
62	stress_test_2	2025-12-11 10:14:44.889054	Tell me about Shilajit Gold Resin	[Shilajit Gold Resin](https://naturemania.in/products/nature-mania-shilajit-gold-resin) is a powerful natural supplement known for its energy-boosting and vitality-enhancing properties. Sourced from the Himalayas, this premium resin is formulated to support overall well-being and enhance physical performance.\n\n**Price:** Rs. 1,171 (original price Rs. 1,249 - 6% off!)\n\n**Size:** 20gm\n\nKey benefits:\n- Boosts energy and stamina\n- Enhances physical performance\n- Supports natural testosterone levels\n- Improves mental clarity\n- Rich in fulvic acid and minerals\n- 100% Pure and Natural\n\n**How to use:** Take one capsule twice daily with lukewarm water or milk after meals. It is recommended to use it for at least 2-3 months for optimal results.\n\nFeel free to check it out here: [Shilajit Gold Resin](https://naturemania.in/products/nature-mania-shilajit-gold-resin)\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_sexual_health.txt", "naturemania_company.txt", "products_general_wellness.txt"]	\N	\N
63	stress_test_5	2025-12-11 10:14:50.026659	Do you have any discounts?	For information about discounts, special offers, or bulk orders, please contact our team directly:\n\n**Phone:** 75092-76000\n**Email:** enquiry@naturemania.in\n\nOur team will be happy to assist you with any pricing inquiries!\n\nIn the meantime, you can also enjoy **Extra 5% Off on Prepaid Orders** on all products. Would you like to know more about any of our products?	t	safety_redirect	\N	\N	\N
64	stress_test_7	2025-12-11 10:14:52.633131	What is the price of Tes-Up? (no changes needed)	The price of [Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule) is Rs. 1,031.00, discounted from Rs. 1,099.00 (6% off). \n\nYou can check it out here: https://naturemania.in/products/tes-up-capsule\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_sexual_health.txt", "products_general_wellness.txt", "blog_articles.txt"]	\N	\N
65	stress_test_6	2025-12-11 10:14:52.927954	How to use Lift-Up Capsules?	To use [Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules), follow these instructions:\n\n- **Dosage:** Take 1-2 capsules twice daily.\n- **Best taken with:** Lukewarm water or milk.\n- **Timing:** Consume them 30 minutes after meals for optimal absorption.\n\nFor best results, we recommend using the capsules for at least 2-3 months.\n\nYou can check out Lift-Up Capsules here: [Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules)\n\n**Price:** Rs. 1,499 (was Rs. 1,699 - 12% off!)\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_lift_up.txt", "products_women_wellness.txt"]	\N	\N
66	stress_test_8	2025-12-11 10:14:54.5329	Tell me about Cup-Up Capsules	[Cup-Up Capsules](https://naturemania.in/products/cup-up-capsules) are designed specifically for breast enhancement, shaping, and uplifting. They provide a safe and natural way to increase breast size without the need for costly surgeries or potentially harmful medications.\n\n**Price:** Rs. 843 (was Rs. 899 - 6% off!)\n\n**Key Benefits:**\n- Increases breast size naturally\n- Helps in breast toning and firming\n- Plumps, firms, and uplifts breasts\n- Improves cup size and smoothens skin\n- Tightens and shapes breasts, reducing sagging\n- Balances uneven breasts and improves hormonal balance\n- 100% Ayurvedic ingredients with no known side effects\n- AYUSH Certified\n\n**How to Use:** Take one capsule in the morning and one in the evening with lukewarm water, 20 minutes after meals. For best results, it is recommended to use continuously for 60-90 days.\n\n**Key Ingredients:** \n- Ashwagandha\n- Gambhari\n- Motha\n- Shatavari\n- Methi\n\nYou can find more details and purchase the Cup-Up Capsules here: [Cup-Up Capsules](https://naturemania.in/products/cup-up-capsules)\n\nRemember, we have **Extra 5% Off on Prepaid Orders** and **Free Shipping across India**!	f	\N	["products_women_wellness.txt", "products_lift_up.txt", "products_sexual_health.txt"]	\N	\N
67	stress_test_9	2025-12-11 10:15:02.491542	How can I place an order?	Placing an order is simple! Here’s how you can do it:\n\n1. **Visit our Website**: Go to [Nature Mania's website](https://naturemania.in/).\n2. **Browse Products**: Browse through our range of Ayurvedic products on the [All Products page](https://naturemania.in/collections/all).\n3. **Select Products**: Click on the product you are interested in to view the details and add it to your cart.\n4. **Proceed to Checkout**: Once you have selected all the products you want, go to your cart and click on 'Checkout'.\n5. **Fill in Your Details**: Enter your shipping information and choose your payment method. We offer Cash on Delivery (COD) and prepaid options.\n6. **Confirm Your Order**: Review your order and confirm it!\n\nIf you have any questions or need further help, feel free to [contact us](https://naturemania.in/pages/contact) or call us at 75092-76000. Happy shopping! \n\n**Extra 5% Off on Prepaid Orders!** Enjoy **Free Shipping** across India!	f	\N	["naturemania_company.txt", "products_lift_up.txt"]	\N	\N
68	stress_test_11	2025-12-11 10:15:07.158272	Do you offer free shipping? (no changes needed)	For information about discounts, special offers, or bulk orders, please contact our team directly:\n\n**Phone:** 75092-76000\n**Email:** enquiry@naturemania.in\n\nOur team will be happy to assist you with any pricing inquiries!\n\nIn the meantime, you can also enjoy **Extra 5% Off on Prepaid Orders** on all products. Would you like to know more about any of our products?	t	safety_redirect	\N	\N	\N
69	stress_test_12	2025-12-11 10:15:10.474984	What are the ingredients in Lift-Up Oil? (no changes needed)	[Lift-Up Oil](https://naturemania.in/products/lift-up-oil) is made with a combination of natural Ayurvedic ingredients that include:\n\n- Ashwagandha\n- Safed Musli\n- Shatavari\n- Other Ayurvedic herbs\n\nThese ingredients are formulated to promote blood circulation and support natural enhancement. \n\nFor more details, you can check it out here: [Lift-Up Oil](https://naturemania.in/products/lift-up-oil). \n\nIf you have any more questions, feel free to ask!	f	\N	["products_lift_up.txt", "products_general_wellness.txt"]	\N	\N
70	stress_test_13	2025-12-11 10:15:10.624462	Are products safe for diabetics? (no changes needed)	Our products are natural Ayurvedic supplements designed to support overall wellness. However, they are not formulated specifically for diabetics or as treatment for diabetes. Therefore, we recommend that anyone with health conditions, including diabetes, consult with a qualified healthcare professional before using our products. \n\nIf you would like to know more about specific products or need assistance, feel free to reach out to us! You can explore our offerings at [Nature Mania](https://naturemania.in/).	f	\N	["products_general_wellness.txt", "naturemania_company.txt", "blog_articles.txt"]	\N	\N
71	stress_test_10	2025-12-11 10:15:11.54673	What makes Naturemania products different? (no changes needed)	Nature Mania products stand out due to several key factors:\n\n1. **100% Ayurvedic Ingredients:** We believe in the power of Ayurveda, using only pure Ayurvedic ingredients in our formulations.\n\n2. **Experienced Team:** Our products are formulated by experienced Ayurvedic doctors who ensure a blend of traditional wisdom and modern science.\n\n3. **AYUSH Certified:** All our products are certified by AYUSH, ensuring their quality and efficacy.\n\n4. **No Side Effects:** We focus on natural solutions with no harmful side effects, promoting overall well-being.\n\n5. **User-Friendly:** Our products are easy to use, making it convenient for our customers to incorporate wellness into their daily lives.\n\n6. **Wide Range of Products:** We offer a diverse selection of natural wellness supplements to address various health needs.\n\nThese attributes combined make our products unique and effective for our customers' health and wellness journeys. For more information about our products, feel free to check them out here: [All Products](https://naturemania.in/collections/all).	f	\N	["naturemania_company.txt", "products_general_wellness.txt", "products_sexual_health.txt"]	\N	\N
72	stress_test_14	2025-12-11 10:15:19.488958	What is Smart Shaping Powder used for? (no changes needed)	[Smart Shaping Powder](https://naturemania.in/products/nature-mania-smart-shaping-powder) is a high-quality blend designed for effective fat metabolism, increased energy, and improved endurance. Specifically, it helps to use fat as an energy source for active lifestyles. \n\nHere are some key benefits of Smart Shaping Powder:\n- Supports advanced fat metabolism\n- Boosts energy levels and endurance\n- Accelerates post-workout recovery\n- Enhances brain health and mental clarity\n- Pure, safe, and effective formula with no artificial additives or fillers\n\n**How to use:** Mix one sachet with 250ml chilled water, shake for 20-30 seconds, and drink. It's best consumed 30 minutes before a workout.\n\n**Price:** Rs. 2,249 (was Rs. 3,699 - 39% off!)\n\nYou can check out Smart Shaping Powder here: [Smart Shaping Powder](https://naturemania.in/products/nature-mania-smart-shaping-powder)\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_general_wellness.txt", "products_women_wellness.txt"]	\N	\N
73	stress_test_15	2025-12-11 10:15:25.732878	How long does delivery take?	Delivery typically takes 2-6 working days across India. Orders are dispatched within 48 hours. If you need your order faster, we also offer express shipping at a nominal cost. Plus, we provide free shipping on all orders!\n\nIf you have any more questions or need assistance, feel free to contact us!	f	\N	["products_general_wellness.txt", "naturemania_company.txt", "products_women_wellness.txt"]	\N	\N
74	stress_test_16	2025-12-11 10:15:27.45871	Can I pay cash on delivery? (no changes needed)	Yes, you can pay cash on delivery (COD) for your orders with us. We offer this option across India for your convenience. If you have any more questions or need assistance with placing an order, feel free to contact us!\n\nFor more information, you can visit our website: https://naturemania.in/	f	\N	["naturemania_company.txt", "products_general_wellness.txt"]	\N	\N
75	stress_test_19	2025-12-11 10:15:28.385952	How to contact customer support? (no changes needed)	To contact our customer support, you can reach us through the following:\n\n**Phone:** 75092-76000  \n**Email:** enquiry@naturemania.in  \n**Contact Page:** https://naturemania.in/pages/contact  \n\nWe're here to assist you!	f	\N	["naturemania_company.txt", "products_general_wellness.txt", "products_women_wellness.txt"]	\N	\N
76	stress_test_18	2025-12-11 10:15:29.651823	Tell me about Vit-Up Capsules	[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule) are a comprehensive multivitamin supplement designed to provide essential vitamins and minerals for overall health support.\n\n**Price:** Rs. 1,218 (originally Rs. 1,299 - 6% off!)\n**Size:** 60 Capsules\n\n### Key Benefits:\n- Boosts immune system\n- Provides essential nutrients\n- Increases stamina and endurance\n- Improves blood circulation and hormone balance\n- Enhances energy levels\n- Strengthens the immune system\n\n### Key Ingredients:\n- Aawla/Amla, Ashwagandha, Loh Bhasam, Vidarikand, Shilajit, and others rich in antioxidants and various vitamins.\n\n### How to Use:\nTake one Vit-Up capsule twice a day with water, after meals. Consistent use is recommended for the best results.\n\nYou can check out Vit-Up Capsules here: [Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)\n\n**Extra 5% Off on Prepaid Orders! Free Shipping across India!**	f	\N	["products_general_wellness.txt", "products_sexual_health.txt", "blog_articles.txt"]	\N	\N
88	stress_test_11	2025-12-11 10:29:55.503423	Do you offer free shipping?	For information about discounts, special offers, or bulk orders, please contact our team directly:\n\n**Phone:** 75092-76000\n**Email:** enquiry@naturemania.in\n\nOur team will be happy to assist you with any pricing inquiries!\n\nIn the meantime, you can also enjoy **Extra 5% Off on Prepaid Orders** on all products. Would you like to know more about any of our products?	t	safety_redirect	\N	\N	\N
90	stress_test_13	2025-12-11 10:29:59.463879	Are products safe for diabetics?	While we provide Ayurvedic wellness products, our team cannot give specific medical advice regarding safety for diabetics or any other health conditions. We recommend consulting with a qualified healthcare professional to determine the suitability of our products for your individual health needs.\n\nIf you're interested in exploring our Ayurvedic offerings, feel free to visit our website: [Nature Mania All Products](https://naturemania.in/collections/all). \n\nLet us know if you need any further assistance!	f	\N	["naturemania_company.txt", "products_general_wellness.txt"]	\N	\N
77	stress_test_17	2025-12-11 10:15:32.060923	What products help with stamina? (no changes needed)	We offer several products that can help boost stamina and enhance performance. Here are some of our Ayurvedic supplements designed for stamina improvement:\n\n1. **[Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule)**  \n   **Price:** Rs. 1,031 (was Rs. 1,099 - 6% off)  \n   [Learn more here](https://naturemania.in/products/tes-up-capsule)\n\n2. **[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)**  \n   **Price:** Rs. 1,218 (was Rs. 1,299 - 6% off)  \n   [Learn more here](https://naturemania.in/products/vit-up-capsule)\n\n3. **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)**  \n   **Price:** Rs. 999 (was Rs. 1,799 - 44% off)  \n   [Learn more here](https://naturemania.in/products/lift-up-oil)\n\n4. **[Shilajit Gold Resin](https://naturemania.in/products/nature-mania-shilajit-gold-resin)**  \n   **Price:** Rs. 1,171 (was Rs. 1,249 - 6% off)  \n   [Learn more here](https://naturemania.in/products/nature-mania-shilajit-gold-resin)\n\nThese products are made with natural ingredients that can support energy levels and enhance stamina. Remember, for specific health concerns, it's always best to consult a healthcare professional.\n\nAlso, don’t forget that you can enjoy **Extra 5% Off on Prepaid Orders** and **Free Shipping** across India! If you have any further questions or need assistance, feel free to reach out to us!	f	\N	["blog_articles.txt", "products_general_wellness.txt", "products_sexual_health.txt"]	\N	\N
78	stress_test_0	2025-12-11 10:29:35.538878	What products does Naturemania offer? (no changes needed)	For information about discounts, special offers, or bulk orders, please contact our team directly:\n\n**Phone:** 75092-76000\n**Email:** enquiry@naturemania.in\n\nOur team will be happy to assist you with any pricing inquiries!\n\nIn the meantime, you can also enjoy **Extra 5% Off on Prepaid Orders** on all products. Would you like to know more about any of our products?	t	safety_redirect	\N	\N	\N
79	stress_test_1	2025-12-11 10:29:38.844091	How much does Lift-Up Oil cost? (no changes needed)	[Lift-Up Oil](https://naturemania.in/products/lift-up-oil) costs **Rs. 999** (originally Rs. 1,799 - 44% off!). \n\nYou can check it out here: [Lift-Up Oil](https://naturemania.in/products/lift-up-oil).\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_lift_up.txt", "products_women_wellness.txt"]	\N	\N
80	stress_test_2	2025-12-11 10:29:40.159486	Tell me about Shilajit Gold Resin	Nature Mania [Shilajit Gold Resin](https://naturemania.in/products/nature-mania-shilajit-gold-resin) is a powerful natural supplement sourced from the Himalayas, known for its energy-boosting and vitality-enhancing properties.\n\n**Price:** Rs. 1,171 (was Rs. 1,249 - 6% off!)\n**Size:** 20gm\n\n**Key Benefits:**\n- Boosts energy and stamina\n- Enhances physical performance\n- Supports natural testosterone levels\n- Improves mental clarity\n- Rich in fulvic acid and minerals\n- 100% Pure and Natural\n\n**How to Use:** Take one capsule twice daily with lukewarm water or milk after meals for optimal results.\n\nYou can check it out here: [Shilajit Gold Resin](https://naturemania.in/products/nature-mania-shilajit-gold-resin)\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_sexual_health.txt", "naturemania_company.txt", "products_general_wellness.txt"]	\N	\N
81	stress_test_3	2025-12-11 10:29:40.257615	What are the benefits of Perm-Up Capsules? (no changes needed)	[Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule) are formulated to help men with premature discharge issues. The Ayurvedic formula works naturally to improve timing and control during intimacy.\n\n**Key Benefits:**\n- Helps control premature discharge\n- Improves timing and duration\n- Boosts confidence during intimacy\n- Reduces performance anxiety\n- Enhances stamina and endurance\n- 100% Ayurvedic Ingredients\n- AYUSH Certified\n- No side effects\n\nFor more details, you can check out the product here: [Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule)\n\n**Price:** Rs. 1,312 (originally Rs. 1,399 - 6% off)! \n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_sexual_health.txt", "products_lift_up.txt", "products_women_wellness.txt"]	\N	\N
82	stress_test_4	2025-12-11 10:29:40.323469	Which products are for women?	We have some great products for women's wellness. Here are our offerings:\n\n1. **[Cup-Up Capsules](https://naturemania.in/products/cup-up-capsules)**  \n   - **Price:** Rs. 843 (Discounted from Rs. 899 - 6% off)  \n   - **Description:** These capsules are designed for breast enhancement, shaping, and uplifting. They are made with 100% Ayurvedic ingredients with no side effects.  \n   - **Key Benefits:** Increases breast size naturally, helps in toning and firming, balances uneven breasts, and improves hormonal imbalance.  \n   - **Learn more here:** [Cup-Up Capsules](https://naturemania.in/products/cup-up-capsules)\n\nIf you need more information or have any specific queries, feel free to **contact us**! We are here to help!	f	\N	["blog_articles.txt", "products_women_wellness.txt", "products_sexual_health.txt"]	\N	\N
83	stress_test_5	2025-12-11 10:29:45.132567	Do you have any discounts? (no changes needed)	For information about discounts, special offers, or bulk orders, please contact our team directly:\n\n**Phone:** 75092-76000\n**Email:** enquiry@naturemania.in\n\nOur team will be happy to assist you with any pricing inquiries!\n\nIn the meantime, you can also enjoy **Extra 5% Off on Prepaid Orders** on all products. Would you like to know more about any of our products?	t	safety_redirect	\N	\N	\N
84	stress_test_7	2025-12-11 10:29:47.541258	What is the price of Tes-Up? (no changes needed)	The price of [Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule) is Rs. 1,031 (discounted from Rs. 1,099 - 6% off). \n\nYou can check it out here: [Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule).\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_sexual_health.txt", "products_general_wellness.txt", "blog_articles.txt"]	\N	\N
85	stress_test_6	2025-12-11 10:29:48.625194	How to use Lift-Up Capsules?	To use [Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules), follow these instructions:\n\n- **Dosage:** Take 1-2 capsules twice daily.\n- **Best Time:** Consume the capsules with lukewarm water or milk.\n- **Timing:** Take them 30 minutes after meals for optimal absorption.\n- **Recommended Duration:** For best results, it's advised to use the capsules for at least 2-3 months.\n\nYou can find more details and purchase the Lift-Up Capsules here: [Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules).\n\nIf you have any other questions or need assistance, feel free to contact us!	f	\N	["products_lift_up.txt", "products_women_wellness.txt"]	\N	\N
86	stress_test_9	2025-12-11 10:29:48.746515	How can I place an order? (no changes needed)	Placing an order with us at Nature Mania is simple! Just follow these steps:\n\n1. Visit our website: [Nature Mania](https://naturemania.in/).\n2. Browse our products and click on any item you're interested in.\n3. Choose the desired quantity and click on the "Add to Cart" button.\n4. Once you've added all your desired products to your cart, click on the cart icon to review your selections.\n5. Click on the "Checkout" button.\n6. Fill in your shipping details and choose your payment method (we offer Cash on Delivery and prepaid options).\n7. Confirm your order.\n\nThat's it! You will receive an order confirmation via email. If you have any further questions or need assistance, please feel free to contact us at [Contact Us](https://naturemania.in/pages/contact) or call 75092-76000. Happy shopping!	f	\N	["naturemania_company.txt", "products_lift_up.txt", "blog_articles.txt"]	\N	\N
87	stress_test_8	2025-12-11 10:29:50.966476	Tell me about Cup-Up Capsules	[Cup-Up Capsules](https://naturemania.in/products/cup-up-capsules) are our natural breast enhancement supplement designed to safely and effectively increase breast size without the need for surgery or hazardous medications.\n\n**Price:** Rs. 843 (was Rs. 899 - 6% off!)  \n**Size:** 60 capsules\n\n### Key Benefits:\n- Increases breast size naturally\n- Helps in breast toning and firming\n- Provides plumping, firming, and uplifting effects on breasts\n- Improves cup size and smoothens skin\n- Tightens and improves shape\n- Balances uneven breasts\n- Supports hormonal balance\n- Made with 100% Ayurvedic ingredients and AYUSH certified\n\n### Key Ingredients:\n- Ashwagandha\n- Gambhari\n- Motha\n- Shatawar (Shatavari)\n- Methi\n\n### How to Use:\nTake one capsule in the morning and one in the evening with lukewarm water after 20 minutes of a meal. For best results, we recommend using it continuously for 60-90 days.\n\n### Customer Reviews:\nOur customers have shared positive experiences with Cup-Up Capsules, noting enhancements in both wellness and appearance.\n\nExplore more and order here: [Cup-Up Capsules](https://naturemania.in/products/cup-up-capsules)\n\n**Remember:** We offer **Extra 5% Off on Prepaid Orders** and **Free Shipping across India!**	f	\N	["products_women_wellness.txt", "products_lift_up.txt", "products_sexual_health.txt"]	\N	\N
89	stress_test_12	2025-12-11 10:29:58.650362	What are the ingredients in Lift-Up Oil? (no changes needed)	[Lift-Up Oil](https://naturemania.in/products/lift-up-oil) is made with a blend of natural Ayurvedic ingredients, including:\n\n- Ashwagandha\n- Safed Musli\n- Shatavari\n- Other Ayurvedic herbs\n\nThese ingredients are designed to promote blood circulation and support natural enhancement. You can learn more about Lift-Up Oil and its benefits here: [Lift-Up Oil](https://naturemania.in/products/lift-up-oil).\n\nIf you have any further questions, feel free to ask!	f	\N	["products_lift_up.txt", "products_general_wellness.txt"]	\N	\N
92	stress_test_14	2025-12-11 10:30:00.228289	What is Smart Shaping Powder used for? (no changes needed)	[Smart Shaping Powder](https://naturemania.in/products/nature-mania-smart-shaping-powder) is used for effective fat metabolism, increased energy, and improved endurance. It is enriched with L-carnitine compounds, helping to use fat as an energy source for active lifestyles.\n\n**Key Benefits:**\n- Advanced fat metabolism support\n- Boosts energy and endurance\n- Accelerates post-workout recovery\n- Supports brain health and mental clarity\n- Pure, safe, and effective formula\n- No artificial additives or fillers\n\n**Price:** Rs. 2,249 (was Rs. 3,699 - 39% off!)\n\nYou can check it out here: [Smart Shaping Powder](https://naturemania.in/products/nature-mania-smart-shaping-powder)\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_general_wellness.txt", "products_women_wellness.txt"]	\N	\N
94	stress_test_19	2025-12-11 10:30:08.32248	How to contact customer support? (no changes needed)	You can contact our customer support through the following methods:\n\n**Phone:** 75092-76000  \n**Email:** enquiry@naturemania.in  \n**Contact Page:** [Click here to contact us](https://naturemania.in/pages/contact)\n\nWe're here to help!	f	\N	["naturemania_company.txt", "products_general_wellness.txt", "products_women_wellness.txt"]	\N	\N
97	stress_test_17	2025-12-11 10:30:12.525952	What products help with stamina? (no changes needed)	To boost stamina, we recommend the following Ayurvedic products from our range:\n\n1. **[Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule)**: These capsules help boost energy and stamina, enhancing physical performance naturally.\n   - **Price:** Rs. 1,031 (was Rs. 1,099 - 6% off!)\n   - **Product URL:** [Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule)\n\n2. **[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)**: Designed to support natural testosterone levels and improve endurance.\n   - **Price:** Rs. 1,218 (was Rs. 1,299 - 6% off!)\n   - **Product URL:** [Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)\n\n3. **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)**: A natural massage oil that promotes blood circulation and supports overall vitality and performance.\n   - **Price:** Rs. 999 (was Rs. 1,799 - 44% off!)\n   - **Product URL:** [Lift-Up Oil](https://naturemania.in/products/lift-up-oil)\n\n4. **[Shilajit Gold Resin](https://naturemania.in/products/nature-mania-shilajit-gold-resin)**: Known for enhancing endurance and stamina through its rich supply of minerals and fulvic acid.\n   - **Price:** Rs. 1,171 (was Rs. 1,249 - 6% off!)\n   - **Product URL:** [Shilajit Gold Resin](https://naturemania.in/products/nature-mania-shilajit-gold-resin)\n\nRegular use of these products, along with a healthy lifestyle, can significantly enhance stamina. \n\nRemember, for personalized health concerns, it's always best to consult a healthcare professional. \n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["blog_articles.txt", "products_general_wellness.txt", "products_sexual_health.txt"]	\N	\N
91	stress_test_10	2025-12-11 10:29:59.795416	What makes Naturemania products different? (no changes needed)	Nature Mania products stand out due to several key factors:\n\n1. **100% Ayurvedic Ingredients**: All our products are formulated using pure Ayurvedic ingredients, ensuring a natural approach to wellness.\n\n2. **AYUSH Certified**: Our products are certified by the AYUSH system, guaranteeing quality and safety.\n\n3. **No Side Effects**: We prioritize safe formulations that do not carry the risk of side effects commonly associated with synthetic products.\n\n4. **Formulated by Experts**: Our product formulations are created by experienced Ayurvedic doctors, ensuring efficacy and alignment with traditional practices.\n\n5. **Comprehensive Wellness Focus**: Our products address a wide range of wellness needs, from intimate health to general well-being, enhancing overall vitality.\n\n6. **Free Shipping and Easy Purchases**: We offer free shipping across India and the convenience of cash on delivery, making it easy for customers to access our products.\n\nIf you want to explore our offerings, feel free to visit: [Nature Mania Products](https://naturemania.in/collections/all)	f	\N	["naturemania_company.txt", "products_general_wellness.txt", "products_sexual_health.txt"]	\N	\N
96	stress_test_18	2025-12-11 10:30:11.370583	Tell me about Vit-Up Capsules	[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule) are a comprehensive multivitamin supplement designed to provide optimum nutritional support for overall health. They are formulated with a blend of essential vitamins, minerals, amino acids, and antioxidants.\n\n**Price:** Rs. 1,218 (originally Rs. 1,299 - Save Rs. 81, 6% off)\n**Size:** 60 Capsules\n**Rating:** 4.7 (based on 353 votes)\n\n**Key Benefits:**\n- Boosts the immune system\n- Provides essential nutrients\n- Increases stamina and endurance\n- Improves blood circulation and hormone balance\n- Enhances energy levels\n- Strengthens overall vitality\n\n**Key Ingredients:**\n- Aawla/Amla\n- Ashwagandha\n- Loh Bhasam\n- Vidarikand\n- Shilajit\n- Gokhru\n- Bala\n- Draksha\n- Dalchini\n- Elaichi\n- Abhrak Bhasam\n- Swaran Makshik Bhasam\n- Vidhara Mool\n\n**How to Use:** Take one Vit-Up capsule twice a day with water, after meals. For best results, take them at the same time each day.\n\nCheck out Vit-Up Capsules here: [Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_general_wellness.txt", "products_sexual_health.txt", "blog_articles.txt"]	\N	\N
93	stress_test_16	2025-12-11 10:30:06.62226	Can I pay cash on delivery? (no changes needed)	Yes, you can pay cash on delivery (COD) for your orders with us! We offer this payment option across India. If you have any further questions or need assistance, feel free to contact us.	f	\N	["naturemania_company.txt", "products_general_wellness.txt"]	\N	\N
95	stress_test_15	2025-12-11 10:30:08.473793	How long does delivery take? (no changes needed)	Delivery typically takes 2-6 working days after dispatch. We dispatch orders within 48 hours, ensuring a quick and reliable service. \n\nFor more details or to track your order, you can visit: https://emm-dee-enterprises.shiprocket.co/\n\nIf you have any other questions, feel free to reach out!	f	\N	["naturemania_company.txt", "products_women_wellness.txt", "products_general_wellness.txt"]	\N	\N
98	guest_1765451865245_ikr5yipxx	2025-12-11 11:18:05.563748	hi	Hi there! I'm NIRA, your guide here at Nature Mania. What brings you here today? Whether you're looking for information about our Ayurvedic products or need help choosing the right solution, I'm happy to help!\n\n---\n\n*Here are some products that align with what we discussed:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "naturemania_company.txt"]	\N	\N
99	guest_1765521802876_1s9jl0uvd	2025-12-12 06:43:41.777722	hi	Hi there! We're NIRA, your guide here at Nature Mania. How can we assist you today? Whether you're curious about our Ayurvedic products or need help with something specific, we're here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "naturemania_company.txt"]	\N	\N
100	guest_1765521493208_968l2s3y4	2025-12-12 07:19:00.092941	hi	Hi there! We're NIRA, your guide here at Nature Mania. What brings you here today? If you're looking for information about our Ayurvedic products or need help choosing the right solution, we're happy to assist!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "naturemania_company.txt"]	\N	\N
101	guest_1765532526825_0o345z1jq	2025-12-12 09:42:42.191356	How lift up oil can help me	[Lift-Up Oil](https://naturemania.in/products/lift-up-oil) is designed to support natural male enhancement by promoting blood circulation and overall vitality. Here are some key benefits:\n\n- **Promotes Blood Circulation**: It enhances blood flow to the male organ, which can improve performance.\n- **Supports Natural Enlargement**: Regular use may help with the natural enlargement process.\n- **Improves Stamina and Performance**: The blend of Ayurvedic herbs is aimed at enhancing stamina and overall energy levels.\n\n**Key Ingredients**: Lift-Up Oil is made from natural Ayurvedic ingredients like Ashwagandha, Safed Musli, and Shatavari, ensuring no harmful additives or chemicals.\n\n**How to Use**: Apply the oil and massage gently for about 10-15 minutes daily for best results.\n\n**Price**: Rs. 999 (originally Rs. 1,799 - 44% off!). \n\nYou can explore more about it here: [Lift-Up Oil](https://naturemania.in/products/lift-up-oil).\n\nPlus, enjoy **Extra 5% Off on Prepaid Orders** and **Free Shipping** across India! If you have any more questions or need assistance, feel free to reach out to us!	f	\N	["products_lift_up.txt", "blog_articles.txt"]	\N	\N
102	guest_1765532526825_0o345z1jq	2025-12-12 09:43:08.628668	In how many days it will be delivered	Delivery times can vary depending on your location, but we generally aim to deliver our products within 5 to 7 business days. Once your order is placed, you will receive tracking details so you can monitor the shipment.\n\nIf you have specific delivery concerns or need assistance, don’t hesitate to [contact us](https://naturemania.in/pages/contact) or call us at **75092-76000**. We're here to help!	f	\N	["products_lift_up.txt", "products_women_wellness.txt"]	\N	\N
103	guest_1765532526825_0o345z1jq	2025-12-12 09:43:34.76336	how can I track my delivery	You can track your delivery easily by visiting our order tracking page here: [Track Order](https://emm-dee-enterprises.shiprocket.co/). Just enter the required details, and you'll be able to see the status of your shipment.\n\nIf you have any further questions or need assistance, feel free to [contact us](https://naturemania.in/pages/contact) or call us at **75092-76000**. We're here to help!	f	\N	["naturemania_company.txt", "products_general_wellness.txt"]	\N	\N
104	guest_1765532526825_0o345z1jq	2025-12-12 09:44:14.143299	is this harmful	[Lift-Up Oil](https://naturemania.in/products/lift-up-oil) is made with 100% Ayurvedic ingredients and does not contain any harmful additives or chemicals. It is formulated to support natural male enhancement and is designed for external topical application. \n\nThat said, we always recommend doing a patch test before trying any new product on your skin. If you have any specific health concerns or conditions, it's best to consult with a qualified healthcare professional.\n\nFor more details about Lift-Up Oil, check it out here: [Lift-Up Oil](https://naturemania.in/products/lift-up-oil). \n\nIf you have other questions or need assistance, feel free to reach out to us!	f	\N	["products_lift_up.txt", "products_women_wellness.txt", "products_sexual_health.txt"]	\N	\N
105	guest_1765532526825_0o345z1jq	2025-12-12 09:44:46.959035	is it safe with perm up capsule?	Yes, using [Lift-Up Oil](https://naturemania.in/products/lift-up-oil) alongside [Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule) is considered safe. Both products are formulated with 100% Ayurvedic ingredients and work synergistically to support male enhancement and performance.\n\n- **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)** promotes blood circulation and natural enlargement through external application.\n- **[Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule)** help with premature discharge and enhance control during intimacy.\n\nFor optimal results, it's best to use these products consistently. However, if you have specific health concerns or conditions, we always recommend consulting with a qualified healthcare professional.\n\nIf you’d like to know more or have further questions, feel free to reach out to us!	f	\N	["products_lift_up.txt", "products_sexual_health.txt"]	\N	\N
106	guest_1765532526825_0o345z1jq	2025-12-12 09:45:02.736229	hindi me batao	Haan, [Lift-Up Oil](https://naturemania.in/products/lift-up-oil) aur [Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule) ka sath mein istemal karna safe hai. Dono products 100% Ayurvedic ingredients se bane hain aur ye male enhancement aur performance ko support karne ke liye synergistically kaam karte hain.\n\n- **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)** blood circulation ko promote karta hai aur external application ke through natural enlargement mein madad karta hai.\n- **[Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule)** premature discharge se bachne aur intimacy ke dauran control badhane mein madad karte hain.\n\nBehtar results ke liye, in products ka istemal regular basis par karna acha rahega. Lekin agar aap ke paas specific health concerns hain, toh hum hamesha recommend karte hain ki ek qualified healthcare professional se sampark karein.\n\nAgar aapko aur information chahiye ya koi aur sawaal hai, toh humse bina jhijhak sampark karein!	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "products_sexual_health.txt"]	\N	\N
107	guest_1765532526825_0o345z1jq	2025-12-12 09:45:32.065893	sperm badhane ke liye konsa product lu?	Sperm badhane ke liye, aap **[Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules)** le sakte hain. Ye capsules energy, stamina, aur male vitality ko boost karne ke liye design kiye gaye hain, jo natural enhancement mein madad karte hain.\n\n**Product Details:**\n- **Price:** Rs. 1,499 (pehle Rs. 1,699 - 12% off!)\n- **Size:** 60 capsules\n\n**Key Benefits:**\n- Energy levels ko badhata hai\n- Stamina aur endurance improve karta hai\n- Natural size enhancement ko support karta hai\n- Overall performance ko enhance karta hai\n- 100% Ayurvedic ingredients \n\nIs product ka istemal karne se aapko better results mil sakte hain agar aap ise 2-3 mahine tak regular basis par lete hain.\n\nAgar aapko aur information chahiye, toh yahan dekhein: [Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules). \n\nAgar aapke aur sawaal hain, toh humse sampark karein!	f	\N	["products_lift_up.txt", "blog_articles.txt", "products_sexual_health.txt"]	\N	\N
108	guest_1765532526825_0o345z1jq	2025-12-12 09:45:54.84518	is se sar me dard to nahin hoga na ?	Humare **[Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules)** mein 100% Ayurvedic ingredients hain, jo generally safe hote hain aur inka koi major side effect nahi hota. Lekin, har vyakti ki body alag hoti hai aur kuch logon ko kisi bhi nayi supplement se pehle sensitivity ho sakti hai.\n\nAgar aapko kisi bhi product ko lene ke baad sar dard ya aur kisi tarah ki samasya mehsoos hoti hai, toh turant product ka istemal band karein aur ek qualified healthcare professional se sampark karen.\n\nAam taur par, [Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules) ka istemal karne se sar mein dard hona nahi chahiye, lekin agar aapko kisi tarah ki chinta hai, toh hamesha achha hai ki doctor se salah lein. \n\nAgar aapko aur information ki zarurat hai, toh humein batayein!	f	\N	["products_sexual_health.txt", "naturemania_company.txt", "products_general_wellness.txt"]	\N	\N
109	guest_1765532526825_0o345z1jq	2025-12-12 09:46:16.571483	isko konsa doctor promote karta hai?	For information about discounts, special offers, or bulk orders, please contact our team directly:\n\n**Phone:** 75092-76000\n**Email:** enquiry@naturemania.in\n\nOur team will be happy to assist you with any pricing inquiries!\n\nIn the meantime, you can also enjoy **Extra 5% Off on Prepaid Orders** on all products. Would you like to know more about any of our products?	t	\N	\N	\N	\N
110	guest_1765532526825_0o345z1jq	2025-12-12 09:46:33.605491	doctor batao	Humare products, jaise ki **[Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules)**, experienced Ayurvedic doctors ke dwara formulate kiye gaye hain. Humara team sirf 100% Ayurvedic ingredients ka hi istemal karta hai, jisse in products ki effectiveness aur safety ka dhyan rakha jata hai.\n\nSpecific doctor ka naam nahi diya gaya hai, lekin humare products ko Ayurvedic doctors ke expertise ke saath banaya gaya hai, jo inki quality aur effectiveness ko ensure karte hain.\n\nAgar aapko kisi particular doctor ke recommendation ya aur kisi detail ki zarurat hai, toh aap hume **[yahan sampark kar sakte hain](https://naturemania.in/pages/contact)** ya **75092-76000** par call kar sakte hain. Hum aapki madad karne ke liye yahan hain!	f	\N	["naturemania_company.txt", "products_general_wellness.txt", "products_sexual_health.txt"]	\N	\N
111	guest_1765533455804_7dcg8qc39	2025-12-12 09:57:45.468904	Hello	Hi there! We're glad to see you here at Nature Mania. What can we assist you with today? Are you looking for information about our Ayurvedic products or do you need help in choosing the right wellness solution?\n\n---\n\n*Feel free to explore more when you're ready:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_lift_up.txt", "naturemania_company.txt", "products_general_wellness.txt"]	\N	\N
112	guest_1765533455804_7dcg8qc39	2025-12-12 09:57:54.737795	who are you	We are NIRA, your friendly assistant here at Nature Mania! Our team specializes in guiding you through our range of Ayurvedic wellness products, helping you find the right solutions for your needs. If you have any questions or need information, feel free to ask! \n\n---\n\n*Explore our products here:*  \n[Shop All](https://naturemania.in/collections/all)	f	\N	["naturemania_company.txt", "products_sexual_health.txt", "products_general_wellness.txt"]	\N	\N
113	guest_1765533455804_7dcg8qc39	2025-12-12 09:58:15.180699	what do you know about ayurveda	Ayurveda is an ancient Indian system of medicine that focuses on holistic health and well-being. It emphasizes the balance between the body, mind, and spirit, utilizing natural herbs, diet, and lifestyle changes to promote wellness. The core principles of Ayurveda include:\n\n1. **Five Elements**: Everything in the universe, including the human body, is made up of five elements: earth, water, fire, air, and ether. These elements combine to form three primary energies or doshas: Vata, Pitta, and Kapha.\n\n2. **Doshas**: Each individual has a unique balance of these doshas, which determines their physical and mental characteristics. Ayurvedic treatments aim to restore balance to these doshas to achieve optimal health.\n\n3. **Natural Remedies**: Ayurveda uses natural ingredients, such as herbs, plants, minerals, and dietary recommendations, to promote healing and prevent disease. \n\n4. **Lifestyle Practices**: Ayurveda encourages a healthy lifestyle that includes proper diet, exercise, yoga, meditation, and stress management to maintain overall well-being.\n\n5. **Personalized Approach**: Ayurveda takes into account each person’s unique constitution, health history, and lifestyle, making the approach highly individualized.\n\nAt Nature Mania, we offer a range of Ayurvedic supplements designed to support various aspects of health and wellness using traditional formulations.\n\nIf you’re interested in exploring any specific Ayurvedic products, let us know!\n\n---\n\n*You can view our products here:*  \n[Shop All](https://naturemania.in/collections/all)	f	\N	["naturemania_company.txt", "products_sexual_health.txt", "products_lift_up.txt"]	\N	\N
114	guest_1765548645708_fhwunxsga	2025-12-12 14:12:12.776551	what products do you sell	We offer a variety of Ayurvedic products that support wellness and enhancement. Here’s a list of our main products:\n\n1. **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)** (30ml) - Rs. 999 (was Rs. 1,799 - 44% off)  \n   [View Product](https://naturemania.in/products/lift-up-oil)\n\n2. **[Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules)** (60 caps) - Rs. 1,499 (was Rs. 1,699 - 12% off)  \n   [View Product](https://naturemania.in/products/lift-up-capsules)\n\n3. **[Size Combo](https://naturemania.in/products/size-combo)** - Rs. 2,700 (was Rs. 2,998 - 9% off)  \n   [View Product](https://naturemania.in/products/size-combo)\n\n4. **[Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule)** (60 caps) - Rs. 1,312 (was Rs. 1,399 - 6% off)  \n   [View Product](https://naturemania.in/products/perm-up-capsule)\n\n5. **[Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule)** (60 caps) - Rs. 1,031 (was Rs. 1,099 - 6% off)  \n   [View Product](https://naturemania.in/products/tes-up-capsule)\n\n6. **[Shilajit Gold Resin](https://naturemania.in/products/nature-mania-shilajit-gold-resin)** (20gm) - Rs. 1,171 (was Rs. 1,249 - 6% off)  \n   [View Product](https://naturemania.in/products/nature-mania-shilajit-gold-resin)\n\n7. **[Cup-Up Capsules](https://naturemania.in/products/cup-up-capsules)** (60 caps) - Rs. 843 (was Rs. 899 - 6% off)  \n   [View Product](https://naturemania.in/products/cup-up-capsules)\n\n8. **[Soothe-Up Capsules](https://naturemania.in/products/soothe-up-capsule)** (60 caps) - Rs. 749 (was Rs. 799 - 6% off)  \n   [View Product](https://naturemania.in/products/soothe-up-capsule)\n\n9. **[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)** (60 caps) - Rs. 1,218 (was Rs. 1,299 - 6% off)  \n   [View Product](https://naturemania.in/products/vit-up-capsule)\n\n10. **[Smart Shaping Powder](https://naturemania.in/products/nature-mania-smart-shaping-powder)** (30 sachets) - Rs. 2,249 (was Rs. 3,699 - 39% off)  \n    [View Product](https://naturemania.in/products/nature-mania-smart-shaping-powder)\n\nYou can check out all of our products [here](https://naturemania.in/collections/all). We also provide **Extra 5% Off on Prepaid Orders** and **Free Shipping across India**! If you have any more questions, feel free to reach out!	f	\N	["naturemania_company.txt", "products_general_wellness.txt", "products_lift_up.txt"]	\N	\N
145	guest_1765825622650_3ucc9mbjx	2025-12-15 19:07:28.204812	hi	Hey there! 👋 I'm GRESTA, your guide at GREST — India's trusted destination for premium refurbished [iPhones](https://grest.in/collections/iphones) and [MacBooks](https://grest.in/collections/macbook). Whether you're looking for a specific model, curious about our quality checks, or need help choosing the right device, I'm here to help! What can I assist you with today?	f	\N	["https://grest.in/collections/iphone-12-refurbished", "grest_product_catalog.txt", "https://grest.in/pages/contact-us"]	\N	\N
115	guest_1765548645708_fhwunxsga	2025-12-12 14:12:38.224186	what are the most common problems that your customers come with	We receive inquiries about a variety of wellness concerns from our customers. While we do not provide medical advice, some of the most common topics include:\n\n1. **Intimate Wellness:** Many customers seek products for enhancing male and female intimate wellness, looking for natural solutions to enhance size and performance.\n\n2. **Energy and Stamina:** A significant number of inquiries revolve around boosting energy levels and improving overall stamina and endurance.\n\n3. **Hormonal Balance:** Customers often ask about support for hormonal balance, especially related to women's wellness.\n\n4. **Natural Enhancement:** Many individuals look for natural enhancement solutions, seeking alternatives to surgical procedures.\n\n5. **General Health and Well-Being:** Questions about improving overall vitality and health are common, where customers inquire about natural supplements that can support their lifestyle.\n\nFor specific product recommendations or personalized solutions, feel free to contact us! We’re here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule) | [Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules) | [Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)	f	\N	["products_lift_up.txt", "products_women_wellness.txt"]	\N	\N
116	guest_1765548645708_fhwunxsga	2025-12-12 14:17:00.996611	mere raat akele hai. kya karoon	Akele hone par aap kuch activities kar sakte hain jo aapko relax aur entertained rakhengi. Yahan kuch suggestions hain:\n\n1. **Padhai karein:** Aap apne favourite book, article, ya blog padh sakte hain.\n\n2. **Movie ya Series dekhein:** Apne pasand ki movie ya web series dekhna ek accha option hai.\n\n3. **Music suno:** Aap apne favourite songs ya playlists sun sakte hain jo aapko khush karein.\n\n4. **Meditation karein:** Thoda time meditation ya deep breathing exercises mein bhi laga sakte hain, yeh aapko shanti aur relaxation de sakta hai.\n\n5. **Cooking karein:** Agar aapko cooking ka shauk hai, toh naye recipes try karne ka waqt hai!\n\n6. **Writing ya Journaling:** Apne khayalon ko likhna shant kar sakta hai aur aapko clarity de sakta hai.\n\n7. **Online Community se judain:** Social media ya online forums par friends se baat karein ya naye logon se milein.\n\nAgar aap kisi specific samasya ya baat ke liye discuss karna chahte hain, toh aap hamesha humse contact kar sakte hain. Hum yahaan madad karne ke liye hain!\n\n---\n\n*Here are some products that align with what we discussed:*\n[Soothe-Up Capsules](https://naturemania.in/products/soothe-up-capsule)	f	\N	["products_general_wellness.txt", "naturemania_company.txt", "products_sexual_health.txt"]	\N	\N
117	guest_1765603737321_wg66dx7ww	2025-12-13 05:29:42.812884	i want to lift up oil	[Lift-Up Oil](https://naturemania.in/products/lift-up-oil) is our natural men's organ massage oil designed to promote blood circulation and support natural enhancement.\n\n**Price:** Rs. 999 (originally Rs. 1,799 - 44% off!)  \n**Size:** 30ml  \n\n**Key Benefits:**\n- Promotes blood circulation\n- Supports natural enlargement\n- Improves stamina and performance\n- Made with Ayurvedic herbs like Ashwagandha, Safed Musli, and Shatavari\n- 100% Ayurvedic, AYUSH Certified\n\n**How to Use:** Apply the oil and massage gently for 10-15 minutes daily for the best results.\n\nCheck it out here: [Lift-Up Oil](https://naturemania.in/products/lift-up-oil)\n\nDon't forget, we provide **Extra 5% Off on Prepaid Orders** and **Free Shipping across India!**	f	\N	["products_lift_up.txt", "blog_articles.txt"]	\N	\N
118	guest_1765603737321_wg66dx7ww	2025-12-13 05:32:46.938177	how many doctors told about lift-up oil	We don't have specific information about how many doctors recommend [Lift-Up Oil](https://naturemania.in/products/lift-up-oil). However, our Ayurvedic products are designed with natural ingredients and are AYUSH Certified, making them a popular choice for many looking for enhancement solutions. \n\nFor personal health concerns or recommendations regarding our products, we suggest consulting with a qualified healthcare professional. If you need more details about Lift-Up Oil or have any other queries, feel free to ask or you can also [contact us](https://naturemania.in/pages/contact). \n\nHere’s the link to the product for more information: [Lift-Up Oil](https://naturemania.in/products/lift-up-oil).	f	\N	["products_lift_up.txt", "products_women_wellness.txt"]	\N	\N
119	guest_1765604634749_atl3y5g12	2025-12-13 05:44:00.645462	hi	Hi there! I'm NIRA, your guide here at Nature Mania. What brings you here today? Whether you're looking for information about our Ayurvedic products or need help choosing the right solution, I'm happy to help!\n\n---\n\n*If you'd like to learn more, these might interest you:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "naturemania_company.txt"]	\N	\N
120	guest_1765780284395_9dkpz2v4p	2025-12-15 06:32:10.929018	guide me how to eat gummies	It seems we currently specialize in Ayurvedic supplements and do not offer gummies as part of our product range. However, if you're looking for guidance on our products, like herbal capsules or oils, we'd be happy to help!\n\nYou can explore our offerings here: [All Products](https://naturemania.in/collections/all).\n\nIf you have specific health concerns or questions, feel free to contact us at [Contact Us](https://naturemania.in/pages/contact) or call us at 75092-76000. We're here to assist you!	f	\N	["products_lift_up.txt", "blog_articles.txt", "products_sexual_health.txt"]	\N	\N
121	guest_1765780284395_9dkpz2v4p	2025-12-15 06:32:34.850817	ok tell me how can i take test up	The [Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule) are designed to boost natural testosterone levels and support overall male health. Here's how you can take them:\n\n**Dosage:**\n- Take one capsule in the morning and one in the evening with lukewarm water after meals. \n\n**Recommendation:**\n- For best results, use regularly for 60-90 days.\n\n**Price:** Rs. 1,031 (was Rs. 1,099 - 6% off)\n\nYou can check out the Tes-Up Capsules here: [Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule).\n\nIf you have any further questions or need assistance, feel free to contact us!	f	\N	["products_sexual_health.txt", "products_women_wellness.txt", "blog_articles.txt"]	\N	\N
122	guest_1765780284395_9dkpz2v4p	2025-12-15 06:32:59.727777	is test up a unisex product	The [Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule) are specifically formulated for male health and are designed to boost natural testosterone levels, increase energy and vitality, and enhance overall male performance. Therefore, it is not considered a unisex product.\n\nIf you have any additional questions or need information about products suitable for women's wellness, please let us know! You can also explore our full range of products here: [All Products](https://naturemania.in/collections/all).	f	\N	["products_sexual_health.txt", "products_women_wellness.txt", "blog_articles.txt"]	\N	\N
123	guest_1765793928478_2684tvwzy	2025-12-15 10:19:48.44321	so you have any product called Gummies?	We don't have any products specifically called Gummies in our range. However, we offer a variety of Ayurvedic supplements designed for different wellness needs. If you're looking for something specific or need help finding a product that meets your needs, please let us know! You can check out all of our products here: [All Products](https://naturemania.in/collections/all). \n\nIf you have any specific concerns or questions, feel free to contact us!	f	\N	["products_general_wellness.txt", "products_sexual_health.txt"]	\N	\N
124	guest_1765794197733_7y06zuc6d	2025-12-15 10:23:45.029585	do you have any products for weight loss?	Yes, we have the [Smart Shaping Powder](https://naturemania.in/products/nature-mania-smart-shaping-powder), which is designed for weight loss and fat burning. \n\n**Product Details:**\n- **Name:** Nature Mania Smart Shaping Powder (Weight Loss, Fat Burner)\n- **Price:** Rs. 2,249 (was Rs. 3,699 - 39% off)\n- **Size:** Pack of 30 sachets (5gm each)\n\n**Key Benefits:**\n- Effective fat metabolism support\n- Increases energy and endurance\n- Aids in post-workout recovery\n- Contains L-carnitine for enhanced fat use as energy\n\n**How to Use:** Mix one sachet with 250ml chilled water, shake for 20-30 seconds, and drink. It's best consumed 30 minutes before a workout.\n\nYou can check it out here: [Smart Shaping Powder](https://naturemania.in/products/nature-mania-smart-shaping-powder).\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_general_wellness.txt", "blog_articles.txt"]	\N	\N
125	guest_1765796866310_ia3defcq8	2025-12-15 11:08:11.310827	do you have any product called Gummies?	Yes, we have a product called Lift-Up Gummies. They are power-packed with pure Himalayan Shilajit and come in a delicious Imli flavor. Each gummy is designed to support energy, stamina, and mood, making them a great addition to your daily routine.\n\n**Price:** Rs. 1,799\n**Quantity:** 60 Gummies\n\nKey benefits include:\n- Supports normal testosterone levels\n- Helps you feel less tired and more energized\n- Tasty and easy to consume\n- Sugar-free and made with safe natural ingredients\n\nYou can check them out here: [Lift-Up Gummies](https://naturemania.in/products/lift-up-gummies-imli-flavour-60n).\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["https://naturemania.in/products/lift-up-gummies-imli-flavour-60n"]	\N	\N
126	guest_1765813919562_20vt0n0ni	2025-12-15 16:14:29.803489	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	\N	\N	\N
127	guest_1765816735790_g0zx97uib	2025-12-15 16:39:06.549463	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	\N	\N	\N
128	guest_1765817388046_28zpp9sh4	2025-12-15 16:49:56.106074	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	\N	\N	\N
129	guest_1765817953721_mgdgetvkq	2025-12-15 16:59:26.286764	hi	Hey there! 👋 I'm GRESTA, your guide at GREST — India's trusted destination for premium refurbished [iPhones](https://grest.in/collections/iphones) and [MacBooks](https://grest.in/collections/macbook). Whether you're looking for a specific model, curious about our quality checks, or need help choosing the right device, I'm here to help! What can I assist you with today?	f	\N	["https://grest.in/collections/iphones", "https://grest.in/pages/contact-us", "https://grest.in/collections/all"]	\N	\N
130	guest_1765817953721_mgdgetvkq	2025-12-15 16:59:48.030494	do you have iPhone 16?	Currently, we don't have the [iPhones](https://grest.in/collections/iphones) 16 in our collection. 😔 We specialize in premium refurbished models like the iPhone 12, 13, 14, and 15 series. \n\nIf you're interested in any of those models, I can provide you with their prices and features! Would you like to explore those options?	f	\N	["https://grest.in/pages/contact-us", "https://grest.in/collections/macbook", "https://grest.in/blogs/news"]	\N	\N
131	guest_1765818660499_1mo3u98xn	2025-12-15 17:11:11.930515	hi	Hey there! 👋 I'm GRESTA, your guide at GREST — India's trusted destination for premium refurbished [iPhones](https://grest.in/collections/iphones) and [MacBooks](https://grest.in/collections/macbook). Whether you're looking for a specific model, curious about our quality checks, or need help choosing the right device, I'm here to help! What can I assist you with today?	f	\N	["grest_product_catalog.txt", "https://grest.in/cdn/shop/t/72/assets/global.css", "https://grest.in/cdn/shop/t/72/assets/base.css"]	\N	\N
132	guest_1765818660499_1mo3u98xn	2025-12-15 17:11:25.960508	do you have iPhone 12?	Yes, we have the [iPhones](https://grest.in/collections/iphones) 12 available! 📱 \n\n- **Starting Price**: ₹19,999\n- **Storage Options**: 64GB, 128GB, 256GB\n- **Display**: 6.1" Super Retina XDR\n- **Processor**: A14 Bionic\n\nAll our iPhones come with a 12-month warranty and have passed over 50 quality checks! You can check out more details and shop [here](https://grest.in/products/iphone-12).\n\nWould you like help with anything else?	f	\N	["grest_product_catalog.txt", "https://grest.in/pages/faqs"]	\N	\N
133	guest_1765820352596_tuxh4x7ba	2025-12-15 17:39:26.138404	hi	Hey there! 👋 I'm GRESTA, your guide at GREST — India's trusted destination for premium refurbished [iPhones](https://grest.in/collections/iphones) and [MacBooks](https://grest.in/collections/macbook). Whether you're looking for a specific model, curious about our quality checks, or need help choosing the right device, I'm here to help! What can I assist you with today?	f	\N	["grest_product_catalog.txt", "https://grest.in/collections/iphone-12-refurbished", "https://grest.in/pages/contact-us"]	\N	\N
134	guest_1765820352596_tuxh4x7ba	2025-12-15 17:39:51.150356	where is your office located? (no changes needed)	I don't have that specific information, but you can always reach out to us at [our contact page](https://grest.in/pages/contact-us) for more details. How else can I assist you today?	f	\N	["https://grest.in/collections/iphone-12-refurbished", "https://grest.in/policies/refund-policy", "https://grest.in/pages/about"]	\N	\N
135	guest_1765820803887_gpr7wcuqr	2025-12-15 17:46:57.968414	hi	Hey there! 👋 I'm GRESTA, your guide at GREST — India's trusted destination for premium refurbished [iPhones](https://grest.in/collections/iphones) and [MacBooks](https://grest.in/collections/macbook). Whether you're looking for a specific model, curious about our quality checks, or need help choosing the right device, I'm here to help! What can I assist you with today?	f	\N	["https://grest.in/collections/iphone-12-refurbished", "grest_product_catalog.txt", "https://grest.in/pages/contact-us"]	\N	\N
136	guest_1765820803887_gpr7wcuqr	2025-12-15 17:47:11.865007	aapka office kaha hai?	Hamara office Gurugram, Haryana mein hai. 📍\n\n**Office Address:**\nKhasra No. 34/22, 1st Floor, NK Tower, Kanhai Road, Sector-45, Gurugram, Haryana-122003\n\nAgar aapko aur koi jaanakari chahiye ya koi sawaal hai, toh pooch sakte hain!	f	\N	["grest_product_catalog.txt", "grest_contact_info.txt", "https://grest.in"]	\N	\N
137	guest_1765820803887_gpr7wcuqr	2025-12-15 17:47:50.907876	what is your return policy? (no changes needed)	Our return policy is designed to make it easy for you! Here's a quick overview:\n\n1. **Return/Replacement Initiation**:\n   - You can place a replacement request within 7 days of order delivery.\n   - For damaged or missing products, the return request should be filed within 48 hours of delivery.\n\n2. **Conditions for Return/Replacement**:\n   - Wrong Product: Wrong color/size/style.\n   - Defective Product: Manufacturing defect/non-functioning.\n   - Damaged Product: Physical damage/tampered packaging.\n   - Wrong Quantity: Missing products/parts.\n\n3. **Conditions Not Accepted**:\n   - Altered/Used Products.\n   - Products returned without original packaging (price tags, labels, accessories).\n   - Tampered serial numbers.\n   - Defective products reported after 7 days.\n\n4. **Return Process**:\n   - Initiate the return by calling +91 9818 925 900 or email info@Grest.in.\n   - A pickup will be arranged through our courier partners after approval.\n\nFor more details, you can check our full policy here: [Refund Policy](https://grest.in/policies/refund-policy). If you have any specific queries about a return, feel free to ask!	f	\N	["https://grest.in/policies/refund-policy", "https://grest.in/products/iphone-16"]	\N	\N
138	guest_1765820803887_gpr7wcuqr	2025-12-15 17:48:41.128263	aap kitni warranty dete ho?	Hum apne sabhi products par **12 mahine ki warranty** dete hain! 🛡️\n\nYeh warranty hardware issues ko cover karti hai, jisse aapko peace of mind milta hai ki aapka device reliable hai. Agar aapko kisi tareeke se issue hota hai, toh aap hamesha humein sampark kar sakte hain, aur hum aapki madad karenge. \n\nAur haan, sabhi devices 50+ quality checks se guzarne ke baad aate hain! Agar aapko aur koi jaanakari chahiye, toh zaroor poochiye.\n\n---\n\n*Feel free to explore more:*\n[Warranty](https://grest.in/pages/warranty-policy) | [FAQs](https://grest.in/pages/faqs)	f	\N	["https://grest.in", "https://grest.in/blogs/news/trade-in-vs-buying-a-refurbished-iphone-which-route-gives-you-better-value", "https://grest.in/products/iphone-16"]	\N	\N
139	guest_1765822839334_c8e1zqaxa	2025-12-15 18:20:53.373676	hi	Hey there! 👋 I'm GRESTA, your guide at GREST — India's trusted destination for premium refurbished [iPhones](https://grest.in/collections/iphones) and [MacBooks](https://grest.in/collections/macbook). Whether you're looking for a specific model, curious about our quality checks, or need help choosing the right device, I'm here to help! What can I assist you with today?	f	\N	["https://grest.in/collections/iphone-12-refurbished", "grest_product_catalog.txt", "https://grest.in/pages/contact-us"]	\N	\N
140	guest_1765822839334_c8e1zqaxa	2025-12-15 18:37:21.420162	what is your return policy?	Our return policy is designed to make things easy for you! Here's how it works: \n\n1. **Replacement Requests**: You can initiate a return within **7 days** of receiving your order. If you received a damaged or missing product, please file the return request within **48 hours**.\n\n2. **Conditions for Return**: We accept returns if:\n   - You received the wrong product (like wrong color or size).\n   - The product is defective or non-functioning.\n   - The product is physically damaged or tampered with.\n   - There’s a missing item or part.\n\n3. **Conditions for Non-Acceptance**: Returns won't be accepted if:\n   - The product is used or altered.\n   - The original packaging (price tags, labels & accessories) is missing.\n   - The serial number is tampered with.\n   - Defective products reported after 7 days.\n\n4. **Process**: \n   - Call us at +91 9818 925 900 or email info@Grest.in to start the replacement process.\n   - Once approved, we arrange for pickup at no additional cost, or we can reimburse you up to ₹150 for shipping if you choose to send it back yourself.\n\n5. **Warranty**: If you're facing issues under warranty after the return period, just contact us for support!\n\nFor further details or to start a return, feel free to reach out at our [Contact Page](https://grest.in/pages/contact-us). We're here to help! 😊	f	\N	["https://grest.in/policies/refund-policy", "https://grest.in/products/iphone-16"]	\N	\N
141	guest_1765822839334_c8e1zqaxa	2025-12-15 18:37:54.538113	what warranty do you offer	We offer an amazing **12-month warranty** on all our products! 🛡️ This means that any hardware issues that arise within a year from your purchase date are covered, ensuring your peace of mind.\n\nHere's what you can expect with our warranty:\n\n- **Coverage**: The warranty covers hardware issues due to manufacturing defects.\n- **Quality Assurance**: Our devices undergo **50+ quality checks** before shipping, ensuring they meet high standards.\n- **7-Day Replacement**: If you're not satisfied with your device, you have a hassle-free 7-day replacement option.\n\nFeel free to explore our [products](https://grest.in/collections/[iPhones](https://grest.in/collections/iphones)) knowing that you're backed by our comprehensive warranty! If you have any more questions or need assistance, just let us know! 🌟	f	\N	["https://grest.in/blogs/news/trade-in-vs-buying-a-refurbished-iphone-which-route-gives-you-better-value", "https://grest.in/products/iphone-16", "https://grest.in/blogs/news/best-time-season-to-buy-a-refurbished-iphone-in-india-festival-deals-to-year-end-discounts"]	\N	\N
142	guest_1765824912586_raryfoi3z	2025-12-15 18:55:25.833412	hi	Hey there! 👋 I'm GRESTA, your guide at GREST — India's trusted destination for premium refurbished [iPhones](https://grest.in/collections/iphones) and [MacBooks](https://grest.in/collections/macbook). Whether you're looking for a specific model, curious about our quality checks, or need help choosing the right device, I'm here to help! What can I assist you with today?	f	\N	["https://grest.in/collections/iphone-12-refurbished", "grest_product_catalog.txt", "https://grest.in/pages/contact-us"]	\N	\N
143	guest_1765824912586_raryfoi3z	2025-12-15 18:55:42.375893	what warranty do you offer	Great question! 💪 We provide a **12-month warranty** on all our refurbished products. This means if you encounter any hardware issues within a year of your purchase, you’re covered! \n\nAdditionally, all our devices go through **50+ quality checks**, ensuring you get a reliable product. Plus, we have a **7-day replacement policy** if you're not satisfied for any reason.\n\nIf you have more questions or need help with specific products, feel free to ask!\n\n---\n\n*Feel free to explore more:*\n[Warranty](https://grest.in/pages/warranty-policy) | [FAQs](https://grest.in/pages/faqs)	f	\N	["https://grest.in/blogs/news/trade-in-vs-buying-a-refurbished-iphone-which-route-gives-you-better-value", "https://grest.in/products/iphone-16", "https://grest.in/blogs/news/best-time-season-to-buy-a-refurbished-iphone-in-india-festival-deals-to-year-end-discounts"]	\N	\N
144	test123	2025-12-15 18:58:38.090792	what warranty do you offer	We offer a standard 6-month warranty on all our [iPhones](https://grest.in/collections/iphones) and [MacBooks](https://grest.in/collections/macbook), starting from the date of purchase. Additionally, you can extend this warranty for another 6 months at just ₹1,499, giving you a total coverage of up to 12 months!\n\nOur warranty covers:\n- Software issues\n- Functional problems (like speaker, microphone, and performance glitches)\n- Hardware issues arising from manufacturing defects\n\nPlease note that physical damage, display damage, water damage, unauthorized repairs, and accessories (like chargers and cables) are not covered under our warranty.\n\nFor any warranty service claims, you can easily reach out to us at https://grest.in/pages/contact-us.\n\nIf you have any more questions, feel free to ask! 🤗	f	\N	["grest_warranty_policy.txt", "https://grest.in/pages/faqs", "https://grest.in/products/iphone-16"]	\N	\N
146	guest_1765825622650_3ucc9mbjx	2025-12-15 19:07:43.942576	what warranty do you offer?	Great question! 😊 At GREST, we provide a **12-month warranty** on all our refurbished devices. This means that if you face any hardware issues within a year of purchase, you're covered!\n\nAdditionally, all our products undergo **50+ quality checks** to ensure performance and safety. We also offer a **7-day replacement policy** if you’re not satisfied after receiving your device. \n\nSo, you can shop confidently knowing you're protected! If you have more questions or need help with anything else, just let me know!\n\n---\n\n*Browse more options here:*\n[Warranty](https://grest.in/pages/warranty-policy) | [FAQs](https://grest.in/pages/faqs)	f	\N	["https://grest.in/blogs/news/trade-in-vs-buying-a-refurbished-iphone-which-route-gives-you-better-value", "https://grest.in/products/iphone-16", "https://grest.in/pages/faqs"]	\N	\N
147	debug_test_1765825820	2025-12-15 19:10:28.382273	what warranty do you offer	We offer a comprehensive 12-month warranty for all our [iPhones](https://grest.in/collections/iphones) and [MacBooks](https://grest.in/collections/macbook) that you purchase from us! Here's a quick overview of the warranty details:\n\n- **Duration**: 6 months standard warranty which can be extended for an additional 6 months at ₹1,499.\n- **Coverage**: Our warranty covers software issues, functional problems (like speaker and performance glitches), and hardware issues due to manufacturing defects.\n- **Not Covered**: Physical, display, or water damage, and unauthorized repairs are not covered.\n- **Hassle-Free Claim**: You can easily raise a warranty request through our customer support via phone, email, or our website.\n\nYour warranty is valid across India, ensuring you get the support you need no matter where you are!\n\nFeel free to ask if you have more questions about our warranty or anything else! 😊	f	\N	["grest_warranty_policy.txt", "https://grest.in/pages/faqs", "https://grest.in/products/iphone-16"]	\N	\N
148	final_test_1765825978	2025-12-15 19:13:08.865552	what warranty do you offer	We offer a comprehensive 12-month warranty on all our products! This includes a standard 6-month warranty, which you can extend for an additional 6 months at just ₹1,499. \n\nOur warranty covers:\n- Software issues\n- Functional problems like speaker, microphone, and performance glitches\n- Hardware issues due to manufacturing defects\n\nHowever, it does not cover:\n- Physical damage\n- Display damage\n- Water damage\n- Unauthorized repairs\n\nYou can raise a warranty request easily through our customer support. We're here to ensure your purchasing experience is worry-free! If there's anything else you'd like to know, feel free to ask! 😊 \n\nFor more details, you can also check our [Warranty Policy Page](https://grest.in/pages/warranty-policy).	f	\N	["grest_warranty_policy.txt", "https://grest.in/pages/faqs", "https://grest.in/policies/refund-policy"]	\N	\N
149	guest_1765826102529_dyhrrh2zo	2025-12-15 19:16:33.868398	HI	Hey there! 👋 I'm GRESTA, your guide at GREST — India's trusted destination for premium refurbished [iPhones](https://grest.in/collections/iphones) and [MacBooks](https://grest.in/collections/macbook). Whether you're looking for a specific model, curious about our quality checks, or need help choosing the right device, I'm here to help! What can I assist you with today?	f	\N	["https://grest.in/collections/iphone-12-refurbished", "grest_product_catalog.txt", "https://grest.in/pages/contact-us"]	\N	\N
150	guest_1765826102529_dyhrrh2zo	2025-12-15 19:16:53.013488	WHAT IS the warranty you offer? (no changes needed)	We offer a 12-month warranty on all our products. This warranty covers any hardware issues, ensuring you have peace of mind with your purchase. Additionally, every device goes through a rigorous 50+ quality checks to make sure it meets our high standards.\n\nIf you need more specific details or have any other questions, feel free to ask! 😊\n\n---\n\n*Browse more options here:*\n[Warranty](https://grest.in/pages/warranty-policy) | [FAQs](https://grest.in/pages/faqs)	f	\N	["https://grest.in/blogs/news/trade-in-vs-buying-a-refurbished-iphone-which-route-gives-you-better-value", "grest_product_catalog.txt", "https://grest.in/blogs/news/why-refurbished-macbooks-are-a-smart-investment-for-freelancers-startups"]	\N	\N
151	authority_test_1765826677	2025-12-15 19:24:48.069109	what warranty do you offer	Every [iPhones](https://grest.in/collections/iphones) and [MacBooks](https://grest.in/collections/macbook) we sell comes with a 6-month warranty for complete peace of mind. Plus, you have the option to extend it for an additional 6 months at just ₹1,499, giving you a total potential coverage of 12 months! 🎉 \n\nOur warranty covers software issues and functional problems like speaker, microphone, and performance glitches. However, it doesn't cover physical damage, water damage, or unauthorized repairs.\n\nIf you have any questions about the warranty or need assistance, feel free to contact us!	f	\N	["grest_warranty_policy.txt", "https://grest.in/pages/faqs", "https://grest.in/policies/refund-policy"]	\N	\N
152	guest_1765826834545_3yw36gift	2025-12-15 19:27:29.269014	hi	Hey there! 👋 I'm GRESTA, your guide at GREST — India's trusted destination for premium refurbished [iPhones](https://grest.in/collections/iphones) and [MacBooks](https://grest.in/collections/macbook). Whether you're looking for a specific model, curious about our quality checks, or need help choosing the right device, I'm here to help! What can I assist you with today?	f	\N	["https://grest.in/collections/iphone-12-refurbished", "grest_product_catalog.txt", "https://grest.in/pages/contact-us"]	\N	\N
153	guest_1765826834545_3yw36gift	2025-12-15 19:27:47.968681	what warranty do you offer	Great question! 💪 We offer a **12-month warranty** on all our products. This means if you face any hardware issues within a year of purchase, we’ve got you covered! \n\nAdditionally, every device goes through **50+ quality checks** to ensure it meets our high standards, and we have a **7-day replacement policy** if you're not satisfied. If you need any more details or have specific questions, just let me know!\n\n---\n\n*Here are some helpful links:*\n[Warranty](https://grest.in/pages/warranty-policy) | [FAQs](https://grest.in/pages/faqs)	f	\N	["https://grest.in/blogs/news/trade-in-vs-buying-a-refurbished-iphone-which-route-gives-you-better-value", "https://grest.in/blogs/news/best-time-season-to-buy-a-refurbished-iphone-in-india-festival-deals-to-year-end-discounts", "https://grest.in/pages/faqs"]	\N	\N
154	final_check	2025-12-15 19:39:17.385018	what warranty do you offer	We offer a 6-month warranty on all our products, which can be extended to a total of 12 months for just ₹1,499. This warranty covers software issues, functional problems, and hardware issues due to manufacturing defects. \n\nHowever, it does not cover physical damage, display damage, water damage, or unauthorized repairs. \n\nIf you have any other questions or need assistance, feel free to contact us! 😊\n\n---\n\n*Browse more options here:*\n[Warranty](https://grest.in/pages/warranty-policy) | [FAQs](https://grest.in/pages/faqs)	f	\N	["grest_warranty_policy.txt", "https://grest.in/pages/faqs", "https://grest.in/policies/refund-policy"]	\N	\N
155	guest_1765828544577_2djanmznz	2025-12-15 19:56:03.454416	hi	Hey there! 👋 I'm GRESTA, your guide at GREST — India's trusted destination for premium refurbished [iPhones](https://grest.in/collections/iphones) and [MacBooks](https://grest.in/collections/macbook). Whether you're looking for a specific model, curious about our quality checks, or need help choosing the right device, I'm here to help! What can I assist you with today?	f	\N	["https://grest.in/collections/iphone-12-refurbished", "grest_product_catalog.txt", "https://grest.in/pages/contact-us"]	\N	\N
156	guest_1765828544577_2djanmznz	2025-12-15 19:56:17.715095	what warranty do you offer? (no changes needed)	Great question! 💪 We offer a **6-month warranty** on all our devices, starting from your purchase date. You can also extend this warranty for an additional 6 months for ₹1,499, giving you complete peace of mind.\n\nOur warranty covers software issues and functional problems like speaker, microphone, and performance glitches. If you face any issues, just reach out to us, and we’ll help you sort it out!\n\nIf you have any other questions, feel free to ask!\n\n---\n\n*Browse more options here:*\n[Warranty](https://grest.in/pages/warranty-policy) | [FAQs](https://grest.in/pages/faqs)	f	\N	["https://grest.in/blogs/news/trade-in-vs-buying-a-refurbished-iphone-which-route-gives-you-better-value", "grest_product_catalog.txt", "https://grest.in/blogs/news/why-refurbished-macbooks-are-a-smart-investment-for-freelancers-startups"]	\N	\N
157	guest_1765857346414_q61wmlet3	2025-12-16 03:59:11.136352	I feel tired all the time, what should I take? (no changes needed)	We understand that feeling tired all the time can be challenging. While our Ayurvedic products are designed to support overall wellness, we recommend consulting with a healthcare professional for personalized advice.\n\nHowever, we do have products that may help boost energy levels:\n\n1. **[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)** - These capsules are formulated to enhance energy, endurance, and overall vitality.\n   - **Price:** Rs. 1,218 (was Rs. 1,299 - 6% off)\n   - [Check it out here](https://naturemania.in/products/vit-up-capsule)\n\n2. **Power-Up Combo** - This combo helps in boosting stamina, power, and overall health with its natural ingredients.\n   - [Explore the Power-Up Combo](https://naturemania.in/products/power-up-combo)\n\nAdditionally, staying hydrated, maintaining a healthy diet, and ensuring adequate sleep can also contribute to improved energy levels.\n\nFor any specific health concerns, please consult a healthcare professional. If you need more information or want to discuss our products further, feel free to [contact us](https://naturemania.in/pages/contact)! \n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["blog_articles.txt", "products_sexual_health.txt", "https://naturemania.in/products/power-up-combo"]	\N	\N
158	guest_1765857346414_q61wmlet3	2025-12-16 03:59:53.086766	what's the difference between them and which one is the best	We have a couple of Ayurvedic products that can support energy levels, and here's a summary of their key differences:\n\n1. **[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)**:\n   - **Purpose:** Designed to enhance overall vitality and energy levels.\n   - **Ingredients:** Contains ingredients that support endurance and health.\n   - **Price:** Rs. 1,218 (was Rs. 1,299 - 6% off).\n\n2. **Power-Up Combo**:\n   - **Purpose:** This combo targets stamina and power, combining multiple products for a holistic approach to energy and vitality.\n   - **Ingredients:** A blend of herbs focused on boosting physical strength, endurance, and vitality.\n\nTo determine which one is best for you, it really depends on your specific needs. If you want a straightforward energy boost, **[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)** could be a great choice. However, if you're looking for a more comprehensive approach that targets different aspects of energy and stamina, the **Power-Up Combo** might be more suitable.\n\nFor more information on these products, please feel free to [check out Vit-Up Capsules here](https://naturemania.in/products/vit-up-capsule) and contact us if you have more questions!\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["https://naturemania.in/products/nature-mania-lift-up-oil-male-enhancer-lift-up-massage-oil", "https://naturemania.in/products/deaddiction-combo-for-men", "https://naturemania.in/products/nature-mania-regen-combo"]	\N	\N
159	guest_1765857346414_q61wmlet3	2025-12-16 04:00:24.193826	Which product gives faster results? (no changes needed)	When it comes to quicker results, the **[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)** are formulated to provide noticeable improvements in energy and vitality relatively quickly, as they are designed to enhance overall well-being, endurance, and stamina.\n\nMany users have reported experiencing increased energy levels and enhanced performance after using [Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule) for a short period. This makes it a popular choice for those looking for faster results.\n\n**Price:** Rs. 1,218 (was Rs. 1,299 - 6% off).\n\nWhile results can vary from person to person, if you're looking to boost your energy quickly, we suggest giving the Vit-Up Capsules a try.\n\nFor further inquiries or if you need assistance, don’t hesitate to [contact us](https://naturemania.in/pages/contact)! \n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["https://naturemania.in/products/vit-up-capsule"]	\N	\N
160	guest_1765857346414_q61wmlet3	2025-12-16 04:00:56.233231	Should I take it before or after food? (no changes needed)	For the **[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)**, it is recommended to take them after a meal for better absorption. This helps ensure that the active ingredients are effectively utilized by your body.\n\nIn general, it’s a good practice to take the capsules at the same time each day to maintain an even level of the active ingredients in your system.\n\nIf you have any further questions or need assistance, feel free to [contact us](https://naturemania.in/pages/contact)! \n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["https://naturemania.in/products/vit-up-capsule", "https://naturemania.in/products/perm-up-capsule", "https://naturemania.in/products/soothe-up-capsule"]	\N	\N
161	guest_1765858817878_fxk2jcg5t	2025-12-16 04:22:38.261224	for stress which product is useful	For stress relief, we recommend our **Relax-Up Combo**. This combo is designed to promote relaxation and calm the mind, making it suitable for individuals looking to reduce stress and anxiety.\n\n**Price:** Rs. 1,800 (originally Rs. 2,098)\n\nYou can check it out and purchase it here: [Relax-Up Combo](https://naturemania.in/products/relax-up-combo)\n\nThis combination utilizes natural ingredients to help you unwind and feel more at ease. If you'd like more information about any other specific products or have other queries, feel free to ask!\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["https://naturemania.in/products/relax-up-combo", "https://naturemania.in/products/deaddiction-combo-for-men", "https://naturemania.in/products/nature-mania-boost-up-combo-the-natural-booster-packpack"]	\N	\N
162	guest_1765858817878_fxk2jcg5t	2025-12-16 04:23:07.180142	any single product you have	For stress relief, we suggest our **[Soothe-Up Capsules](https://naturemania.in/products/soothe-up-capsule)**. These capsules are designed to improve sleep and help overcome anxiety and sadness.\n\n**Price:** Rs. 749 (originally Rs. 799)\n\nYou can find more details and purchase them here: [Soothe-Up Capsules](https://naturemania.in/products/soothe-up-capsule)\n\nIf you need more information about this product or anything else, just let us know! \n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["https://naturemania.in/products/nature-mania-regen-combo", "https://naturemania.in/products/cupupcream", "https://naturemania.in/products/vit-up-capsule"]	\N	\N
163	guest_1765858817878_fxk2jcg5t	2025-12-16 04:23:53.125218	then why you recommend combo first is it a way to try to sell to customer	We appreciate your feedback! We recommend the **Relax-Up Combo** because it includes multiple products that work synergistically for enhanced benefits in managing stress and promoting relaxation. However, we understand that some customers prefer single products.\n\nThe **[Soothe-Up Capsules](https://naturemania.in/products/soothe-up-capsule)** are indeed an excellent choice for focused stress relief, and they're a fantastic option if you're looking for something specific. Our team is here to provide the best options based on your needs, whether that's a combo or a single product.\n\nIf you have any more questions or need further assistance, please let us know! We're here to help. \n\nFor purchasing options, you can click here: [Soothe-Up Capsules](https://naturemania.in/products/soothe-up-capsule).\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["https://naturemania.in/products/soothe-up-capsule", "https://naturemania.in/products/power-up-combo", "https://naturemania.in/products/deaddiction-combo-for-men"]	\N	\N
164	guest_1765858817878_fxk2jcg5t	2025-12-16 04:25:21.804444	if a customer can take one medicine to cure his issue why you recommend so many medicines it is safe to intake that much supplements	Thank you for sharing that with me. However, I'm not able to provide medical advice, diagnose conditions, or make recommendations about medications or treatments.\n\nOur Ayurvedic products are natural wellness supplements and are not intended to diagnose, treat, cure, or prevent any disease. For any health-related concerns, please consult with a qualified healthcare professional who can give you personalized guidance.\n\nI'm happy to share information about Nature Mania's Ayurvedic products and their natural ingredients. Is there something specific about our products I can help you with?	t	\N	\N	\N	\N
165	guest_1765858817878_fxk2jcg5t	2025-12-16 04:26:42.077931	but you have to suggest in that way so that customer can easily agree	We understand the importance of making informed choices when it comes to wellness. Our approach is to provide a variety of Ayurvedic supplements that target different aspects of health and well-being. Each product is designed to serve specific needs and can be more effective when used in combination, based on individual requirements.\n\nFor instance, products like **[Soothe-Up Capsules](https://naturemania.in/products/soothe-up-capsule)** focus on stress relief, while others may target enhancement or energy. Customers can choose based on their personal preferences and wellness goals.\n\nIt's always a good idea for customers to evaluate what works best for them, and our team is here to support that journey. If you have specific concerns or goals in mind, we can help recommend the right products for you!\n\nFeel free to explore more about our offerings: [All Products](https://naturemania.in/collections/all).\n\nIf you have any further questions or need personalized recommendations, just ask! We're here to assist! \n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["https://naturemania.in/products/soothe-up-capsule", "https://naturemania.in/products/cup-up-capsules", "https://naturemania.in/products/tes-up-capsule"]	\N	\N
166	guest_1765858817878_fxk2jcg5t	2025-12-16 04:27:27.972951	if they can choose on their personal preference why need to ask you then	Great question! While customers can certainly choose based on personal preference, many people appreciate guidance in navigating the variety of products available. Our team is knowledgeable about the benefits and unique features of each product, which can help customers make informed decisions that align with their wellness goals.\n\nWe understand that everyone’s needs are different, so we aim to assist customers in finding the most suitable options for them. Our recommendations are based on understanding how our products work together and the specific benefits they offer. \n\nIf you'd like assistance in selecting products or if you have specific wellness goals, feel free to reach out. We’re here to help you find the right solutions for your health journey! \n\nYou can explore our products here: [All Products](https://naturemania.in/collections/all). \n\nAnd remember, you can reach out to us directly if you have any questions! \n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["https://naturemania.in/products/deaddiction-combo-for-men", "https://naturemania.in/products/pre-mature-combo", "https://naturemania.in/products/perm-up-capsule"]	\N	\N
167	guest_1765858817878_fxk2jcg5t	2025-12-16 04:28:03.962607	but you are not suggesting properly in that way	We appreciate your feedback and understand the need for clearer recommendations. Our goal is to help guide you to the right products based on your needs. \n\nFor example, if you're looking to reduce stress and improve relaxation, we recommend **[Soothe-Up Capsules](https://naturemania.in/products/soothe-up-capsule)**. They are designed to enhance pleasure during intimate activities and promote overall mental well-being.\n\nIf someone is concerned about energy and stamina in intimate moments, products like **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)** and **[Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules)** might be appropriate choices. \n\nHere’s a quick summary of a couple of options:\n\n1. **[Soothe-Up Capsules](https://naturemania.in/products/soothe-up-capsule)**\n   - **Price:** Rs. 749 (was Rs. 799 - 6% off)\n   - **Use:** Reduces stress and anxiety, enhances pleasure.\n   - **How to use:** Take one capsule twice a day with water, preferably after meals. \n\n2. **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)**\n   - **Price:** Rs. 999 (was Rs. 1,799 - 44% off)\n   - **Use:** Promotes blood circulation and enhances organ health.\n   - **How to use:** Apply and massage gently for 10-15 minutes daily.\n\nWe encourage customers to review these options and see what aligns best with their wellness goals. \n\nYou can view our complete range of products here: [All Products](https://naturemania.in/collections/all). \n\nIf you have further specific goals or questions, feel free to ask! We're dedicated to assisting you with your choices! \n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["https://naturemania.in/products/soothe-up-capsule", "products_sexual_health.txt"]	\N	\N
174	guest_1765858817878_fxk2jcg5t	2025-12-16 04:34:57.285716	is there any policy regarding not dispatching full cod order	We don't have specific information regarding policies about not dispatching full cash on delivery (COD) orders. For this kind of concern, we'd recommend reaching out to our customer support team directly, as they will have the most accurate and detailed information regarding our policies and procedures. \n\nYou can contact us at:\n- **Phone:** 75092-76000\n- **Email:** enquiry@naturemania.in\n\nThey'll be able to clarify any questions you have regarding COD orders and help resolve any issues you may be experiencing. \n\nThank you for your patience, and feel free to check our full product range here: [All Products](https://naturemania.in/collections/all).\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["https://naturemania.in/products/vit-up-capsule", "https://naturemania.in/products/tes-up-capsule", "https://naturemania.in/products/pre-mature-combo"]	\N	\N
168	guest_1765858817878_fxk2jcg5t	2025-12-16 04:28:59.052952	but you have not suggested me first soothe up capsule you suggested me the combo is it a cheap way to sell	We understand your concern. Our intention is to offer solutions that provide value to our customers, rather than simply promoting a specific product or combo. The De-Addiction Combo, which includes **[Soothe-Up Capsules](https://naturemania.in/products/soothe-up-capsule)** and **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)**, is presented as a combination that addresses both relaxation and enhancement in a cohesive manner. \n\nHowever, we also realize that some customers prefer to start with individual products based on their specific needs. \n\nIf relaxation and stress relief are your primary concerns, starting with the **[Soothe-Up Capsules](https://naturemania.in/products/soothe-up-capsule)** could be an excellent first choice. \n\n- **[Soothe-Up Capsules](https://naturemania.in/products/soothe-up-capsule)**\n  - **Price:** Rs. 749 (was Rs. 799 - 6% off)\n  - **Benefits:** Designed to help reduce stress and enhance the overall intimate experience.\n\nWe value your feedback and want to ensure we align our suggestions with your preferences and needs. Please let us know what specific benefits you’re looking for so we can tailor our recommendations better!\n\nYou can see all our offerings here: [All Products](https://naturemania.in/collections/all).\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["https://naturemania.in/products/soothe-up-capsule", "https://naturemania.in/products/liftup-capsule", "https://naturemania.in/products/deaddiction-combo-for-men"]	\N	\N
169	guest_1765858817878_fxk2jcg5t	2025-12-16 04:29:42.774414	i did not tell you that i have an issue regarding my penis	Thank you for clarifying, and we apologize for any misunderstanding! We offer a range of products tailored to various health and wellness needs, not solely focused on intimate concerns. \n\nIf you're looking for products that enhance overall wellness or target other areas of health, we can definitely assist with that. Here’s a quick overview of some options:\n\n1. **[Shilajit Gold Resin](https://naturemania.in/products/nature-mania-shilajit-gold-resin)**\n   - **Price:** Rs. 1,171 (was Rs. 1,249 - 6% off)\n   - **Benefits:** Boosts energy, improves stamina, and supports overall health.\n\n2. **[Smart Shaping Powder](https://naturemania.in/products/nature-mania-smart-shaping-powder)**\n   - **Price:** Rs. 2,249 (was Rs. 3,699 - 39% off)\n   - **Benefits:** Supports weight management and body shaping.\n\nIf you have specific wellness goals or areas you'd like to focus on, please share! We’re here to guide you to the best products for your needs. \n\nYou can view all our products here: [All Products](https://naturemania.in/collections/all).\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["https://naturemania.in/products/liftup-capsule"]	\N	\N
170	guest_1765858817878_fxk2jcg5t	2025-12-16 04:30:21.518357	you are still lacking in many ways how can you suggest any product to customer	We appreciate your feedback and want to improve our suggestions to better meet your expectations. Our aim is to provide relevant product recommendations based on the information we have. \n\nTo assist you effectively, it would help to know specifically:\n- What goals or results are you looking for in terms of wellness?\n- Are there any particular concerns or areas where you would like support?\n\nBased on your input, we can tailor our recommendations. Each of our products is designed with specific benefits, and understanding your needs will help us guide you to the best options.\n\nPlease let us know how you'd like to proceed, and we’ll do our best to assist you! \n\nYou can also check all our offerings here: [All Products](https://naturemania.in/collections/all).\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["naturemania_company.txt", "https://naturemania.in/products/nature-mania-smart-shaping-tablets", "https://naturemania.in/products/pre-mature-combo"]	\N	\N
171	guest_1765858817878_fxk2jcg5t	2025-12-16 04:31:29.563346	you are not satisfying at all	We sincerely apologize for not meeting your expectations, and we appreciate your honest feedback. Our goal is to provide helpful and relevant information about our products, and we regret if our responses haven’t been as effective as you'd hoped.\n\nIf there's a specific product or topic you want to discuss, please let us know, and we'll make every effort to provide clear and relevant information. Alternatively, if you have any specific concerns or preferences, sharing those will help us assist you better.\n\nThank you for your patience, and we’re here to help if you decide to continue the conversation. You can always check our full range of products here: [All Products](https://naturemania.in/collections/all).\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["https://naturemania.in/products/soothe-up-capsule", "https://www.naturemania.in", "https://www.naturemania.in/pages/contact"]	\N	\N
172	guest_1765858817878_fxk2jcg5t	2025-12-16 04:32:34.144576	if I have to check product range in website and what's the use of yours	We understand your frustration and appreciate your candidness. Our role here is to help guide you through specific product information, answer questions, and assist with any concerns you may have about our offerings. \n\nWhile you can certainly browse our website, we aim to provide personalized recommendations based on your needs, making the process easier for you. For example, we can highlight specific products that may align with your wellness goals, explain their benefits, or provide additional insights that might not be readily available.\n\nIf there’s a specific area of wellness you’re interested in, or if you have any questions about our products, please let us know, and we will do our best to assist you further!\n\nYou can also explore our complete product range here: [All Products](https://naturemania.in/collections/all).\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["https://naturemania.in/products/nature-mania-smart-shaping-powder", "https://naturemania.in/products/nature-mania-pure-himalayan-shilajit-resin-30-gm-for-men-and-women", "products_sexual_health.txt"]	\N	\N
173	guest_1765858817878_fxk2jcg5t	2025-12-16 04:34:02.449602	if the nature mania team is asking that they cannot process the full code order then what can we do	If our team informs you that they are unable to process a full code order, we recommend reaching out to us directly for clarification and assistance. Here are the steps you can take:\n\n1. **Contact Us Directly:** Please call our team at **75092-76000** or email us at **enquiry@naturemania.in**. Our customer support representatives will be happy to help you with your order or provide alternative solutions.\n\n2. **Provide Order Details:** When you reach out, make sure to include any relevant information about your order, such as the order number and the specific issues you're facing. \n\nOur team is here to support you and will do their best to resolve your concerns. Thank you for your understanding, and we look forward to assisting you!\n\nYou can also explore our products here: [All Products](https://naturemania.in/collections/all).\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["naturemania_company.txt", "https://naturemania.in/products/nature-mania-tight-up-intimate-and-tightening-gel-50gm", "https://naturemania.in/products/nature-mania-regen-combo"]	\N	\N
175	guest_1765858817878_fxk2jcg5t	2025-12-16 04:35:40.39306	if I have to contact them then what is the use of you	We completely understand your point, and we're here to provide guidance and support! While our team can’t perform actions like contacting you directly, we can help by answering questions about our products, explaining their benefits, and guiding you on how to order or address any inquiries you may have.\n\nOur role is to serve as your first point of contact for information, recommendations, and assistance with our products. For specific issues, like order processing, our customer support team can offer detailed assistance, and we're here to direct you to them.\n\nIf you have any questions about our products or if you're looking for specific recommendations, please let us know! We’re happy to assist you in any way we can.\n\nYou can also explore our full product range here: [All Products](https://naturemania.in/collections/all).\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["naturemania_company.txt", "https://naturemania.in/products/deaddiction-combo-for-men", "https://naturemania.in/products/nature-mania-smart-shaping-tablets"]	\N	\N
176	guest_1765858817878_fxk2jcg5t	2025-12-16 04:36:19.597408	you are not giving me proper answers	We apologize if our responses haven't met your expectations, and we appreciate your feedback. We're here to help you to the best of our ability! If there is a specific question or issue regarding our products, orders, or policies that you need assistance with, please let us know, and we'll do our best to provide a clear and helpful response.\n\nIf your question is about order processing or policies that require direct assistance, contacting our customer support team is the best way to get accurate information. Here are the contact options again:\n\n- **Phone:** 75092-76000\n- **Email:** enquiry@naturemania.in\n\nPlease feel free to ask any other questions you have about our products, and we'll provide the information you need! You can also check out our products here: [All Products](https://naturemania.in/collections/all).\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["https://naturemania.in/products/nature-mania-boost-up-combo-the-natural-booster-packpack", "https://naturemania.in/products/nature-mania-green-tea-tablets-60n-weight-management", "https://naturemania.in/products/liftup-capsule"]	\N	\N
177	guest_1765868478331_3ftm9nfgx	2025-12-16 07:01:58.200706	Hello	Hi there! We're NIRA, your guide here at Nature Mania. What brings you here today? Whether you have questions about our Ayurvedic products or need assistance in choosing the right solution, we're happy to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["https://www.naturemania.in/collections/all", "https://www.naturemania.in/blogs/news", "https://www.naturemania.in"]	\N	\N
178	guest_1765880230771_wqwf9z26g	2025-12-16 10:17:48.558058	where is my order	You can track your order using this link: [Track Order](https://emm-dee-enterprises.shiprocket.co/). \n\nIf you need further assistance, feel free to contact us at:\n\n**Phone:** 75092-76000  \n**Email:** enquiry@naturemania.in  \n\nWe're here to help!	f	\N	["https://naturemania.in/products/liftup-capsule", "naturemania_company.txt", "https://naturemania.in/products/size-combo"]	\N	\N
179	guest_1765880230771_wqwf9z26g	2025-12-16 10:18:22.746856	my number is 7404983721 tell me my order history	I'm sorry, but I'm unable to access your order history directly. To check your order history, please contact us at:\n\n**Phone:** 75092-76000  \n**Email:** enquiry@naturemania.in  \n\nOur team will be happy to assist you with your order details. Thank you for understanding!	f	\N	["naturemania_company.txt", "https://naturemania.in/products/nature-mania-regen-combo", "https://naturemania.in/products/nature-mania-herba-hair-oil"]	\N	\N
180	guest_1765880806658_v4bmv3779	2025-12-16 10:27:09.515929	tell me about shilajit gummies	Our Lift-Up Gummies are delicious sugar-free Shilajit gummies designed to enhance men's sexual wellness and overall energy levels. Each gummy is specifically formulated to support normal testosterone levels, helping to boost your confidence, mood, and muscle strength. \n\n**Key benefits:**\n1. **Boosts Energy and Strength:** These gummies provide your body with the additional energy needed to stay active throughout the day.\n2. **Supports Testosterone Levels:** They help in maintaining normal testosterone levels, which can improve performance in various aspects of life.\n3. **Reduces Fatigue:** If you often feel tired, these gummies can assist in combating exhaustion and keeping you energized.\n4. **Easy to Consume:** No need to swallow large pills; simply chew a gummy whenever you need a boost.\n5. **Natural Ingredients:** Made with plant-based ingredients, they are safe for daily use and have no known negative effects.\n\n**Price:** Rs. 1,299 (for a pack of 60 gummies)\n\nCheck them out here: [Lift-Up Gummies](https://naturemania.in/products/lift-up-gummies-imli-flavour-60n)\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["https://naturemania.in/products/lift-up-gummies-imli-flavour-60n"]	\N	\N
181	guest_1765880806658_v4bmv3779	2025-12-16 10:27:14.385085	tell me about shilajit gummies	Our Lift-Up Gummies are a delicious way to enhance your daily energy and support your sexual wellness. These sugar-free gummies are formulated with Pure Himalayan Shilajit and eight potent Ayurvedic herbs, designed to improve your mood, stamina, and focus.\n\n**Key Benefits:**\n1. **Boosts Power and Energy:** Lift-Up Gummies provide your body with the strength and energy needed to stay active throughout the day.\n2. **Supports Testosterone Levels:** These gummies are specifically designed to promote normal testosterone levels, which can boost your confidence, mood, and performance both at work and in personal life.\n3. **Reduces Fatigue:** If you're often feeling tired, these gummies may help keep you energised and reduce feelings of exhaustion.\n4. **Easy to Take:** No need for water! Just chew these tasty gummies whenever you need a boost.\n\n**Price:** Rs. 1,199 for 60 gummies\n\nCheck them out here: [Lift-Up Gummies](https://naturemania.in/products/lift-up-gummies-imli-flavour-60n)\n\nExtra 5% Off on Prepaid Orders! We also offer Free Shipping across India!	f	\N	["https://naturemania.in/products/lift-up-gummies-imli-flavour-60n"]	\N	\N
182	guest_1765880806658_v4bmv3779	2025-12-16 10:27:53.36151	lift up oil kitne dinon main farak dikha deta hai	[Lift-Up Oil](https://naturemania.in/products/lift-up-oil) ka इस्तेमाल karke aapko farak mehsoos karne mein kuch hafte lagenge. Regular use se, aapko behtar blood circulation aur firmer erections mein sudhaar dikhai dega. Har vyakti ki body alag hoti hai, isliye kuch logon ko zyada jaldi result mil sakta hai, jabki kuch logon ko kuch samay lag sakta hai.\n\nHum Lift-Up Oil ko rozana istemal karne ki salah dete hain, taaki aap iski poori khurak ka labh utha sakein. \n\n**Yahaan Lift-Up Oil dekhein:** [Lift-Up Oil](https://naturemania.in/products/lift-up-oil)\n\n**Price:** Rs. 999 (pichle daam Rs. 1,799 par - 44% off!)\n\nExtra 5% Off on Prepaid Orders aur Free Shipping across India! Agar aapko aur koi sawal hai to humein batayein!	f	\N	["https://naturemania.in/products/lift-up-massage-oil", "https://naturemania.in/products/nature-mania-regen-combo", "https://naturemania.in/products/lift-up-gold-herbal-massage-oil-for-men"]	\N	\N
183	guest_1765880806658_v4bmv3779	2025-12-16 10:28:43.41052	mujhe weight loss wale product ke bare mein batao	Hamare paas weight loss ke liye kuch behtar products hain, jo aapki weight management mein madad kar sakte hain. Yahan hum [Smart Shaping Powder](https://naturemania.in/products/nature-mania-smart-shaping-powder) aur Green Tea Tablets ka zikar karna chahenge:\n\n1. **Smart Shaping Powder**:\n   - **Price:** Rs. 2,249 (original Rs. 3,699 - 39% off!)\n   - **Description:** Ye powder specially design kiya gaya hai taaki fat metabolism ko facilitate karein aur energy levels ko badhayein. Isme herbal components hain jo fat break down mein madad karte hain.\n   - **How to Use:** Is powder ko liquid mein milkar consume karein aur regular exercise ke sath istemal karein for better results.\n   - **Check it out here:** [Smart Shaping Powder](https://naturemania.in/products/nature-mania-smart-shaping-powder)\n\n2. **Green Tea Tablets**:\n   - **Price:** Rs. 899 (original Rs. 1,499)\n   - **Description:** Is product mein antioxidants hote hain jo weight loss mein madad karte hain aur metabolism ko badhate hain. Ye tablets overall health ko support karne ke liye bhi faydemand hain.\n   - **Check it out here:** [Green Tea Tablets](https://naturemania.in/products/nature-mania-green-tea-tablets-60n-weight-management)\n\nAgar aapko in products ya kisi aur ki jankari chahiye, toh humein bataiye. Hamara team aapki madad ke liye hamesha tayyar hai!\n\n**Extra 5% Off on Prepaid Orders!** Free Shipping across India!	f	\N	["products_general_wellness.txt", "https://naturemania.in/products/nature-mania-smart-shaping-tablets", "https://naturemania.in/products/nature-mania-green-tea-tablets-60n-weight-management"]	\N	\N
184	guest_1765880806658_v4bmv3779	2025-12-16 10:33:34.816851	weight loss ka kya work hai kis content se mil ke bana hai	Hamare **[Smart Shaping Powder](https://naturemania.in/products/nature-mania-smart-shaping-powder)** ka mukhya udheshya un logon ki madad karna hai jo weight loss achieve karna chahte hain. Ye powder body ke fat metabolism ko enhance karne, energy levels badhane, aur overall health ko support karne ke liye design kiya gaya hai.\n\n**Key Ingredients:**\n1. **L-Carnitine**: Fat ko energy mein convert karne mein madad karta hai.\n2. **Garcinia Cambogia**: Appetite control aur fat storage ko reduce karne mein help karta hai.\n3. **Green Tea Extract**: Antioxidant properties ke liye jaana jata hai aur metabolism ko boost karta hai.\n4. **Ginger Extract**: Digestion ko sudharta hai aur metabolism ko accelerate karta hai.\n5. **Aawla (Amla)**: Immunity badhata hai aur detoxification mein madad karta hai.\n6. **Black Pepper Extract**: Nutrient absorption ko improve karta hai aur fat metabolism ko support karta hai.\n\nYe sabhi ingredients milkar organic tareeke se aapki weight management mein madadkarte hain aur aapko healthy living ki taraf badhate hain.\n\nCheck karein: [Smart Shaping Powder](https://naturemania.in/products/nature-mania-smart-shaping-powder)\n\n**Price:** Rs. 2,249 (original Rs. 3,699 - 39% off!)\n\nAgar aapko aur koi jankari chahiye, toh humein batayein! **Extra 5% Off on Prepaid Orders!** Aur haan, Free Shipping across India!	f	\N	["products_general_wellness.txt", "https://naturemania.in/products/nature-mania-green-tea-tablets-60n-weight-management", "https://naturemania.in/products/nature-mania-smart-shaping-tablets"]	\N	\N
185	guest_1765880806658_v4bmv3779	2025-12-16 10:34:36.947658	lift up capsule ke kya benefits hai	**[Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules)** ka istemal karne se aapko kai fayde mil sakte hain. Ye capsules specially male intimate health ke liye design kiye gaye hain aur inke key benefits hain:\n\n1. **Improves Blood Flow**: Ye capsules body mein blood circulation ko enhance karne mein madad karte hain, jo overall performance ko behtar banata hai.\n\n2. **Enhances Erection Quality**: [Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules) ko lene se erections ki quality mein sudhaar hota hai, jisse aapko firmer aur longer-lasting results milte hain.\n\n3. **Supports Natural Enlargement**: Regular istemal ke sath, ye capsules natural enlargement ka support karte hain.\n\n4. **Boosts Stamina**: Ye capsules stamina aur energy levels ko badhane mein madadgar hote hain, jisse aapka performance improve hota hai.\n\n5. **Made with Ayurvedic Ingredients**: Inhe Ayurvedic herbs se tayar kiya gaya hai, jo naturally aapki health ko support karte hain.\n\n**How to Use:** Daily ek capsule paani ke sath lena hai, aur ise meal ke baad lena recommended hai taaki absorption achhi tarah ho sake.\n\n**Price:** Rs. 1,499 (original Rs. 1,699 - 12% off!)\n\nAgar aapko Lift-Up Capsules ya kisi aur product ke baare mein jaankari chahiye, toh humein bataiye! \n\n**Check it here:** [Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules)\n\n**Extra 5% Off on Prepaid Orders!** Free Shipping across India!	f	\N	["https://naturemania.in/products/lift-up-massage-oil", "https://naturemania.in/products/liftup-capsule", "products_lift_up.txt"]	\N	\N
186	guest_1765880806658_v4bmv3779	2025-12-16 10:34:59.64433	kya content se bana hai	**[Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules)** mein natural Ayurvedic ingredients ka istemal kiya gaya hai, jo male intimate health ko support karne ke liye design kiye gaye hain. Inke kuch key ingredients hain:\n\n1. **Ashwagandha (Withania somnifera)**: Ye herb stress ko khatam karne, energy aur stamina badhane mein madadgar hota hai. Iska sexual health par bhi positive impact hota hai.\n\n2. **Safed Musli (Chlorophytum borivilianum)**: Ye traditionally stamina aur sexual health ko improve karne ke liye jaana jata hai. Yah libido ko boost karne mein bhi helpful hai.\n\n3. **Shatavari (Asparagus racemosus)**: Ye women's health ke liye zyada jaana jata hai, lekin men's health mein bhi beneficial hai. Ye hormonal balance mein madad karta hai.\n\n4. **Gokshura (Tribulus terrestris)**: Ye testosterone levels ko naturally badhata hai, jo sexual performance aur energy ko enhance karne mein madad karta hai.\n\n5. **Kaunch Beej (Mucuna pruriens)**: Ye natural aphrodisiac hai aur libido ko badhane mein madadgar hota hai.\n\nYe ingredients milkar [Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules) ko effective aur herbal wellness solution banate hain jo aapki intimate health ke liye beneficial hote hain.\n\nAgar aapko in capsules ya kisi aur product ke baare mein aur jaankari chahiye, toh humein zaroor batayein! \n\n**Check it here:** [Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules)\n\n**Price:** Rs. 1,499 (original Rs. 1,699 - 12% off!)\n\n**Extra 5% Off on Prepaid Orders!** Free Shipping across India!	f	\N	["https://naturemania.in/products/perm-up-capsule", "https://naturemania.in/products/nature-mania-pure-himalayan-shilajit-resin-30-gm-for-men-and-women", "https://naturemania.in/products/vit-up-capsule"]	\N	\N
194	guest_1765994278475_vk06nl2p3	2025-12-17 18:01:36.514096	Aapse order kare to kitne din me aa jayega	Agar aap humare products ka order karte hain, toh aapke order ki delivery samanya roop se 5 se 7 din ke andar ho jaati hai, lekin yeh delivery location par bhi depend karta hai.\n\nAapko yeh yaad rakhna hoga ki humari taraf se **Free Shipping** bhi available hai, aur aap **Cash on Delivery (COD)** ka option bhi choose kar sakte hain.\n\nAgar aapko order tracking ki zarurat hai, toh aap yahan jaakar apne order ko track kar sakte hain:  \n[Track Order](https://emm-dee-enterprises.shiprocket.co/)\n\nKya aap kisi specific product ke baare mein soch rahe hain? Hum madad karne ke liye yahaan hain!	f	\N	["https://naturemania.in/products/liftup-capsule", "https://naturemania.in/products/tes-up-capsule", "https://naturemania.in/products/lift-up-massage-oil"]	\N	\N
187	guest_1765880806658_v4bmv3779	2025-12-16 10:35:43.167693	cup up cream ke benefits batao	**[Cup-Up Cream](https://naturemania.in/products/cupupcream)** ka istemal karke aapko kai fayde mil sakte hain, jo breast enhancement aur skin toning ke liye design kiya gaya hai. Is cream ke key benefits ye hain:\n\n1. **Natural Breast Enhancement**: Ye cream breast size ko naturally enhance karne mein madad karti hai, jisse aapko desired fullness aur shape milta hai.\n\n2. **Skin Firming and Toning**: Cream ke ingredients skin ko tone aur firm karte hain, jisse breast ki skin presentable aur smooth hoti hai.\n\n3. **Improves Elasticity**: Isme sammilit ingredients elasticity ko badhane mein helpful hote hain, jo skin ko rejuvenate karte hain.\n\n4. **Nourishes Skin**: Ye cream deep nourishment provide karti hai, jo skin ke cells ko health aur vitality se bharta hai.\n\n5. **Promotes Cell Renewal**: Iski advanced formula skin ke rejuvenation ko promote karti hai, naye cells ka vikas karne mein madad deti hai.\n\n6. **Supports Natural Growth**: Ye cream hormonal balance ko support karta hai, jisse natural breast growth ka process achhe se chalta hai.\n\n**How to Use:** Daily is cream ko apply karna hota hai, gently massage karte hue. Ye skin ke andar achhe se absorb hota hai.\n\n**Price:** Rs. 999 (original Rs. 1,199 - 17% off!)\n\nAgar aapko Cup-Up Cream ya kisi aur product ke baare mein aur jaanana hai, toh zaroor batayein!\n\n**Check it here:** [Cup-Up Cream](https://naturemania.in/products/cupupcream)\n\n**Extra 5% Off on Prepaid Orders!** Free Shipping across India!	f	\N	["https://naturemania.in/products/cup-up-combo", "https://naturemania.in/products/cup-up-capsules", "products_women_wellness.txt"]	\N	\N
188	guest_1765880806658_v4bmv3779	2025-12-16 10:36:14.653531	lift up gold aur lift up oil main kya farak hai batao hindi mein	**Lift-Up Gold** aur **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)** dono hi products male intimate health ke liye design kiye gaye hain, lekin in dono mein kuch khaas farak hain:\n\n### 1. **Product Type**:\n- **Lift-Up Gold**: Ye ek herbal massage oil hai jo langsung skin par apply kiya jata hai. Ye oil external use ke liye hai, jo skin ko nourish karta hai aur blood circulation ko increase karta hai.\n- **Lift-Up Oil**: Ye bhi ek herbal massage oil hai, jo deep absorption ke liye design kiya gaya hai. Iska bhi external application ke liye istemal hota hai.\n\n### 2. **Ingredients**:\n- **Lift-Up Gold**: Ismein special ingredients jaise ashwagandha, shatavari, clove, aur swarna makshik bhasam shamil hain. Ye ingredients overall performance aur stamina ko enhance karne mein madadgar hain.\n- **Lift-Up Oil**: Ismein bhi similar ingredients hote hain, lekin ismein aur bhi herbal components ho sakte hain jo ki blood flow aur erection quality ko improve karne ke liye design kiye gaye hain.\n\n### 3. **Usage Purpose**:\n- **Lift-Up Gold**: Ye natural enhancement aur comfort ke liye design kiya gaya hai, jo ki foreskin care aur sensitive skin ke liye bhi beneficial hai.\n- **Lift-Up Oil**: Iska main focus natural size aur thickness ko improve karna, stronger erections ko support karna, aur stamina badhane par hota hai.\n\n### 4. **Application Method**:\n- Dono products ko 10-15 minutes tak gently massage karna hota hai, lekin Lift-Up Gold thoda aur effectively intimate moments ke hone se 15 minutes pehle lagana recommended hai.\n\nDono products ke apne unique fayde hain aur aap inki apni zarurat ke hisaab se chunaav kar sakte hain. Agar aapko inme se kisi aur product ya unke benefits ke baare mein aur jankari chahiye, toh humein zaroor batayein!\n\nAap in dono products ko yahan dekh sakte hain:\n- [Lift-Up Gold](https://naturemania.in/products/lift-up-gold-herbal-massage-oil-for-men)\n- [Lift-Up Oil](https://naturemania.in/products/lift-up-oil)\n\n**Extra 5% Off on Prepaid Orders!** Free Shipping across India!	f	\N	["https://naturemania.in/products/lift-up-gold-herbal-massage-oil-for-men", "https://naturemania.in/products/lift-up-massage-oil"]	\N	\N
189	guest_1765880806658_v4bmv3779	2025-12-16 10:37:40.634642	jab dono ka work same hai toh alag kya hai fir	Agar dono products ka kaam similar lag raha hai, toh kuch khas cheezein hain jo inka fark banati hain:\n\n### 1. **Formulation**:\n- **Lift-Up Gold**: Ismein ek specific formulation hai jo extra herbal components aur nutrients se bhara hota hai, jaise ki swarna makshik bhasam, jo ki skin ko zyada nourished feel karata hai aur mental relaxation bhi provide karta hai. Ismein thodi luxurious touch hoti hai.\n\n- **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)**: Ye thodi aur standard formulation hai, jisme key ingredients hote hain jo primarily blood circulation ko enhance karne aur natural size badhane par focus karta hai. Ye effective hone ke saath-saath affordability bhi rakhte hain.\n\n### 2. **Sensory Experience**:\n- **Lift-Up Gold**: Is oil ko apply karne par aapko thoda premium aur pleasant experience milega, jo high-quality ingredients se aata hai.\n\n- **Lift-Up Oil**: Ye bhi effective hai, par ismein sensory experience thoda alag ho sakta hai, jo ki diverse herbs par depend karta hai.\n\n### 3. **Target Audience**:\n- **Lift-Up Gold**: Zyada luxury aur pampering experience ki talash karne waale logon ke liye targeted hai, ya jo log natural enhancement ko seriously lete hain.\n\n- **Lift-Up Oil**: Ye un logon ke liye hai jo effective solution chahte hain jo budget-friendly ho, bina kisi complex formulation ke.\n\n### 4. **Skin Benefits**:\n- **Lift-Up Gold**: Skin ko deeper nourishment deta hai, jisse skin soft aur supple hoti hai, aur ye long-term skin health ke liye bhi beneficial hota hai.\n\n- **Lift-Up Oil**: Ye primarily blood flow badhane par focus karta hai, aur short-term results ko target karta hai.\n\nIsliye, agar aapko ek enriching experience chahiye, toh aap **Lift-Up Gold** chune. Agar aap ko effective aur cost-effective solution chahiye, toh **Lift-Up Oil** achha rahega.\n\nAgar aapko koi aur specific sawaal hai ya kisi product ke details chahiye, toh humein zaroor batayein!\n\n**Check them here**:\n- [Lift-Up Gold](https://naturemania.in/products/lift-up-gold-herbal-massage-oil-for-men)\n- [Lift-Up Oil](https://naturemania.in/products/lift-up-oil)\n\n**Extra 5% Off on Prepaid Orders!** Free Shipping across India!	f	\N	["https://www.naturemania.in/collections/all", "https://naturemania.in/products/perm-up-capsule", "https://www.naturemania.in/pages/about-us"]	\N	\N
190	guest_1765994278475_vk06nl2p3	2025-12-17 17:58:42.458619	Aap hindi mein baat karoge ?	Haan, bilkul! Aap kis cheez ke baare mein jaan na chahte hain? Hum yahan aapki madad ke liye hain!	f	\N	["https://naturemania.in/products/perm-up-capsule", "https://www.naturemania.in", "https://www.naturemania.in/collections/all"]	\N	\N
191	guest_1765994278475_vk06nl2p3	2025-12-17 17:58:56.586437	Aapka naam kya hai	Hamara naam NIRA hai, aur hum yahan Nature Mania mein aapki madad karne ke liye hain! Aap humse kisi bhi Ayurvedic product ke baare mein pooch sakte hain. Aapko kya janna hai?\n\n---\n\n*Feel free to explore more when you're ready:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["https://naturemania.in/products/vit-up-capsule", "https://www.naturemania.in/collections/all", "https://naturemania.in/products/perm-up-capsule"]	\N	\N
192	guest_1765994278475_vk06nl2p3	2025-12-17 17:59:38.786694	Mera ling khada nahin hota	Is samasya se jude kisi bhi health concern ka samadhan dene mein hum madad nahi kar sakte. Lekin humare paas kuch Ayurvedic products hain jo natural enhancement ke liye design kiye gaye hain, jisse aap apne confidence mein sudhar dekh sakte hain.\n\n1. **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil) (30ml)**: Rs. 999 (pehle Rs. 1,799 - 44% off)  \n   [Lift-Up Oil](https://naturemania.in/products/lift-up-oil)\n\n2. **[Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules) (60 caps)**: Rs. 1,499 (pehle Rs. 1,699 - 12% off)  \n   [Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules)\n\nYeh products blood circulation ko promote karte hain aur natural enhancement mein madad karte hain.\n\nAgar aapko kisi aur information ki zarurat hai ya purchase karna chahte hain, toh humse sampark kar sakte hain:  \n**Phone:** 75092-76000  \n**Email:** enquiry@naturemania.in  \n\nExtra 5% Off on Prepaid Orders! Free Shipping available!	f	\N	["https://www.naturemania.in/blogs/news", "https://www.naturemania.in/collections/all", "https://www.naturemania.in/pages/contact"]	\N	\N
193	guest_1765994278475_vk06nl2p3	2025-12-17 18:00:40.705971	Agar inse result na aaya toh?	Hamare Ayurvedic products ko natural wellness ke liye design kiya gaya hai, lekin har vyakti ka anubhav alag ho sakta hai. Agar aapko hamare products se koi result nahi milta, toh hum yeh salah dete hain ki aap kisi qualified healthcare professional se sampark karein, jo aapki specific health needs ko samajh sakein.\n\nHamara maqsad aapki sehat aur khushhali mein sudhar lana hai, aur hamare products sirf ek saadhan hain. Agar aapko aur bhi information ki zarurat hai ya kisi aur product ke baare mein jaan na chahte hain, toh humse sampark kar sakte hain:\n\n**Phone:** 75092-76000  \n**Email:** enquiry@naturemania.in  \n\nAgar aapko koi aur madad chahiye, toh hum yahan hain!\n\n---\n\n*If you'd like to learn more, these might interest you:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["https://www.naturemania.in/pages/about-us", "https://www.naturemania.in", "https://www.naturemania.in/blogs/news"]	\N	\N
195	guest_1765994278475_vk06nl2p3	2025-12-17 18:02:15.817239	Lift up oil konsa original hai	Hamare paas **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)** ek hi product hai, jo ki original hai. Yeh natural Ayurvedic oil hai, jo male intimate health ko sudharne ke liye design kiya gaya hai. Iska formulation khas Ayurvedic herbs se kiya gaya hai, jisse yeh effective aur safe hai.\n\nYeh product aapko yahan milega: **[Lift-Up Oil (30ml)](https://naturemania.in/products/lift-up-oil)**  \n**Price:** Rs. 999 (pehle Rs. 1,799 - 44% off)  \n\nYeh oil blood circulation ko improve karta hai, stamina ko badhata hai, aur natural enhancement mein madad karta hai.\n\nKya aap is product ko order karne mein interested hain ya koi aur sawaal hai?	f	\N	["https://naturemania.in/products/lift-up-massage-oil", "https://naturemania.in/products/liftup-capsule", "https://naturemania.in/products/nature-mania-regen-combo"]	\N	\N
196	guest_1765994278475_vk06nl2p3	2025-12-17 18:03:22.475879	Kya nature mania Dr Neha ki hai?	Hamara maqsad hai aapko quality Ayurvedic products dena, lekin humein Dr. Neha ke baare mein specific information nahi hai. Nature Mania ek Ayurvedic e-commerce brand hai jo pure aur effective natural solutions par focus karta hai, lekin hume kis bhi vyakti ke association ke baare mein jaankari nahi hai.\n\nAgar aapko kuch aur specific information chahiye ya kisi product ke baare mein jankari chahiye, toh aap humse sampark kar sakte hain:\n\n**Phone:** 75092-76000  \n**Email:** enquiry@naturemania.in  \n\nHum yahan aapki madad ke liye hain!\n\n---\n\n*Here are some products that align with what we discussed:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["naturemania_company.txt", "https://naturemania.in/products/nature-mania-pure-himalayan-shilajit-resin-30-gm-for-men-and-women", "https://naturemania.in/products/nature-mania-smart-shaping-tablets"]	\N	\N
197	guest_1765994278475_vk06nl2p3	2025-12-17 18:03:40.753055	Dr neha lift up oil ko kyun promote karti hai ?	For information about discounts, special offers, or bulk orders, please contact our team directly:\n\n**Phone:** 75092-76000\n**Email:** enquiry@naturemania.in\n\nOur team will be happy to assist you with any pricing inquiries!\n\nIn the meantime, you can also enjoy **Extra 5% Off on Prepaid Orders** on all products. Would you like to know more about any of our products?	t	\N	\N	\N	\N
198	guest_1765994278475_vk06nl2p3	2025-12-17 18:04:10.891025	Aap Dr Neha Mehta ko jaante ho?	Humein Dr. Neha Mehta ke baare mein specific information nahi hai. Humara maqsad aapko Ayurvedic products aur wellness solutions ke baare mein jaankari dena hai. Aagar aap kisi specific product, jaise **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)**, ya hamare kisi aur product ke baare mein jaan-na chahte hain, toh humein bataiye.\n\nAgar aapne kisi aur cheez ki talash ki hai ya kisi specific vishay par jaankari chahiye, toh humari team aapki madad ke liye yahan hai. Aap humse sampark bhi kar sakte hain:\n\n**Phone:** 75092-76000  \n**Email:** enquiry@naturemania.in  \n\nKya aapko aur koi madad chahiye?	f	\N	["https://www.naturemania.in/collections/all", "naturemania_company.txt", "https://naturemania.in/products/vit-up-capsule"]	\N	\N
199	guest_1766029537617_3x33dsr03	2025-12-18 03:46:14.88767	can you suggest me an iPhone under 25000	Currently, our [iPhones](https://grest.in/collections/iphones) start around ₹38,999, which is above your budget of ₹25,000. 🌟 While we don't have models under that price point, you may want to consider exploring other refurbished options or saving a bit more to get a quality refurbished iPhone.\n\nIf you're open to looking outside your current budget, I'd recommend checking out models like:\n- **iPhone 12 (Refurbished)** Around ₹42,000\n- **iPhone 13 (Refurbished)** Around ₹38,999\n\nBoth options come with our 12-month warranty and have passed 50+ quality checks. Would you like to browse our full collection or need help with something else? 😊	f	\N	["https://grest.in/blogs/news/how-much-storage-do-you-really-need-in-a-refurbished-iphone-64gb-vs-128gb-vs-256gb", "https://grest.in/blogs/news/best-time-season-to-buy-a-refurbished-iphone-in-india-festival-deals-to-year-end-discounts", "grest_product_catalog.txt"]	\N	\N
200	price_test_1766033240	2025-12-18 04:47:43.379643	suggest me an iPhone under 25000	Aapke budget mein ₹25,000 se neeche ke options ke liye, hum aapko **Apple [iPhones](https://grest.in/collections/iphones) 11** recommend karte hain. 📱\n\n**iPhone 11 ki pricing**: \n- **Price**: ₹13,699\n\nYe phone superb features ke saath aata hai jaise ki dual-camera system aur Apple ka A13 Bionic chip, jo isay performance ke liye kaafi powerful banata hai. \n\nAap ise purchase karne ke liye yahan click kar sakte hain: [iPhone 11](https://grest.in/products/iphone-11)\n\nAgar aapko aur options ya madad chahiye, toh zaroor batayein!	f	\N	["https://grest.in/blogs/news/how-much-storage-do-you-really-need-in-a-refurbished-iphone-64gb-vs-128gb-vs-256gb", "grest_product_catalog.txt", "https://grest.in/blogs/news/best-time-season-to-buy-a-refurbished-iphone-in-india-festival-deals-to-year-end-discounts"]	\N	\N
201	price_test2	2025-12-18 04:48:15.046525	suggest me an iPhone under 25000	Hamare pas ₹25,000 ke andar kaafi acche options hain! 🎉 \n\nYahan ek popular choice hai:\n\n- **Apple [iPhones](https://grest.in/collections/iphones) 11** — ₹13,699 \n  - Yeh model kaafi reliable hai aur ismein acha performance aur camera quality hai.\n  - 12 mahine ki warranty ke saath aata hai!\n\nAgar aap iPhone 11 ke baare mein aur jaanna chahte hain ya isse purchase karna chahte hain, to yahaan click karein: [Apple iPhone 11](https://grest.in/products/iphone-11)\n\nKya aapko kisi aur model ke baare mein jaan na hai?	f	\N	["https://grest.in/blogs/news/how-much-storage-do-you-really-need-in-a-refurbished-iphone-64gb-vs-128gb-vs-256gb", "grest_product_catalog.txt", "https://grest.in/blogs/news/best-time-season-to-buy-a-refurbished-iphone-in-india-festival-deals-to-year-end-discounts"]	\N	\N
202	hindi_test	2025-12-18 04:48:47.871137	aapke paas sabse sasta iPhone kaunsa hai	Hamare paas sabse sasta [iPhones](https://grest.in/collections/iphones) **iPhone 11** hai, jo ₹13,699 se shuru hota hai! 📱 Yeh ek accha choice hai agar aap acche features aur performance ke saath budget-friendly option dhund rahe hain. \n\nAap is link par jaakar purchase kar sakte hain: [Refurbished iPhone 11](https://grest.in/products/refurbished-iphone-11).\n\nKya aapko aur koi madad chahiye?	f	\N	["https://grest.in/pages/about", "https://grest.in/pages/warranty-policy", "https://grest.in/pages/faqs"]	\N	\N
203	trust_test	2025-12-18 04:51:22.52163	can I trust GREST? Is it reliable? (no changes needed)	Absolutely! You can trust GREST. We are a registered company, and our commitment to quality is reflected in our rigorous processes. Here are some key points that highlight our reliability:\n\n- **50+ Quality Checks**: Every device undergoes over 50 technical and functional tests to ensure its performance.\n- **12-Month Warranty**: All our products come with a full 12-month warranty, providing you with peace of mind.\n- **7-Day Replacement Policy**: If you're not satisfied with your purchase, you can return it within 7 days for a hassle-free replacement.\n- **Positive Reviews**: We have excellent ratings on platforms like Trustpilot and Mouthshut, showcasing customer satisfaction.\n\nYou can explore more about us and see our reviews here: [Trustpilot](https://www.trustpilot.com/review/grest.in) and [Mouthshut](https://www.mouthshut.com/product-reviews/Grest-in-reviews-926089093).\n\nIf you have any more questions or need assistance, feel free to reach out to us!	f	\N	["https://grest.in/blogs/news/refurbished-iphone-conditions-fair-good-superb", "grest_contact_info.txt", "https://grest.in/blogs/news/how-much-storage-do-you-really-need-in-a-refurbished-iphone-64gb-vs-128gb-vs-256gb"]	\N	\N
204	competitor_test	2025-12-18 04:51:48.424458	why should I buy from GREST and not from Cashify	Buying from us at GREST comes with several advantages that set us apart from competitors like Cashify. Here are some reasons why you should choose us:\n\n1. **50+ Quality Checks**: Every device undergoes rigorous testing to ensure top-notch quality.\n2. **12-Month Warranty**: We provide a full 12-month warranty on all our products, giving you peace of mind.\n3. **7-Day Hassle-Free Replacement**: If you're not completely satisfied, you can return it within 7 days and get a replacement.\n4. **Free Delivery**: We offer free delivery across India on all orders.\n5. **Genuine Products**: You can be assured of 100% authentic Apple devices.\n6. **Best Prices**: Our prices are significantly lower than new devices, allowing you to save money without compromising on quality.\n7. **In-House Refurbishment**: We have our own expert technicians who handle the refurbishment, ensuring high standards.\n\nWe’re committed to providing the best experience for our customers. If you're looking for reliable, quality-tested refurbished Apple products, we're here for you! \n\nReady to explore our collection? Check it out here: [GREST Collection](https://grest.in) 😊	f	\N	["https://grest.in/pages/faqs", "https://grest.in/blogs/news/trade-in-vs-buying-a-refurbished-iphone-which-route-gives-you-better-value", "https://grest.in/blogs/news/best-time-season-to-buy-a-refurbished-iphone-in-india-festival-deals-to-year-end-discounts"]	\N	\N
205	final_warranty	2025-12-18 04:53:45.833018	what warranty do you offer	We offer a 6-month warranty on all our products, which can be extended to a total of 12 months for an additional fee of ₹1,499. This warranty covers software issues, functional problems like speaker and microphone issues, and hardware defects due to manufacturing faults. \n\nIf you're interested in purchasing an extended warranty or have any more questions, feel free to ask! 😊\n\n---\n\n*Browse more options here:*\n[Warranty](https://grest.in/pages/warranty-policy) | [FAQs](https://grest.in/pages/faqs)	f	\N	["grest_warranty_policy.txt", "https://grest.in/pages/faqs", "https://grest.in/policies/refund-policy"]	\N	\N
206	final_price	2025-12-18 04:54:08.757419	suggest me an iPhone under 25000	Hamare paas ₹25,000 ke budget mein kuch acche [iPhones](https://grest.in/collections/iphones) options hain! 📱 \n\n1. **Apple iPhone 11** - Starting from ₹13,699\n   - 64GB storage\n   - Super Retina display\n   - Dual 12MP rear cameras\n   - Great performance for daily use\n\nYe sabhi phones 12-month warranty aur 50+ quality checks ke saath aate hain! Aap is model ke baare mein zyada jaanne ke liye yahaan visit kar sakte hain: [iPhone 11 on GREST](https://grest.in/products/apple-iphone-11).\n\nKya aapko aur koi madad chahiye?	f	\N	["https://grest.in/blogs/news/how-much-storage-do-you-really-need-in-a-refurbished-iphone-64gb-vs-128gb-vs-256gb", "grest_product_catalog.txt", "https://grest.in/blogs/news/best-time-season-to-buy-a-refurbished-iphone-in-india-festival-deals-to-year-end-discounts"]	\N	\N
207	spec_test	2025-12-18 05:05:24.932833	Tell me about iPhone 15 Pro camera specs	The [iPhones](https://grest.in/collections/iphones) 15 Pro features an impressive camera system that enhances your photography experience! 📸 Here are the key specs:\n\n- **Triple Camera System**: Includes a Pro camera system for advanced photography.\n- **Main Camera**: 48MP wide camera allowing for stunning detail and clarity.\n- **Ultra-Wide Camera**: 12MP ultra-wide camera, perfect for capturing expansive landscapes.\n- **Telephoto Camera**: 12MP telephoto camera enables 5x optical zoom for detailed close-ups.\n- **Night Mode**: Automatically enabled for all cameras, ensuring great low-light performance.\n- **Photonic Engine**: Delivers improved color accuracy and detail in images.\n- **Video Recording**: Supports 4K video recording at up to 60 fps, and 4K Dolby Vision HDR for cinematic quality.\n\nWith these features, the iPhone 15 Pro is designed to capture every moment beautifully! If you're interested, you can check out more details or get one here: [iPhone 15 Pro](https://grest.in/products/iphone-15-pro). \n\nLet me know if you have any more questions or need assistance!	f	\N	["grest_product_catalog.txt", "https://grest.in/blogs/news/refurbished-iphone-conditions-fair-good-superb", "https://grest.in/blogs/news/how-much-storage-do-you-really-need-in-a-refurbished-iphone-64gb-vs-128gb-vs-256gb"]	\N	\N
208	specs_test	2025-12-18 12:40:45.904883	iPhone 15 camera specs	The [iPhones](https://grest.in/collections/iphones) 15 has impressive camera specs that elevate your photography experience! 📸 Here are the details:\n\n- **Rear Camera**: Dual 48 MP (wide f/1.6) + 12 MP (ultra-wide f/2.4)\n- **Front Camera**: 12 MP f/1.9\n\nIt also features a 6.1" Super Retina XDR display, ensuring your photos look stunning! \n\nIf you're interested, you can check out more details and purchase the iPhone 15 here: [iPhone 15](https://grest.in/products/iphone-15). Kya aapko aur details chahiye?	f	\N	["grest_product_catalog.txt", "https://grest.in/blogs/news/refurbished-iphone-conditions-fair-good-superb", "https://grest.in/blogs/news/how-much-storage-do-you-really-need-in-a-refurbished-iphone-64gb-vs-128gb-vs-256gb"]	\N	\N
209	compare_test	2025-12-18 12:41:09.874126	difference between iPhone 14 and iPhone 15	The [iPhones](https://grest.in/collections/iphones) 14 and iPhone 15 have several key differences. Here’s a quick comparison:\n\n1. **Processor**:\n   - **iPhone 14**: A15 Bionic Chip.\n   - **iPhone 15**: A16 Bionic Chip, offering better performance and efficiency.\n\n2. **Design**:\n   - **iPhone 14**: Traditional Lightning connector.\n   - **iPhone 15**: Features a USB-C port, allowing for faster charging and data transfer.\n\n3. **Camera**:\n   - **iPhone 14**: 12 MP dual camera system.\n   - **iPhone 15**: Enhanced camera capabilities with improved image processing.\n\n4. **Display**:\n   - Both models feature a 6.1" Super Retina XDR display, but the iPhone 15 may have slightly improved brightness and color accuracy.\n\n5. **Dynamic Island**:\n   - **iPhone 14**: Standard display notch.\n   - **iPhone 15**: Introduces Dynamic Island, allowing for more interactive notifications and controls.\n\n6. **Build**:\n   - The iPhone 15 generally has a more premium finish and design enhancements compared to the iPhone 14.\n\nPrice-wise, the iPhone 15 starts at ₹37,999, while the iPhone 14 starts at ₹30,299. \n\nFor more details, you can check out our listings:\n- [iPhone 14](https://grest.in/products/refurbished-apple-iphone-14) \n- [iPhone 15](https://grest.in/products/iphone-15)\n\nIf you have any specific preferences or questions, let us know! 😊	f	\N	["https://grest.in/blogs/news/best-time-season-to-buy-a-refurbished-iphone-in-india-festival-deals-to-year-end-discounts", "grest_product_catalog.txt", "https://grest.in/blogs/news/trade-in-vs-buying-a-refurbished-iphone-which-route-gives-you-better-value"]	\N	\N
210	specs_test2	2025-12-18 12:42:12.634627	What are the camera specs of iPhone 16 Pro Max? (no changes needed)	I'm sorry, but I don't have specific camera specifications for the [iPhones](https://grest.in/collections/iphones) 16 Pro Max at the moment. However, you can find more detailed information directly on our product page: [iPhone 16 Pro Max](https://grest.in/products/iphone-16-pro-max).\n\nIf you have any other questions or need further assistance, feel free to ask!	f	\N	["grest_product_catalog.txt", "https://grest.in/blogs/news/refurbished-iphone-conditions-fair-good-superb", "https://grest.in/blogs/news/how-much-storage-do-you-really-need-in-a-refurbished-iphone-64gb-vs-128gb-vs-256gb"]	\N	\N
211	guest_1766073474797_kv9usdrdp	2025-12-18 15:58:24.435749	hi	Hi there! We're NIRA, your guide here at Nature Mania. What brings you here today? If you have any questions about our Ayurvedic products or need assistance choosing the right solution, we're here to help!\n\n---\n\n*If you'd like to learn more, these might interest you:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["https://www.naturemania.in/collections/all", "https://www.naturemania.in/blogs/news", "https://www.naturemania.in/pages/contact"]	\N	\N
212	guest_1766073447974_55bpcb5ov	2025-12-18 15:58:29.487818	hi	Hi there! I'm NIRA, your guide here at Nature Mania. What brings you here today? Whether you're looking for information about our Ayurvedic products or need help choosing the right solution, I'm happy to help!\n\n---\n\n*Here are some products that align with what we discussed:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["https://www.naturemania.in/collections/all", "https://www.naturemania.in/blogs/news", "https://www.naturemania.in/pages/contact"]	\N	\N
213	guest_1766074384821_zv1xzy396	2025-12-18 16:17:09.640902	hi	Hey there! 👋 I'm GRESTA, your guide at GREST — India's trusted destination for premium refurbished [iPhones](https://grest.in/collections/iphones) and [MacBooks](https://grest.in/collections/macbook). Whether you're looking for a specific model, curious about our quality checks, or need help choosing the right device, I'm here to help! What can I assist you with today?	f	\N	["https://grest.in/collections/iphone-12-refurbished", "grest_product_catalog.txt", "https://grest.in/pages/contact-us"]	\N	\N
214	test123	2025-12-18 16:47:05.801021	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
215	guest_1766076411960_ztqpofiqs	2025-12-18 16:47:06.144224	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs or looking for support, I'm happy to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
216	guest_1766076411960_ztqpofiqs	2025-12-18 16:51:14.63683	hi	Hi again! It’s great to see you back. How can we assist you today? Whether you have questions about our programs or just need some guidance, we’re here to help!	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
217	guest_1766076987507_46oar2tvx	2025-12-18 16:56:34.537408	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs or looking for support, I'm happy to help!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
218	test123	2025-12-18 20:06:17.210623	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
219	guest_1766088387693_e2w998unt	2025-12-18 20:06:42.382983	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
220	guest_1766089140079_k8r2fcomp	2025-12-18 20:19:04.568007	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, seeking support, or just exploring, I'm here to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
221	guest_1766089379910_j5v5a0qhs	2025-12-18 20:23:04.39037	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs or looking for support, I'm here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
222	guest_1766089922150_xk410c207	2025-12-18 20:32:27.896354	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
223	guest_1766089922150_xk410c207	2025-12-18 20:36:45.725959	i feel lonely	I'm really sorry to hear that you're feeling lonely — that's a tough experience to go through. It's important to know you're not alone in feeling this way. Sometimes, these feelings can stem from a disconnect within ourselves and a desire for deeper connections.\n\nWe have programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" that focus on understanding and addressing these emotional roots. Would you like more information on that, or would it help to connect with our team?	f	\N	["Coaching: Do you feel lonely among your loved ones?", "website_elevate360.txt", "Coaching: Watch this if you feel exhausted"]	\N	\N
224	guest_1766091230108_sso302sg2	2025-12-18 20:54:22.103587	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs or looking for support, I'm happy to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feedback (id, message_id, session_id, rating, comment, created_at) FROM stdin;
\.


--
-- Data for Name: flagged_conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flagged_conversations (id, session_id, user_message, flag_reason, severity, created_at) FROM stdin;
\.


--
-- Data for Name: grest_products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grest_products (id, sku, name, category, variant, storage, color, condition, price, original_price, discount_percent, in_stock, warranty_months, product_url, image_url, description, specifications, created_at, updated_at) FROM stdin;
1	IPHONE_16	Apple iPhone 16	iPhone	\N	\N	\N	\N	48799.00	69900.00	30	t	6	https://grest.in/products/iphone-16	https://cdn.shopify.com/s/files/1/0639/4576/9191/files/Frame_2_21.png?v=1761804573	\N	{"specs": {}, "storage_options": ["256 GB", "512 GB", "128 GB"], "colors": ["White Titanium", "Teal", "Random", "Black", "Ultramarine", "Pink"], "conditions": ["Superb", "Good", "Fair"], "variant_count": 54, "price_range": "Rs. 48,799 - Rs. 61,999"}	2025-12-18 04:41:21.650207	2025-12-18 04:41:21.650211
2	IPHONE_15	Apple iPhone 15	iPhone	\N	\N	\N	\N	37999.00	72999.00	47	t	6	https://grest.in/products/iphone-15	https://cdn.shopify.com/s/files/1/0639/4576/9191/files/Frame_9_10.png?v=1761800696	\N	{"specs": {}, "storage_options": ["256 GB", "512 GB", "128 GB"], "colors": ["Yellow", "Green", "Random", "Blue", "Black", "Pink"], "conditions": ["Superb", "Good", "Fair"], "variant_count": 54, "price_range": "Rs. 37,999 - Rs. 49,999"}	2025-12-18 04:41:22.933716	2025-12-18 04:41:22.93372
3	REFURBISHED_APPLE_IPHONE_14	Apple iPhone 14	iPhone	\N	\N	\N	\N	30299.00	69900.00	56	t	6	https://grest.in/products/refurbished-apple-iphone-14	https://cdn.shopify.com/s/files/1/0639/4576/9191/files/Frame_11_1.png?v=1761762198	\N	{"specs": {}, "storage_options": ["256 GB", "512 GB", "128 GB"], "colors": ["Midnight", "Yellow", "Red", "Purple", "Starlight", "Random", "Blue"], "conditions": ["Superb", "Good", "Fair"], "variant_count": 63, "price_range": "Rs. 30,299 - Rs. 38,999"}	2025-12-18 04:41:24.24051	2025-12-18 04:41:24.240514
4	REFURBISHED_APPLE_IPHONE_14_PLUS	Apple iPhone 14 Plus	iPhone	\N	\N	\N	\N	34099.00	79900.00	57	t	6	https://grest.in/products/refurbished-apple-iphone-14-plus	https://cdn.shopify.com/s/files/1/0639/4576/9191/files/Frame_1_4.png?v=1761763215	\N	{"specs": {}, "storage_options": ["256 GB", "512 GB", "128 GB"], "colors": ["Midnight", "Yellow", "Purple", "Starlight", "Random", "Blue"], "conditions": ["Superb", "Good", "Fair"], "variant_count": 54, "price_range": "Rs. 34,099 - Rs. 41,999"}	2025-12-18 04:41:25.509142	2025-12-18 04:41:25.509146
5	REFURBISHED_APPLE_IPHONE_14_PRO	Apple iPhone 14 Pro	iPhone	\N	\N	\N	\N	49299.00	119900.00	58	t	6	https://grest.in/products/refurbished-apple-iphone-14-pro	https://cdn.shopify.com/s/files/1/0639/4576/9191/files/Frame_3_5.png?v=1761766096	\N	{"specs": {}, "storage_options": ["256 GB", "1TB", "512 GB", "128 GB"], "colors": ["Deep Purple", "Space Black", "Silver", "Gold", "Random"], "conditions": ["Superb", "Good", "Fair"], "variant_count": 60, "price_range": "Rs. 49,299 - Rs. 81,500"}	2025-12-18 04:41:26.804013	2025-12-18 04:41:26.804018
6	REFURBISHED_APPLE_IPHONE_14_PRO_MAX	Apple iPhone 14 Pro Max	iPhone	\N	\N	\N	\N	54299.00	127999.00	57	t	6	https://grest.in/products/refurbished-apple-iphone-14-pro-max	https://cdn.shopify.com/s/files/1/0639/4576/9191/files/Frame_4_8_f406a91f-1dd3-4cdb-b802-e5d5046cf5f0.png?v=1761766687	\N	{"specs": {}, "storage_options": ["256 GB", "1 TB", "512 GB", "128 GB"], "colors": ["Random", "Deep Purple", "Space Black", "Gold"], "conditions": ["Superb", "Good", "Fair"], "variant_count": 48, "price_range": "Rs. 54,299 - Rs. 68,999"}	2025-12-18 04:41:28.073379	2025-12-18 04:41:28.073384
7	REFURBISHED_APPLE_IPHONE_13	Apple iPhone 13	iPhone	\N	\N	\N	\N	25899.00	59900.00	56	t	6	https://grest.in/products/refurbished-apple-iphone-13	https://cdn.shopify.com/s/files/1/0639/4576/9191/files/Frame_1_17.png?v=1761798135	\N	{"specs": {}, "storage_options": ["256 GB", "512 GB", "128 GB"], "colors": ["Midnight", "Green", "Red", "Starlight", "Random", "Blue", "Pink"], "conditions": ["Superb", "Good", "Fair"], "variant_count": 63, "price_range": "Rs. 25,899 - Rs. 33,999"}	2025-12-18 04:41:29.346623	2025-12-18 04:41:29.346627
8	REFURBISHED_APPLE_IPHONE_13_MINI	Apple iPhone 13 mini	iPhone	\N	\N	\N	\N	25199.00	64900.00	61	t	6	https://grest.in/products/refurbished-apple-iphone-13-mini	https://cdn.shopify.com/s/files/1/0639/4576/9191/files/Frame_9_6.png?v=1761798859	\N	{"specs": {}, "storage_options": ["256 GB", "512 GB", "128 GB"], "colors": ["Midnight", "Green", "Red", "Starlight", "Random", "Blue", "Pink"], "conditions": ["Superb", "Good", "Fair"], "variant_count": 63, "price_range": "Rs. 25,199 - Rs. 32,999"}	2025-12-18 04:41:30.638988	2025-12-18 04:41:30.638992
9	REFURBISHED_IPHONE_13_PRO	Apple iPhone 13 Pro	iPhone	\N	\N	\N	\N	38699.00	119900.00	67	t	6	https://grest.in/products/refurbished-iphone-13-pro	https://cdn.shopify.com/s/files/1/0639/4576/9191/files/Frame_5_15.png?v=1761799724	\N	{"specs": {}, "storage_options": ["256 GB", "1 TB", "512 GB", "128 GB"], "colors": ["Random", "Silver", "Sierra Blue", "Graphite"], "conditions": ["Superb", "Good", "Fair"], "variant_count": 48, "price_range": "Rs. 38,699 - Rs. 61,999"}	2025-12-18 04:41:31.911977	2025-12-18 04:41:31.911981
10	APPLE_IPHONE_13_PRO_MAX	Apple iPhone 13 Pro Max	iPhone	\N	\N	\N	\N	42399.00	129900.00	67	t	6	https://grest.in/products/apple-iphone-13-pro-max	https://cdn.shopify.com/s/files/1/0639/4576/9191/files/Frame_5_39.png?v=1763478802	\N	{"specs": {}, "storage_options": ["512GB", "128GB", "256GB", "1TB"], "colors": ["Green", "Silver", "Gold", "Random", "Blue", "Graphite"], "conditions": ["Superb", "Good", "Fair"], "variant_count": 72, "price_range": "Rs. 42,399 - Rs. 69,999"}	2025-12-18 04:41:33.21738	2025-12-18 04:41:33.217385
11	REFURBISHED_APPLE_IPHONE_12	Apple iPhone 12	iPhone	\N	\N	\N	\N	18099.00	44999.00	59	t	6	https://grest.in/products/refurbished-apple-iphone-12	https://cdn.shopify.com/s/files/1/0639/4576/9191/files/Frame_11_2.png?v=1761794234	\N	{"specs": {}, "storage_options": ["64 GB", "256 GB", "128 GB"], "colors": ["Green", "Red", "Purple", "White", "Random", "Blue", "Black"], "conditions": ["Superb", "Good", "Fair"], "variant_count": 63, "price_range": "Rs. 18,099 - Rs. 23,199"}	2025-12-18 04:41:34.498131	2025-12-18 04:41:34.498135
12	REFURBISHED_IPHONE_12_MINI	Apple iPhone 12 mini	iPhone	\N	\N	\N	\N	17499.00	59900.00	70	t	6	https://grest.in/products/refurbished-iphone-12-mini	https://cdn.shopify.com/s/files/1/0639/4576/9191/files/Frame_11_3.png?v=1761796429	\N	{"specs": {}, "storage_options": ["64 GB", "256 GB", "128 GB"], "colors": ["Green", "Red", "Purple", "White", "Random", "Blue", "Black"], "conditions": ["Superb", "Good", "Fair"], "variant_count": 63, "price_range": "Rs. 17,499 - Rs. 24,299"}	2025-12-18 04:41:35.78216	2025-12-18 04:41:35.782165
13	REFURBISHED_APPLE_IPHONE_12_PRO	Apple iPhone 12 Pro	iPhone	\N	\N	\N	\N	28499.00	109000.00	73	t	6	https://grest.in/products/refurbished-apple-iphone-12-pro	https://cdn.shopify.com/s/files/1/0639/4576/9191/files/Frame_4_17.png?v=1761796679	\N	{"specs": {}, "storage_options": ["256 GB", "512 GB", "128 GB"], "colors": ["Pacific Blue", "Silver", "Gold", "Random", "Graphite"], "conditions": ["Superb", "Good", "Fair"], "variant_count": 45, "price_range": "Rs. 28,499 - Rs. 36,999"}	2025-12-18 04:41:37.079982	2025-12-18 04:41:37.079986
14	REFURBISHED_APPLE_IPHONE_12_PRO_MAX	Apple iPhone 12 Pro Max	iPhone	\N	\N	\N	\N	32599.00	119900.00	72	t	6	https://grest.in/products/refurbished-apple-iphone-12-pro-max	https://cdn.shopify.com/s/files/1/0639/4576/9191/files/Frame_3_16.png?v=1761797465	\N	{"specs": {}, "storage_options": ["256 GB", "512 GB", "128 GB"], "colors": ["Random", "Graphite", "Pacific Blue", "Gold"], "conditions": ["Superb", "Good", "Fair"], "variant_count": 36, "price_range": "Rs. 32,599 - Rs. 39,999"}	2025-12-18 04:41:38.358112	2025-12-18 04:41:38.358116
15	REFURBISHED_IPHONE_11	Apple iPhone 11	iPhone	\N	\N	\N	\N	13699.00	43900.00	68	t	6	https://grest.in/products/refurbished-iphone-11	https://cdn.shopify.com/s/files/1/0639/4576/9191/files/Frame_5_4dd9eb9e-2825-4958-b0a5-72cae3fb98da.png?v=1761753511	\N	{"specs": {}, "storage_options": ["64 GB", "256 GB", "128 GB"], "colors": ["Yellow", "Purple", "Red", "White", "Random", "Green", "Black"], "conditions": ["Superb", "Good", "Fair"], "variant_count": 63, "price_range": "Rs. 13,699 - Rs. 20,499"}	2025-12-18 04:41:39.628579	2025-12-18 04:41:39.628586
16	REFURBISHED_APPLE_IPHONE_11_PRO	Apple iPhone 11 Pro	iPhone	\N	\N	\N	\N	18899.00	106600.00	82	t	6	https://grest.in/products/refurbished-apple-iphone-11-pro	https://cdn.shopify.com/s/files/1/0639/4576/9191/files/Frame_2_6.png?v=1761767184	\N	{"specs": {}, "storage_options": ["64 GB", "256 GB", "512 GB"], "colors": ["Matte Silver", "Matte Graphite", "Matte Gold", "Matte Midnight Green", "Random"], "conditions": ["Superb", "Good", "Fair"], "variant_count": 45, "price_range": "Rs. 18,899 - Rs. 26,499"}	2025-12-18 04:41:40.880955	2025-12-18 04:41:40.88096
17	REFURBISHED_APPLE_IPHONE_11_PRO_MAX	Apple iPhone 11 Pro Max	iPhone	\N	\N	\N	\N	21199.00	117100.00	81	t	6	https://grest.in/products/refurbished-apple-iphone-11-pro-max	https://cdn.shopify.com/s/files/1/0639/4576/9191/files/Frame_5_7.png?v=1761767793	\N	{"specs": {}, "storage_options": ["64 GB", "256 GB", "512 GB"], "colors": ["Matte Black", "Silver", "Matte Gold", "Matte Midnight Green", "Random"], "conditions": ["Superb", "Good", "Fair"], "variant_count": 45, "price_range": "Rs. 21,199 - Rs. 29,999"}	2025-12-18 04:41:42.169122	2025-12-18 04:41:42.169127
18	APPLE_IPAD_A2602_A13_BIONIC_9TH_GEN_WIFI202164GB10	APPLE IPAD A2602 A13 BIONIC 9TH GEN WIFI(2021)(64GB)(10.2")	iPad	\N	\N	\N	\N	15299.00	\N	\N	t	6	https://grest.in/products/apple-ipad-a2602-a13-bionic-9th-gen-wifi202164gb10-2	https://cdn.shopify.com/s/files/1/0639/4576/9191/files/Frame_7_5_dc704dbb-1dc7-4035-bb9c-98d5441aa06b.png?v=1765963018	\N	{"specs": {}, "storage_options": ["64GB"], "colors": ["Silver", "Gray"], "conditions": ["Superb", "Good", "Fair"], "variant_count": 6, "price_range": "Rs. 15,299 - Rs. 16,999"}	2025-12-18 04:41:43.419186	2025-12-18 04:41:43.41919
19	APPLE_IPAD_PRO_A1934_A12X_BIONIC_1ST_GEN_WIFI_CELL	APPLE IPAD PRO A1934 A12X BIONIC 1ST GEN WIFI & CELLULAR (2018)(64GB)(11")	iPad	\N	\N	\N	\N	20699.00	\N	\N	t	6	https://grest.in/products/apple-ipad-pro-a1934-a12x-bionic-1st-gen-wifi-cellular-201864gb11-1	https://cdn.shopify.com/s/files/1/0639/4576/9191/files/Frame_10_7_da2c6917-9d4a-499a-858a-5a3c47e51cff.png?v=1765964731	\N	{"specs": {}, "storage_options": ["64GB"], "colors": ["Silver", "Gray"], "conditions": ["Superb", "Good", "Fair"], "variant_count": 6, "price_range": "Rs. 20,699 - Rs. 22,999"}	2025-12-18 04:41:44.675585	2025-12-18 04:41:44.67559
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, conversation_id, role, content, sources, created_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, product_name, model, storage, condition, color, price_inr, mrp_inr, product_url, variant_id, in_stock, last_updated, created_at) FROM stdin;
\.


--
-- Data for Name: response_feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.response_feedback (id, conversation_id, rating, comment, created_at) FROM stdin;
\.


--
-- Data for Name: user_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_accounts (id, channel, external_id, email, display_name, profile_image, created_at, last_seen) FROM stdin;
1	google	test@example.com	test@example.com	Test User	\N	2025-12-04 05:36:09.043215	2025-12-04 05:37:15.246695
2	google	sammy@test.com	sammy@test.com	Sammy Test	\N	2025-12-04 05:57:17.51794	2025-12-04 07:34:48.243748
3	google	newuser@example.com	newuser@example.com	Priya Sharma	\N	2025-12-04 07:35:03.466696	2025-12-04 07:35:03.466701
4	google	test@summary.com	test@summary.com	Test User	\N	2025-12-04 07:53:18.237777	2025-12-04 07:59:12.042548
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, name, image, created_at, updated_at) FROM stdin;
\.


--
-- Name: analytics_daily_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.analytics_daily_id_seq', 1, false);


--
-- Name: chat_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.chat_sessions_id_seq', 118, true);


--
-- Name: conversation_summaries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.conversation_summaries_id_seq', 1, true);


--
-- Name: conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.conversations_id_seq', 224, true);


--
-- Name: feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.feedback_id_seq', 1, false);


--
-- Name: flagged_conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.flagged_conversations_id_seq', 1, false);


--
-- Name: grest_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.grest_products_id_seq', 19, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.messages_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_id_seq', 1, false);


--
-- Name: response_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.response_feedback_id_seq', 1, false);


--
-- Name: user_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_accounts_id_seq', 4, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: analytics_daily analytics_daily_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_daily
    ADD CONSTRAINT analytics_daily_pkey PRIMARY KEY (id);


--
-- Name: chat_sessions chat_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_pkey PRIMARY KEY (id);


--
-- Name: conversation_summaries conversation_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_summaries
    ADD CONSTRAINT conversation_summaries_pkey PRIMARY KEY (id);


--
-- Name: conversation_summaries conversation_summaries_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_summaries
    ADD CONSTRAINT conversation_summaries_user_id_key UNIQUE (user_id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: flagged_conversations flagged_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flagged_conversations
    ADD CONSTRAINT flagged_conversations_pkey PRIMARY KEY (id);


--
-- Name: grest_products grest_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grest_products
    ADD CONSTRAINT grest_products_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: response_feedback response_feedback_conversation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.response_feedback
    ADD CONSTRAINT response_feedback_conversation_id_key UNIQUE (conversation_id);


--
-- Name: response_feedback response_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.response_feedback
    ADD CONSTRAINT response_feedback_pkey PRIMARY KEY (id);


--
-- Name: user_accounts uq_channel_external_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_accounts
    ADD CONSTRAINT uq_channel_external_id UNIQUE (channel, external_id);


--
-- Name: user_accounts user_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_accounts
    ADD CONSTRAINT user_accounts_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_conversation_summaries_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversation_summaries_user_id ON public.conversation_summaries USING btree (user_id);


--
-- Name: idx_conversations_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversations_session ON public.conversations USING btree (session_id);


--
-- Name: idx_conversations_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversations_user ON public.conversations USING btree (user_id);


--
-- Name: idx_messages_conversation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_conversation ON public.messages USING btree (conversation_id);


--
-- Name: idx_products_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_category ON public.grest_products USING btree (category);


--
-- Name: idx_products_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_model ON public.products USING btree (model);


--
-- Name: idx_products_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_name ON public.products USING btree (product_name);


--
-- Name: idx_products_price; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_price ON public.grest_products USING btree (price);


--
-- Name: ix_analytics_daily_date; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_analytics_daily_date ON public.analytics_daily USING btree (date);


--
-- Name: ix_analytics_daily_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_analytics_daily_id ON public.analytics_daily USING btree (id);


--
-- Name: ix_chat_sessions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_sessions_id ON public.chat_sessions USING btree (id);


--
-- Name: ix_chat_sessions_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_chat_sessions_session_id ON public.chat_sessions USING btree (session_id);


--
-- Name: ix_chat_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_sessions_user_id ON public.chat_sessions USING btree (user_id);


--
-- Name: ix_conversations_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_conversations_id ON public.conversations USING btree (id);


--
-- Name: ix_conversations_safety_flagged; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_conversations_safety_flagged ON public.conversations USING btree (safety_flagged);


--
-- Name: ix_conversations_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_conversations_session_id ON public.conversations USING btree (session_id);


--
-- Name: ix_conversations_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_conversations_timestamp ON public.conversations USING btree ("timestamp");


--
-- Name: ix_grest_products_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_grest_products_category ON public.grest_products USING btree (category);


--
-- Name: ix_grest_products_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_grest_products_id ON public.grest_products USING btree (id);


--
-- Name: ix_grest_products_in_stock; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_grest_products_in_stock ON public.grest_products USING btree (in_stock);


--
-- Name: ix_grest_products_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_grest_products_name ON public.grest_products USING btree (name);


--
-- Name: ix_grest_products_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_grest_products_sku ON public.grest_products USING btree (sku);


--
-- Name: ix_response_feedback_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_response_feedback_id ON public.response_feedback USING btree (id);


--
-- Name: ix_user_accounts_channel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_accounts_channel ON public.user_accounts USING btree (channel);


--
-- Name: ix_user_accounts_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_accounts_email ON public.user_accounts USING btree (email);


--
-- Name: ix_user_accounts_external_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_accounts_external_id ON public.user_accounts USING btree (external_id);


--
-- Name: chat_sessions chat_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.user_accounts(id);


--
-- Name: conversation_summaries conversation_summaries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_summaries
    ADD CONSTRAINT conversation_summaries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.user_accounts(id);


--
-- Name: conversations conversations_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(session_id);


--
-- Name: conversations conversations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: feedback feedback_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id);


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- Name: response_feedback response_feedback_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.response_feedback
    ADD CONSTRAINT response_feedback_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- PostgreSQL database dump complete
--

\unrestrict vomfTflGBTsKDQrmq5ilv0FYtCcflWstoeSgd2qo7mDPwGZTC3K7GTdI0vHAMHf

