#!/bin/bash
# JoveHeal Restore Script
# Generated: 2025-12-18_21-43-51
#
# Usage:
#   1. Extract the backup archive
#   2. Set required environment variables (see env_template.json)
#   3. Run: bash restore.sh
#

echo "=========================================="
echo "  JoveHeal Restore Script"
echo "=========================================="

# Check for DATABASE_URL
if [ -z "$DATABASE_URL" ]; then
    echo "ERROR: DATABASE_URL environment variable not set!"
    echo "Please set DATABASE_URL to your PostgreSQL connection string."
    exit 1
fi

# Restore PostgreSQL
if [ -f "postgresql.sql" ]; then
    echo "[1/3] Restoring PostgreSQL database..."
    psql "$DATABASE_URL" < postgresql.sql
    if [ $? -eq 0 ]; then
        echo "      PostgreSQL restored successfully!"
    else
        echo "      ERROR: PostgreSQL restore failed!"
        exit 1
    fi
else
    echo "[1/3] No PostgreSQL backup found - skipping"
fi

# Restore ChromaDB
if [ -d "vector_db" ]; then
    echo "[2/3] Restoring ChromaDB vector database..."
    rm -rf ../vector_db 2>/dev/null
    cp -r vector_db ../
    echo "      ChromaDB restored successfully!"
else
    echo "[2/3] No ChromaDB backup found - skipping"
fi

# Restore Knowledge Base
if [ -d "knowledge_base" ]; then
    echo "[3/3] Restoring knowledge base..."
    rm -rf ../knowledge_base 2>/dev/null
    cp -r knowledge_base ../
    echo "      Knowledge base restored successfully!"
else
    echo "[3/3] No knowledge base backup found - skipping"
fi

echo ""
echo "=========================================="
echo "  RESTORE COMPLETE"
echo "=========================================="
echo ""
echo "Next steps:"
echo "1. Set all environment variables from env_template.json"
echo "2. Run: npm install && npm run build"
echo "3. Run: pip install -r requirements.txt"
echo "4. Start the application"
echo ""
