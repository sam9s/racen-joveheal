--
-- PostgreSQL database dump
--

\restrict 5uzTSp3Me2U2z7FmzLCKz51Kd0gewDpnS9MlY813IMXxMSsIxTDYVfzZ9JorBxF

-- Dumped from database version 16.11 (74c6bb6)
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.response_feedback DROP CONSTRAINT IF EXISTS response_feedback_conversation_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_conversation_id_fkey;
ALTER TABLE IF EXISTS ONLY public.feedback DROP CONSTRAINT IF EXISTS feedback_message_id_fkey;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_session_id_fkey;
ALTER TABLE IF EXISTS ONLY public.conversation_summaries DROP CONSTRAINT IF EXISTS conversation_summaries_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.chat_sessions DROP CONSTRAINT IF EXISTS chat_sessions_user_id_fkey;
DROP INDEX IF EXISTS public.ix_user_accounts_external_id;
DROP INDEX IF EXISTS public.ix_user_accounts_email;
DROP INDEX IF EXISTS public.ix_user_accounts_channel;
DROP INDEX IF EXISTS public.ix_response_feedback_id;
DROP INDEX IF EXISTS public.ix_grest_products_sku;
DROP INDEX IF EXISTS public.ix_grest_products_name;
DROP INDEX IF EXISTS public.ix_grest_products_in_stock;
DROP INDEX IF EXISTS public.ix_grest_products_id;
DROP INDEX IF EXISTS public.ix_grest_products_category;
DROP INDEX IF EXISTS public.ix_conversations_timestamp;
DROP INDEX IF EXISTS public.ix_conversations_session_id;
DROP INDEX IF EXISTS public.ix_conversations_safety_flagged;
DROP INDEX IF EXISTS public.ix_conversations_id;
DROP INDEX IF EXISTS public.ix_chat_sessions_user_id;
DROP INDEX IF EXISTS public.ix_chat_sessions_session_id;
DROP INDEX IF EXISTS public.ix_chat_sessions_id;
DROP INDEX IF EXISTS public.ix_analytics_daily_id;
DROP INDEX IF EXISTS public.ix_analytics_daily_date;
DROP INDEX IF EXISTS public.idx_voice_messages_call_id;
DROP INDEX IF EXISTS public.idx_voice_conversations_call_id;
DROP INDEX IF EXISTS public.idx_products_price;
DROP INDEX IF EXISTS public.idx_products_name;
DROP INDEX IF EXISTS public.idx_products_model;
DROP INDEX IF EXISTS public.idx_products_category;
DROP INDEX IF EXISTS public.idx_messages_conversation;
DROP INDEX IF EXISTS public.idx_error_logs_created_at;
DROP INDEX IF EXISTS public.idx_error_logs_call_id;
DROP INDEX IF EXISTS public.idx_conversations_user;
DROP INDEX IF EXISTS public.idx_conversations_session;
DROP INDEX IF EXISTS public.idx_conversation_summaries_user_id;
DROP INDEX IF EXISTS _system.idx_replit_database_migrations_v1_build_id;
ALTER TABLE IF EXISTS ONLY public.voice_messages DROP CONSTRAINT IF EXISTS voice_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.voice_conversations DROP CONSTRAINT IF EXISTS voice_conversations_pkey;
ALTER TABLE IF EXISTS ONLY public.voice_conversations DROP CONSTRAINT IF EXISTS voice_conversations_call_id_unique;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_accounts DROP CONSTRAINT IF EXISTS user_accounts_pkey;
ALTER TABLE IF EXISTS ONLY public.user_accounts DROP CONSTRAINT IF EXISTS uq_channel_external_id;
ALTER TABLE IF EXISTS ONLY public.response_feedback DROP CONSTRAINT IF EXISTS response_feedback_pkey;
ALTER TABLE IF EXISTS ONLY public.response_feedback DROP CONSTRAINT IF EXISTS response_feedback_conversation_id_key;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_pkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS ONLY public.grest_products DROP CONSTRAINT IF EXISTS grest_products_pkey;
ALTER TABLE IF EXISTS ONLY public.flagged_conversations DROP CONSTRAINT IF EXISTS flagged_conversations_pkey;
ALTER TABLE IF EXISTS ONLY public.feedback DROP CONSTRAINT IF EXISTS feedback_pkey;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_pkey;
ALTER TABLE IF EXISTS ONLY public.conversation_summaries DROP CONSTRAINT IF EXISTS conversation_summaries_user_id_key;
ALTER TABLE IF EXISTS ONLY public.conversation_summaries DROP CONSTRAINT IF EXISTS conversation_summaries_pkey;
ALTER TABLE IF EXISTS ONLY public.chat_sessions DROP CONSTRAINT IF EXISTS chat_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.backend_error_logs DROP CONSTRAINT IF EXISTS backend_error_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.analytics_daily DROP CONSTRAINT IF EXISTS analytics_daily_pkey;
ALTER TABLE IF EXISTS ONLY _system.replit_database_migrations_v1 DROP CONSTRAINT IF EXISTS replit_database_migrations_v1_pkey;
ALTER TABLE IF EXISTS public.voice_messages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.voice_conversations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_accounts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.response_feedback ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.products ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.messages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.grest_products ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.flagged_conversations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.feedback ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.conversations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.conversation_summaries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.chat_sessions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.backend_error_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.analytics_daily ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS _system.replit_database_migrations_v1 ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.voice_messages_id_seq;
DROP TABLE IF EXISTS public.voice_messages;
DROP SEQUENCE IF EXISTS public.voice_conversations_id_seq;
DROP TABLE IF EXISTS public.voice_conversations;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.user_accounts_id_seq;
DROP TABLE IF EXISTS public.user_accounts;
DROP SEQUENCE IF EXISTS public.response_feedback_id_seq;
DROP TABLE IF EXISTS public.response_feedback;
DROP SEQUENCE IF EXISTS public.products_id_seq;
DROP TABLE IF EXISTS public.products;
DROP SEQUENCE IF EXISTS public.messages_id_seq;
DROP TABLE IF EXISTS public.messages;
DROP SEQUENCE IF EXISTS public.grest_products_id_seq;
DROP TABLE IF EXISTS public.grest_products;
DROP SEQUENCE IF EXISTS public.flagged_conversations_id_seq;
DROP TABLE IF EXISTS public.flagged_conversations;
DROP SEQUENCE IF EXISTS public.feedback_id_seq;
DROP TABLE IF EXISTS public.feedback;
DROP SEQUENCE IF EXISTS public.conversations_id_seq;
DROP TABLE IF EXISTS public.conversations;
DROP SEQUENCE IF EXISTS public.conversation_summaries_id_seq;
DROP TABLE IF EXISTS public.conversation_summaries;
DROP SEQUENCE IF EXISTS public.chat_sessions_id_seq;
DROP TABLE IF EXISTS public.chat_sessions;
DROP SEQUENCE IF EXISTS public.backend_error_logs_id_seq;
DROP TABLE IF EXISTS public.backend_error_logs;
DROP SEQUENCE IF EXISTS public.analytics_daily_id_seq;
DROP TABLE IF EXISTS public.analytics_daily;
DROP SEQUENCE IF EXISTS _system.replit_database_migrations_v1_id_seq;
DROP TABLE IF EXISTS _system.replit_database_migrations_v1;
DROP SCHEMA IF EXISTS _system;
--
-- Name: _system; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA _system;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: replit_database_migrations_v1; Type: TABLE; Schema: _system; Owner: -
--

CREATE TABLE _system.replit_database_migrations_v1 (
    id bigint NOT NULL,
    build_id text NOT NULL,
    deployment_id text NOT NULL,
    statement_count bigint NOT NULL,
    applied_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: replit_database_migrations_v1_id_seq; Type: SEQUENCE; Schema: _system; Owner: -
--

CREATE SEQUENCE _system.replit_database_migrations_v1_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: replit_database_migrations_v1_id_seq; Type: SEQUENCE OWNED BY; Schema: _system; Owner: -
--

ALTER SEQUENCE _system.replit_database_migrations_v1_id_seq OWNED BY _system.replit_database_migrations_v1.id;


--
-- Name: analytics_daily; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.analytics_daily (
    id integer NOT NULL,
    date timestamp without time zone,
    total_conversations integer,
    unique_sessions integer,
    safety_flags integer,
    avg_response_time_ms double precision,
    positive_feedback integer,
    negative_feedback integer
);


--
-- Name: analytics_daily_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.analytics_daily_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: analytics_daily_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.analytics_daily_id_seq OWNED BY public.analytics_daily.id;


--
-- Name: backend_error_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backend_error_logs (
    id integer NOT NULL,
    error_type character varying(100) NOT NULL,
    endpoint character varying(255) NOT NULL,
    error_message text,
    request_data text,
    call_id character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: backend_error_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.backend_error_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: backend_error_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.backend_error_logs_id_seq OWNED BY public.backend_error_logs.id;


--
-- Name: chat_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_sessions (
    id integer NOT NULL,
    session_id character varying(100) NOT NULL,
    created_at timestamp without time zone,
    last_activity timestamp without time zone,
    channel character varying(50),
    user_id integer
);


--
-- Name: chat_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chat_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: chat_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.chat_sessions_id_seq OWNED BY public.chat_sessions.id;


--
-- Name: conversation_summaries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversation_summaries (
    id integer NOT NULL,
    user_id integer NOT NULL,
    emotional_themes text,
    recommended_programs text,
    last_topics text,
    conversation_status text,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: conversation_summaries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.conversation_summaries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: conversation_summaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.conversation_summaries_id_seq OWNED BY public.conversation_summaries.id;


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversations (
    id integer NOT NULL,
    session_id character varying(100),
    "timestamp" timestamp without time zone,
    user_question text NOT NULL,
    bot_answer text NOT NULL,
    safety_flagged boolean,
    safety_category character varying(100),
    sources_used text,
    response_time_ms integer,
    user_id integer
);


--
-- Name: conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.conversations_id_seq OWNED BY public.conversations.id;


--
-- Name: feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback (
    id integer NOT NULL,
    message_id integer,
    session_id character varying(255),
    rating character varying(20),
    comment text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.feedback_id_seq OWNED BY public.feedback.id;


--
-- Name: flagged_conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flagged_conversations (
    id integer NOT NULL,
    session_id character varying(255),
    user_message text,
    flag_reason character varying(100),
    severity character varying(20),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: flagged_conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.flagged_conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: flagged_conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.flagged_conversations_id_seq OWNED BY public.flagged_conversations.id;


--
-- Name: grest_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grest_products (
    id integer NOT NULL,
    sku character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    category character varying(100) NOT NULL,
    variant character varying(255),
    storage character varying(50),
    color character varying(100),
    condition character varying(100),
    price numeric(10,2) NOT NULL,
    original_price numeric(10,2),
    discount_percent integer,
    in_stock boolean,
    warranty_months integer,
    product_url character varying(500),
    image_url character varying(500),
    description text,
    specifications text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: grest_products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.grest_products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: grest_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.grest_products_id_seq OWNED BY public.grest_products.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    conversation_id integer,
    role character varying(20) NOT NULL,
    content text NOT NULL,
    sources text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id integer NOT NULL,
    product_name character varying(255) NOT NULL,
    model character varying(100),
    storage character varying(50),
    condition character varying(50),
    color character varying(100),
    price_inr numeric(10,2) NOT NULL,
    mrp_inr numeric(10,2),
    product_url text,
    variant_id character varying(100),
    in_stock boolean DEFAULT true,
    last_updated timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: response_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.response_feedback (
    id integer NOT NULL,
    conversation_id integer,
    rating integer NOT NULL,
    comment text,
    created_at timestamp without time zone
);


--
-- Name: response_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.response_feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: response_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.response_feedback_id_seq OWNED BY public.response_feedback.id;


--
-- Name: user_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_accounts (
    id integer NOT NULL,
    channel character varying(50) NOT NULL,
    external_id character varying(255) NOT NULL,
    email character varying(255),
    display_name character varying(255),
    profile_image character varying(500),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_seen timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: user_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_accounts_id_seq OWNED BY public.user_accounts.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    name character varying(255),
    image text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: voice_conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.voice_conversations (
    id integer NOT NULL,
    call_id character varying(255) NOT NULL,
    started_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    ended_at timestamp without time zone,
    caller_phone character varying(50),
    total_turns integer DEFAULT 0,
    full_transcript text,
    readiness_scores text,
    metadata text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: voice_conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.voice_conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: voice_conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.voice_conversations_id_seq OWNED BY public.voice_conversations.id;


--
-- Name: voice_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.voice_messages (
    id integer NOT NULL,
    call_id character varying(255) NOT NULL,
    turn_number integer NOT NULL,
    role character varying(20) NOT NULL,
    content text NOT NULL,
    readiness_score double precision,
    readiness_recommendation character varying(50),
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    latency_ms integer,
    call_ended boolean DEFAULT false,
    closure_type character varying(50),
    sources text
);


--
-- Name: voice_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.voice_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: voice_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.voice_messages_id_seq OWNED BY public.voice_messages.id;


--
-- Name: replit_database_migrations_v1 id; Type: DEFAULT; Schema: _system; Owner: -
--

ALTER TABLE ONLY _system.replit_database_migrations_v1 ALTER COLUMN id SET DEFAULT nextval('_system.replit_database_migrations_v1_id_seq'::regclass);


--
-- Name: analytics_daily id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_daily ALTER COLUMN id SET DEFAULT nextval('public.analytics_daily_id_seq'::regclass);


--
-- Name: backend_error_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backend_error_logs ALTER COLUMN id SET DEFAULT nextval('public.backend_error_logs_id_seq'::regclass);


--
-- Name: chat_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions ALTER COLUMN id SET DEFAULT nextval('public.chat_sessions_id_seq'::regclass);


--
-- Name: conversation_summaries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_summaries ALTER COLUMN id SET DEFAULT nextval('public.conversation_summaries_id_seq'::regclass);


--
-- Name: conversations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations ALTER COLUMN id SET DEFAULT nextval('public.conversations_id_seq'::regclass);


--
-- Name: feedback id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback ALTER COLUMN id SET DEFAULT nextval('public.feedback_id_seq'::regclass);


--
-- Name: flagged_conversations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flagged_conversations ALTER COLUMN id SET DEFAULT nextval('public.flagged_conversations_id_seq'::regclass);


--
-- Name: grest_products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grest_products ALTER COLUMN id SET DEFAULT nextval('public.grest_products_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: response_feedback id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.response_feedback ALTER COLUMN id SET DEFAULT nextval('public.response_feedback_id_seq'::regclass);


--
-- Name: user_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_accounts ALTER COLUMN id SET DEFAULT nextval('public.user_accounts_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: voice_conversations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.voice_conversations ALTER COLUMN id SET DEFAULT nextval('public.voice_conversations_id_seq'::regclass);


--
-- Name: voice_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.voice_messages ALTER COLUMN id SET DEFAULT nextval('public.voice_messages_id_seq'::regclass);


--
-- Data for Name: replit_database_migrations_v1; Type: TABLE DATA; Schema: _system; Owner: -
--

COPY _system.replit_database_migrations_v1 (id, build_id, deployment_id, statement_count, applied_at) FROM stdin;
1	20c7a807-9cd0-47b1-a975-68436082d247	e017467b-0c17-4ea8-a3b3-a56ecfdb13b9	7	2025-12-04 05:29:57.781614+00
2	504c1f41-d8c3-413b-b1d4-80de35cf925a	e017467b-0c17-4ea8-a3b3-a56ecfdb13b9	3	2025-12-04 08:08:11.264684+00
3	5537ac4a-acf6-467a-9479-19569ade4ec2	e017467b-0c17-4ea8-a3b3-a56ecfdb13b9	9	2025-12-16 05:34:54.922977+00
4	d00376f8-15ec-4d53-8de6-041942bf8a84	3e5fd974-49af-4fad-a546-0b5dc492e3f3	13	2025-12-18 20:35:24.852227+00
\.


--
-- Data for Name: analytics_daily; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.analytics_daily (id, date, total_conversations, unique_sessions, safety_flags, avg_response_time_ms, positive_feedback, negative_feedback) FROM stdin;
\.


--
-- Data for Name: backend_error_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backend_error_logs (id, error_type, endpoint, error_message, request_data, call_id, created_at) FROM stdin;
\.


--
-- Data for Name: chat_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_sessions (id, session_id, created_at, last_activity, channel, user_id) FROM stdin;
1	4899da78-0435-4830-a33a-55b9a91f0241	2025-12-01 08:03:57.637656	2025-12-01 08:03:57.637661	web	\N
2	api_test_test123_20251201081612	2025-12-01 08:16:16.880357	2025-12-01 08:16:16.880368	api_test	\N
3	api_test_test_user_20251201082053	2025-12-01 08:21:00.398881	2025-12-01 08:21:09.236373	api_test	\N
4	410377dd-2d3b-48d6-9a91-6a40556b30a1	2025-12-01 08:27:59.115906	2025-12-01 08:27:59.115911	web	\N
5	468c3529-639b-4bf7-8242-95aad6438b11	2025-12-01 09:33:55.215563	2025-12-01 09:43:39.896307	web	\N
6	302d0dfd-9320-4d5f-ad92-0f3a175d8c00	2025-12-01 09:58:15.534748	2025-12-01 09:58:54.132359	web	\N
7	568b4563-8ccf-4738-bca0-b09d0e1a3fd3	2025-12-01 10:05:37.356767	2025-12-01 10:07:46.648509	web	\N
8	eed23f1c-3d2e-4388-8078-a65d690c4f94	2025-12-01 10:24:47.581072	2025-12-01 10:24:47.581077	web	\N
9	860cab47-d476-44dc-af24-f3dda296dcc6	2025-12-01 11:03:38.128583	2025-12-01 11:03:38.128589	web	\N
10	7606ae71-395d-45d0-bafb-d5d39fc79661	2025-12-01 11:31:51.270514	2025-12-01 11:33:30.613827	web	\N
31	widget_1765438919562_nt5xnobh5	2025-12-11 07:42:03.947194	2025-12-11 07:42:27.635507	web	\N
22	guest_1765367682872_8q7z1bbly	2025-12-10 11:54:49.582654	2025-12-10 15:18:16.667886	web	\N
14	guest_1765334352475_kw41hmdko	2025-12-10 02:39:17.03249	2025-12-10 02:49:15.581506	web	\N
47	guest_1765777538347_88hnrpye3	2025-12-15 05:46:19.726585	2025-12-15 05:46:22.817252	web	\N
48	guest_1765782712010_hskcng00g	2025-12-15 07:11:57.206976	2025-12-15 07:12:06.242332	web	\N
23	widget_1765382409098_1db9m1m80	2025-12-10 16:00:15.667418	2025-12-10 16:02:07.316661	web	\N
41	guest_1765643777473_8mdvbelv7	2025-12-13 16:36:30.101716	2025-12-13 16:36:56.26277	web	\N
49	guest_1765901664370_jhupoh5a2	2025-12-16 16:16:21.368044	2025-12-16 16:16:37.747338	web	\N
66	test-nav-123	2025-12-26 07:11:54.8271	2025-12-26 07:11:56.435551	web	\N
34	widget_1765503406942_9ycxaty04	2025-12-12 01:37:01.964748	2025-12-12 01:44:08.797386	web	\N
24	widget_1765385859925_ohbgbnqpk	2025-12-10 16:57:47.021607	2025-12-10 17:01:26.315538	web	\N
15	manychat_joveheal	2025-12-10 04:16:40.569126	2025-12-10 05:17:10.255168	instagram	\N
62	guest_1766357876563_9ats9bckx	2025-12-21 22:58:01.768792	2025-12-21 22:58:37.076381	web	\N
25	widget_1765426468824_fqrczqp8m	2025-12-11 04:16:29.349352	2025-12-11 04:21:37.89633	web	\N
17	manychat_{{ig_username}}	2025-12-10 05:19:00.909214	2025-12-10 05:19:27.541009	instagram	\N
67	test-nav-456	2025-12-26 07:12:04.096905	2025-12-26 07:12:05.053688	web	\N
55	widget_1766073272490_8rn8d00s6	2025-12-18 20:58:33.799037	2025-12-19 03:31:59.884887	web	\N
26	widget_1765430879240_3bm8t6j9q	2025-12-11 05:28:19.983551	2025-12-11 05:28:57.094205	web	\N
42	guest_1765651681179_xul12m9vg	2025-12-13 18:49:25.404454	2025-12-13 18:50:34.153355	web	\N
16	manychat_misfitwhispers	2025-12-10 04:19:36.935173	2025-12-10 07:17:54.407737	instagram	\N
12	guest_1765099916643_4s5amanni	2025-12-07 09:32:04.40305	2025-12-07 09:32:45.652267	web	\N
18	guest_1765339157159_7hff6btzs	2025-12-10 07:56:09.114833	2025-12-10 07:56:18.343556	web	\N
33	widget_1765499845824_q3c8ofosv	2025-12-12 00:37:44.832997	2025-12-12 02:03:45.759865	web	\N
19	widget_1765359604549_83kjrd3dt	2025-12-10 09:40:13.396639	2025-12-10 09:40:42.356293	web	\N
13	guest_1765262136231_qgfyxo2mw	2025-12-09 06:35:41.21663	2025-12-09 06:37:23.491025	web	\N
27	widget_1765431022635_fytvmxlyy	2025-12-11 05:31:07.045438	2025-12-11 05:31:27.202925	web	\N
50	guest_1766047445454_vj0b13bxd	2025-12-18 08:44:10.250954	2025-12-18 08:49:35.181334	web	\N
20	widget_1765360928587_q9u6gkoh5	2025-12-10 10:02:27.472368	2025-12-10 10:03:58.854339	web	\N
35	widget_1765508790635_ui1x6n89g	2025-12-12 03:07:20.618714	2025-12-12 03:07:25.382458	web	\N
36	guest_1765513609094_akx12mqqk	2025-12-12 04:27:07.664632	2025-12-12 04:27:09.101732	web	\N
28	widget_1765431203933_cdydm19jc	2025-12-11 05:33:34.475495	2025-12-11 05:37:14.64384	web	\N
21	guest_1765366876708_emtvwnqc6	2025-12-10 11:41:21.487823	2025-12-10 11:42:22.234986	web	\N
37	widget_1765523327711_5q6v717tu	2025-12-12 07:09:02.702983	2025-12-12 07:09:08.565037	web	\N
29	widget_1765436832172_58w8hjjz9	2025-12-11 07:07:17.485648	2025-12-11 07:07:45.32375	web	\N
43	guest_1765651851548_q4es6ppvf	2025-12-13 18:50:56.913287	2025-12-13 18:51:13.294157	web	\N
56	test123	2025-12-19 12:00:42.52426	2025-12-19 12:00:47.182774	web	\N
30	widget_1765438841257_dk6ww1i1c	2025-12-11 07:40:47.545025	2025-12-11 07:41:23.869886	web	\N
57	guest_1766145648280_5g4p50kmm	2025-12-19 12:00:52.458277	2025-12-19 12:00:54.864715	web	\N
38	guest_1765548654880_m61c6bwk8	2025-12-12 14:13:54.677429	2025-12-12 14:15:58.542108	web	\N
44	guest_1765659228640_azn5h6fht	2025-12-13 20:54:31.091112	2025-12-13 20:55:25.393232	web	\N
58	guest_1766151560145_e95jxb99l	2025-12-19 13:42:44.777134	2025-12-19 13:42:50.688228	web	\N
52	widget_1765460033646_zs1d13ivj	2025-12-18 16:09:49.223153	2025-12-18 16:11:00.541292	web	\N
45	guest_1765703049006_6iw8g0tuz	2025-12-14 09:04:12.711698	2025-12-14 09:04:16.194841	web	\N
39	widget_1765565462246_otcd78yc7	2025-12-13 12:35:32.701782	2025-12-13 12:38:32.04593	web	\N
40	guest_1765634952452_u6pea2dkn	2025-12-13 14:09:18.508334	2025-12-13 14:10:00.777084	web	\N
53	guest_1766091478662_5mzxdikv9	2025-12-18 20:58:01.931496	2025-12-18 20:58:14.526955	web	\N
54	guest_1766091499601_abnmmb099	2025-12-18 20:58:21.692833	2025-12-18 20:58:23.799707	web	\N
46	widget_1765775334668_om9kpthp5	2025-12-15 05:36:17.887117	2025-12-15 05:37:24.855221	web	\N
59	guest_1766156847599_un3petir9	2025-12-19 15:07:32.452869	2025-12-19 15:07:44.277058	web	\N
63	guest_1766546440322_9tqt4d1vd	2025-12-24 03:20:47.32474	2025-12-24 03:21:19.1695	web	\N
60	guest_1766159816662_28bb3tduj	2025-12-19 15:56:59.879473	2025-12-19 15:57:03.328167	web	\N
64	guest_1766549320177_w54it4bo8	2025-12-24 04:08:43.529988	2025-12-24 04:08:56.191106	web	\N
11	user_sam27sep@gmail.com	2025-12-04 06:10:59.277373	2025-12-21 05:20:24.397755	web	1
51	widget_1765503401389_6kg5fjrty	2025-12-18 15:53:27.447619	2025-12-21 06:14:45.280853	web	\N
61	guest_1766302766633_z2dm0by0p	2025-12-21 07:39:30.753054	2025-12-21 07:39:41.350893	web	\N
72	widget-test-123	2025-12-26 08:32:47.043614	2025-12-26 08:32:49.16969	web	\N
68	test-nav-789	2025-12-26 07:12:13.561136	2025-12-26 07:12:22.859216	web	\N
69	test-nav-security	2025-12-26 07:12:45.22111	2025-12-26 07:12:46.371695	web	\N
65	guest_1766731243546_82bk4l9f8	2025-12-26 06:40:57.62436	2025-12-26 06:41:11.372432	web	\N
73	widget-test-456	2025-12-26 08:32:55.956128	2025-12-26 08:32:57.548443	web	\N
70	guest_1766734073091_l8hbtygt5	2025-12-26 07:27:58.744143	2025-12-26 07:29:11.12255	web	\N
71	guest_1766736921186_r3asw8f0r	2025-12-26 08:15:33.678757	2025-12-26 08:18:07.593828	web	\N
74	widget-test-new-123	2025-12-26 08:34:19.877335	2025-12-26 08:34:22.007235	web	\N
75	test-checkout-123	2025-12-26 09:12:16.219795	2025-12-26 09:12:17.471152	web	\N
32	widget_1765439706399_urrce96pp	2025-12-11 07:55:17.078513	2025-12-26 09:02:24.253669	web	\N
76	test-checkout-456	2025-12-26 09:12:23.196268	2025-12-26 09:12:33.903281	web	\N
77	test-discovery-789	2025-12-26 09:12:35.372248	2025-12-26 09:12:36.663099	web	\N
78	test-discovery-new-1	2025-12-26 09:13:07.289714	2025-12-26 09:13:08.473164	web	\N
79	test-inner-child-1	2025-12-26 09:13:12.278382	2025-12-26 09:13:12.35592	web	\N
80	test-inner-child-new	2025-12-26 09:13:51.748443	2025-12-26 09:13:51.82555	web	\N
81	test-checkout-final	2025-12-26 09:14:47.073293	2025-12-26 09:14:48.24474	web	\N
82	test-rel-heal	2025-12-26 09:35:06.451182	2025-12-26 09:35:07.577056	web	\N
83	test-bal-mast	2025-12-26 09:35:14.028956	2025-12-26 09:35:15.237571	web	\N
84	test-shed-shine	2025-12-26 09:35:15.991099	2025-12-26 09:35:16.893182	web	\N
85	test-elev-360	2025-12-26 09:35:18.116674	2025-12-26 09:35:19.300458	web	\N
86	test-shed-shine2	2025-12-26 09:35:27.305944	2025-12-26 09:35:28.511394	web	\N
87	test-elev-360-enroll	2025-12-26 09:35:29.253805	2025-12-26 09:35:30.235078	web	\N
88	test-elev-360-join	2025-12-26 09:35:50.009803	2025-12-26 09:35:50.904621	web	\N
89	test-elev-360-final	2025-12-26 09:37:30.078646	2025-12-26 09:37:31.464646	web	\N
90	test-elev-buy	2025-12-26 09:37:39.270939	2025-12-26 09:37:40.225086	web	\N
91	test-iml	2025-12-26 09:37:41.552941	2025-12-26 09:37:42.445723	web	\N
92	test-career-healing	2025-12-26 09:37:55.547291	2025-12-26 09:37:56.664324	web	\N
93	test-relationship-healing	2025-12-26 09:37:57.738825	2025-12-26 09:37:58.726646	web	\N
94	test-beyond-the-hustle	2025-12-26 09:37:59.296656	2025-12-26 09:38:00.576812	web	\N
95	test-inner-reset	2025-12-26 09:38:01.186287	2025-12-26 09:38:02.096045	web	\N
96	test-shed-and-shine	2025-12-26 09:38:02.66686	2025-12-26 09:38:03.703509	web	\N
97	test-money-and-abundance	2025-12-26 09:38:04.387621	2025-12-26 09:38:05.513244	web	\N
98	test-meta-u	2025-12-26 09:38:06.270547	2025-12-26 09:38:07.516127	web	\N
99	test-healing-circle	2025-12-26 09:38:08.227668	2025-12-26 09:38:09.219082	web	\N
100	test-elevate-360	2025-12-26 09:38:09.776512	2025-12-26 09:38:10.850654	web	\N
101	test-balance-mastery	2025-12-26 09:38:11.511036	2025-12-26 09:38:12.727766	web	\N
102	test-inner-mastery-lounge	2025-12-26 09:38:13.381036	2025-12-26 09:38:14.560463	web	\N
103	test-inner-reset-final	2025-12-26 09:38:55.722178	2025-12-26 09:38:56.729783	web	\N
110	test_ratelimit_session	2025-12-27 10:39:27.168657	2025-12-27 10:39:47.61826	web	\N
107	widget_1766743288779_1q6yw6hbm	2025-12-26 10:02:34.373682	2025-12-26 10:05:27.276934	web	\N
104	widget_1766742685773_vcxw3yoq7	2025-12-26 09:51:30.506565	2025-12-26 09:59:43.609934	web	\N
105	widget_1766743211913_4qluridey	2025-12-26 10:00:41.678723	2025-12-26 10:00:43.244448	web	\N
106	widget_1766743243552_vuyrpdkzt	2025-12-26 10:00:55.963686	2025-12-26 10:01:16.661156	web	\N
108	widget_1766785483673_t52drs50z	2025-12-26 21:45:09.198967	2025-12-26 22:03:57.955427	web	\N
109	widget_1766787170447_h4tqsfpgf	2025-12-26 22:12:54.707138	2025-12-26 22:15:50.031025	web	\N
\.


--
-- Data for Name: conversation_summaries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversation_summaries (id, user_id, emotional_themes, recommended_programs, last_topics, conversation_status, updated_at) FROM stdin;
1	1	[feeling overwhelmed]	[Beyond the Hustle, Balance Mastery]	The conversation primarily revolved around the user's feelings of overwhelm and the assistant's suggestions to explore specific programs offered by JoveHeal.	exploring programs	2025-12-21 05:20:25.95756
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversations (id, session_id, "timestamp", user_question, bot_answer, safety_flagged, safety_category, sources_used, response_time_ms, user_id) FROM stdin;
1	4899da78-0435-4830-a33a-55b9a91f0241	2025-12-01 08:03:57.409036	What services does JoveHeal offer?	JoveHeal offers a variety of wellness coaching services aimed at personal transformation and holistic well-being. Here are the main services we provide:\n\n1. **Balance Mastery+ Program**: \n   - A signature coaching experience designed to help you develop clarity about life goals, build sustainable routines, and master your mindset.\n\n2. **Inner Mastery Lounge**:\n   - An exclusive membership community that includes weekly group coaching sessions, access to guided meditations and exercises, community support, and monthly masterclasses on personal development.\n\n3. **Healing Sessions**:\n   - Available in both individual and group formats, these sessions focus on energy alignment, stress relief, emotional release, and mindfulness practices.\n\n4. **Workshops**:\n   - Regular workshops on topics like goal setting, mindset transformation, stress management, and confidence building, available both in-person and online.\n\nFeel free to reach out if you have more specific questions about any of these services!	f	\N	["joveheal_sample.txt"]	\N	\N
2	api_test_test123_20251201081612	2025-12-01 08:16:15.749417	What programs does JoveHeal offer?	JoveHeal offers several programs and services, including:\n\n1. **Balance Mastery+ Program**: This is the signature coaching experience designed to help individuals develop clarity about their life goals, build sustainable daily routines, master their mindset, create work-life balance, and develop confidence and self-leadership skills. The program typically runs for 8-12 weeks.\n\n2. **Inner Mastery Lounge**: This is an exclusive membership community that includes weekly group coaching sessions, access to guided meditations and exercises, community support, monthly masterclasses on personal development topics, and exclusive resources for members.\n\nAdditionally, JoveHeal offers individual and group healing sessions focused on energy alignment, stress relief, emotional release, and mindfulness practices. Regular workshops on topics such as goal setting, mindset transformation, and self-care are also available.\n\nFor more information about joining any of these programs, you can visit their website at www.joveheal.com.	f	\N	["joveheal_sample.txt"]	\N	\N
3	api_test_test_user_20251201082053	2025-12-01 08:20:57.046012	What is Balance Mastery?	The Balance Mastery+ program is JoveHeal's signature coaching experience designed to help individuals achieve personal transformation and clarity. This program focuses on several key areas, including:\n\n- Developing clarity about your life goals and direction\n- Building sustainable daily routines for success\n- Mastering your mindset and overcoming limiting beliefs\n- Creating a work-life balance that truly works\n- Developing confidence and self-leadership skills\n\nThe program typically runs for 8-12 weeks and provides personalized guidance and support to help participants unlock their potential and create lasting positive change in their lives. If you're interested in this program, I recommend visiting the JoveHeal website for more details.	f	\N	["joveheal_sample.txt"]	\N	\N
4	api_test_test_user_20251201082053	2025-12-01 08:21:09.043818	What is Balance Mastery?	The Balance Mastery+ program is JoveHeal's signature coaching experience aimed at helping individuals achieve personal transformation and clarity. Key focuses of this program include:\n\n- Developing clarity about life goals and direction\n- Building sustainable daily routines for success\n- Mastering mindset and overcoming limiting beliefs\n- Creating effective work-life balance\n- Developing confidence and self-leadership skills\n\nTypically, the program runs for 8-12 weeks and offers personalized guidance and support. For more information, you can check the JoveHeal website.	f	\N	["joveheal_sample.txt"]	\N	\N
5	410377dd-2d3b-48d6-9a91-6a40556b30a1	2025-12-01 08:27:58.896119	What programs does JoveHeal offer?	JoveHeal offers several programs focused on wellness coaching and personal transformation:\n\n1. **Balance Mastery+ Program**: This is our signature coaching experience designed to help you:\n   - Develop clarity about your life goals and direction\n   - Build sustainable daily routines for success\n   - Master your mindset and overcome limiting beliefs\n   - Create work-life balance that actually works\n   - Develop confidence and self-leadership skills\n\n2. **Inner Mastery Lounge**: This is an exclusive membership community that includes:\n   - Weekly group coaching sessions\n   - Access to guided meditations and exercises\n   - Community support and networking\n   - Monthly masterclasses on personal development topics\n   - Exclusive resources and tools for members\n\nWe also offer healing sessions, both individual and group, focusing on energy alignment, stress relief, and mindfulness practices.\n\nIf you have more specific questions about these programs or how to get started, feel free to ask!	f	\N	["joveheal_sample.txt"]	\N	\N
6	468c3529-639b-4bf7-8242-95aad6438b11	2025-12-01 09:33:54.99065	hi what programms yo uoffer?	At JoveHeal, we offer several programs designed to support your wellness journey:\n\n1. **Balance Mastery+ Program**: This is our signature coaching experience that helps you:\n   - Develop clarity about your life goals and direction\n   - Build sustainable daily routines for success\n   - Master your mindset and overcome limiting beliefs\n   - Create work-life balance that actually works\n   - Develop confidence and self-leadership skills\n\n2. **Inner Mastery Lounge**: This is our exclusive membership community that includes:\n   - Weekly group coaching sessions\n   - Access to guided meditations and exercises\n   - Community support and networking\n   - Monthly masterclasses on personal development topics\n   - Exclusive resources and tools for members\n\nAdditionally, we offer individual and group healing sessions focused on energy alignment, stress relief, emotional clarity, and mindfulness practices.\n\nIf you would like more details about a specific program, feel free to ask!	f	\N	["joveheal_sample.txt"]	\N	\N
7	468c3529-639b-4bf7-8242-95aad6438b11	2025-12-01 09:36:53.714989	can you tell me how do I increase my confidence?	While I can't provide specific advice, I can share general concepts that might be helpful in boosting confidence. \n\nParticipating in workshops, such as our **Confidence and Self-Leadership** workshop at JoveHeal, can provide valuable strategies and insights for building self-confidence. Additionally, consistent practice of setting and achieving small goals can help create a sense of accomplishment.\n\nJoining a supportive community, like the **Inner Mastery Lounge**, can offer encouragement and shared experiences that foster confidence. Engaging in regular self-reflection and mindfulness practices may also contribute to a stronger sense of self-worth.\n\nIf you’re interested in exploring these options as a way to build your confidence, feel free to ask about our programs or workshops!	f	\N	["joveheal_sample.txt"]	\N	\N
8	468c3529-639b-4bf7-8242-95aad6438b11	2025-12-01 09:37:37.446233	what program do you offer specifically for this purpose?	For building confidence, the **Balance Mastery+ Program** includes components that focus on developing confidence and self-leadership skills. This program guides you in mastering your mindset and overcoming limiting beliefs, which are crucial for increasing self-confidence.\n\nAdditionally, our **Confidence and Self-Leadership** workshop specifically targets skills and strategies to enhance your confidence. Participating in this workshop can provide practical tools and insights to help you on your confidence journey.\n\nIf you’d like more information on how to join these programs, just let me know!	f	\N	["joveheal_sample.txt"]	\N	\N
9	468c3529-639b-4bf7-8242-95aad6438b11	2025-12-01 09:43:36.96863	do you offer relationship healing ... if yes share details?	Currently, JoveHeal focuses on wellness coaching and healing sessions that primarily include energy alignment, stress relief, emotional clarity, and mindfulness practices. While our services can support personal growth and emotional wellness, we do not specifically offer relationship healing programs.\n\nIf you're interested in personal development or healing, our individual and group healing sessions may provide benefits that can contribute to overall emotional well-being. Feel free to explore our programs or ask about any other topics that may interest you!	f	\N	["joveheal_sample.txt"]	\N	\N
10	302d0dfd-9320-4d5f-ad92-0f3a175d8c00	2025-12-01 09:58:15.305637	What is relationship healing?	Relationship Healing at JoveHeal is a 3-hour deep healing session designed for individuals, particularly women, who seek to enhance intimacy and fulfillment in their relationships. It goes beyond surface-level solutions, focusing on root-level healing to dissolve old wounds and facilitate real transformation.\n\nKey components of Relationship Healing include:\n\n- **Guided Wound Release:** This helps to dissolve emotional pain associated with past experiences.\n- **The Mirror Principle:** This technique transforms relationship triggers into deeper connections.\n- **The 5 Core Wounds Map:** This tool enables participants to understand recurring patterns in their relationships and learn how to overcome them.\n\nThis healing space aims to help you turn conflicts into opportunities for deeper connection, rebuild trust, and reconnect with yourself, allowing you to show up with love and clarity in all your relationships. \n\nIf you're interested or have more questions, feel free to ask!	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt"]	\N	\N
11	302d0dfd-9320-4d5f-ad92-0f3a175d8c00	2025-12-01 09:58:53.933678	Tell me about Balance Mastery	Balance Mastery is a signature 3-month program at JoveHeal specifically designed for high-performing leaders who are seeking to restore balance in their lives. This program is aimed at those who may feel successful externally but are experiencing internal stress and misalignment.\n\nKey features of the Balance Mastery program include:\n\n- **Premium One-on-One Coaching:** You will have personalized sessions where you can uncover root causes, clear emotional and energetic blocks, and realign your inner landscape for a more harmonious outer life.\n- **Deep Root Healing:** This component helps you to identify and release limiting patterns.\n- **Blueprint Shift Work:** A focus on creating lasting transformation.\n- **Tools and Practices for Sustainable Change:** You will receive methodologies to support ongoing growth and balance.\n- **Personalized Support:** Throughout your journey, you will have access to dedicated support to help you achieve your goals.\n\nThis program is ideal for high-achieving professionals who want to deepen their relationships, lead with impact, and live with inner peace while overcoming the feelings of disconnection that often accompany success.\n\nIf you'd like more information or have specific questions about the program, feel free to ask!	f	\N	["website_services.txt", "website_balance_mastery.txt", "joveheal_sample.txt"]	\N	\N
12	568b4563-8ccf-4738-bca0-b09d0e1a3fd3	2025-12-01 10:05:37.137451	do you offer relationship healing ... if yes share details?	Yes, JoveHeal offers a Relationship Healing session designed for individuals seeking to enhance intimacy and fulfillment in their relationships. \n\n**Details of the Relationship Healing session:**\n- **Duration:** 3 hours\n- **Focus:** This deep healing session goes beyond quick fixes, guiding you into root-level healing where old wounds can dissolve and true transformation occurs.\n- **Key Components:**\n  - **Guided Wound Release:** Helps dissolve emotional pain.\n  - **The Mirror Principle:** Teaches how to transform relationship triggers into deeper connections.\n  - **The 5 Core Wounds Map:** Aids in understanding why patterns repeat in relationships and how to stop them.\n\nThis session is an opportunity to heal wounds that impact all your relationships, allowing you to show up with love and clarity.\n\nIf you have any more questions or need further information, feel free to ask!	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt", "website_balance_mastery.txt"]	\N	\N
13	568b4563-8ccf-4738-bca0-b09d0e1a3fd3	2025-12-01 10:07:43.746671	thank you .. ok my issue is I feel sad disconnected, weighed down, whats the best program do you offer for this ?	For feelings of sadness, disconnection, and being weighed down, the **Inner Reset** course would be a great fit for you. \n\n**Details about the Inner Reset:**\n- **Focus:** This self-paced healing course is designed for high-performing individuals who feel soul-tired, disconnected, or burdened by emotions that rest and busyness can't seem to fix.\n- **Key Features:**\n  - Guides you through powerful practices such as inner child healing, emotional release, energetic clearing, and self-love activation.\n  - Allows you to move through the material at your own rhythm, providing lifetime access so you can revisit the process whenever needed.\n\nThis course invites you to pause and reconnect with who you truly are, beneath the pressures and survival patterns. \n\nIf this sounds like a good fit for you or if you have any other questions, feel free to ask!	f	\N	["website_elevate360.txt", "website_inner_mastery_lounge.txt", "website_services.txt"]	\N	\N
14	eed23f1c-3d2e-4388-8078-a65d690c4f94	2025-12-01 10:24:47.233988	any membership you provide?	Yes, JoveHeal offers the **Inner Mastery Lounge**, which is our exclusive membership community. Membership includes the following benefits:\n\n- Weekly group coaching sessions\n- Access to guided meditations and exercises\n- Community support and networking\n- Monthly masterclasses on personal development topics\n- Exclusive resources and tools for members\n\nMembers also have access to all recorded sessions, allowing for a comprehensive experience in a supportive community of like-minded individuals. If you're interested in joining, please visit our website for more details!	f	\N	["joveheal_sample.txt", "website_elevate360.txt", "website_balance_mastery.txt"]	\N	\N
15	860cab47-d476-44dc-af24-f3dda296dcc6	2025-12-01 11:03:37.905214	Who is the coach behind JoveHeal and what is their background?	The coach behind JoveHeal has over 20 years of experience in corporate leadership, specializing in Agile transformation and executive delivery. They went through a profound healing journey that reshaped their approach to coaching. Traditionally focused on strategy, this coach realized that emotional and energetic healing is essential for true transformation. \n\nTheir work now emphasizes guiding high-achieving executives and entrepreneurs to uncover and clear emotional patterns that may lead to burnout and decision fatigue, helping them lead from a place of wholeness. This unique blend of coaching integrates modern techniques with holistic wellness principles to foster profound personal transformation. \n\nIf you have any more questions about JoveHeal's services or programs, feel free to ask!	f	\N	["website_homepage.txt", "joveheal_sample.txt"]	\N	\N
16	7606ae71-395d-45d0-bafb-d5d39fc79661	2025-12-01 11:31:50.924017	I have a broken marriage .. and I am depressed, what course do you suggest?	I'm sorry to hear that you're going through such a difficult time. While I can't provide advice on healing your marriage or addressing feelings of depression, I can share information about JoveHeal's programs that may be helpful.\n\nYou might consider the **Relationship Healing** session, which is designed to help you work through core relationship wounds and enhance connection in your relationships. It's a deep healing session that focuses on transformative healing rather than quick fixes.\n\nIf you're looking for a more comprehensive approach, the **Inner Mastery Lounge** membership is also available. This program supports those who have outgrown surface-level solutions and are ready for deeper shifts in their relationships and personal well-being.\n\nFor personalized support specific to your situation, I encourage reaching out to a licensed therapist or counselor. If you have any more questions about the programs or how to get involved, feel free to ask!	f	\N	["website_balance_mastery.txt", "website_inner_mastery_lounge.txt", "website_elevate360.txt"]	\N	\N
17	7606ae71-395d-45d0-bafb-d5d39fc79661	2025-12-01 11:32:15.789454	ok how do I enroll to this course ..	To enroll in the Relationship Healing course or any other program at JoveHeal, you can visit our website at www.joveheal.com. Once there, please use the contact form for inquiries about specific courses, membership options, and any enrollment processes.\n\nIf you have further questions about the courses or need assistance, feel free to ask!	f	\N	["website_inner_mastery_lounge.txt", "joveheal_sample.txt", "website_services.txt"]	\N	\N
18	7606ae71-395d-45d0-bafb-d5d39fc79661	2025-12-01 11:33:30.420205	I some times feel to take my own life can you help?	I'm really sorry to hear that you're feeling this way. It's very important to speak with someone who can help you, like a licensed therapist or mental health professional. If you're in immediate distress, please reach out to a crisis hotline or local support services in your area. You don't have to go through this alone—there are people who want to help you.\n\nPlease take care of yourself, and I encourage you to seek the support you deserve.	f	\N	["website_elevate360.txt", "website_balance_mastery.txt", "website_beyond_the_hustle.txt"]	\N	\N
19	user_sam27sep@gmail.com	2025-12-04 06:11:10.404169	hi	Hi there! I'm RACEN, your guide for exploring JoveHeal's healing and coaching programs. What brings you here today? Whether you have questions or just want to know more about our offerings, I'm here to help!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Balance Mastery](https://joveheal.com/balance-mastery/) | [Services](https://joveheal.com/services/) | [Healing Sessions](https://joveheal.com/healing-sessions/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
20	user_sam27sep@gmail.com	2025-12-04 06:11:55.760908	I am suffering from a self low esteem what should I do?	I’m really sorry to hear that you’re feeling this way; it’s completely understandable to struggle with self-esteem at times. While I can't provide personal advice, I can share that JoveHeal offers programs like "[Shed & Shine](https://joveheal.com/shed-and-shine/)," which help release emotional weight and improve self-esteem. Would you like to learn more about that, or would you prefer to connect with our team for personalized support?	f	\N	["website_elevate360.txt", "website_shed_and_shine.txt", "website_testimonials.txt"]	\N	\N
21	user_sam27sep@gmail.com	2025-12-04 06:12:19.40124	please provide me details on this program...	I apologize for the confusion, but I don't have specific details on a program called "[Shed & Shine](https://joveheal.com/shed-and-shine/)." However, if you're interested in enhancing self-esteem, our "[Balance Mastery+](https://joveheal.com/balance-mastery/)" program could be beneficial. It focuses on inner alignment, revealing limiting patterns, and creating lasting transformation. \n\nWould you like to know more about [Balance Mastery](https://joveheal.com/balance-mastery/)+ or connect with JoveHeal's team for further details?	f	\N	["website_services.txt", "website_balance_mastery.txt", "joveheal_sample.txt"]	\N	\N
22	user_sam27sep@gmail.com	2025-12-04 07:16:55.887029	hi	Hi there! Welcome back! I'm RACEN, here to assist you with any questions about JoveHeal's coaching and healing programs. What can I help you with today?\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Balance Mastery](https://joveheal.com/balance-mastery/) | [Services](https://joveheal.com/services/) | [Healing Sessions](https://joveheal.com/healing-sessions/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
23	user_sam27sep@gmail.com	2025-12-04 07:17:58.87536	I feel disconnected from the society ... alone and dejected can you assist	I'm really sorry to hear you're feeling this way; it’s completely valid to feel disconnected at times. It sounds tough, and I want you to know you’re not alone in this. JoveHeal offers a program called "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" that focuses on uncovering emotional patterns and fostering genuine connections. Would you like to learn more about this program or connect with our team for additional support?	f	\N	["website_elevate360.txt", "website_beyond_the_hustle.txt", "website_balance_mastery.txt"]	\N	\N
24	user_sam27sep@gmail.com	2025-12-04 07:18:20.161466	please provide more details for the program .	Absolutely! The "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" program is a transformative masterclass designed for individuals who may appear successful externally but feel drained and disconnected internally. Here’s what it offers:\n\n- **Awareness:** Understand the hidden patterns that shape your career, relationships, and energy.\n- **Guided Healing:** Experience a healing shift to release a limiting belief in real-time.\n- **Practical Insights:** Gain tools on how to rebuild your life from your inner truth rather than external pressures.\n\nThis program aims to help you reconnect with yourself and find fulfillment. If you're interested, I can connect you with JoveHeal's team for more information or to get started!	f	\N	["website_services.txt", "website_balance_mastery.txt", "joveheal_sample.txt"]	\N	\N
25	user_sam27sep@gmail.com	2025-12-04 07:19:13.673182	please provide details how I can contact the coach directly.	To contact JoveHeal directly, you can use the contact form available on their website. Here’s how you can reach out:\n\n1. Visit [JoveHeal's Contact Page](https://www.joveheal.com/contact).\n2. Fill out the form with your name, email, country, and a message detailing your inquiries or how you'd like to connect.\n\nThe team will get back to you to assist further. If you need any help with the process, feel free to ask!	f	\N	["joveheal_sample.txt", "website_services.txt", "website_contact.txt"]	\N	\N
26	user_sam27sep@gmail.com	2025-12-04 07:43:48.052364	hi	Hi Sammy! It's great to hear from you again. How can I assist you today? Whether you have questions or just need to chat, I'm here for you!	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
27	user_sam27sep@gmail.com	2025-12-04 07:44:23.913652	what was the last discussion we were having?	Last time, we talked about how you can contact JoveHeal directly for more information or to connect with a coach. If there's anything specific you want to continue discussing or if you have new questions, feel free to let me know!	f	\N	["website_balance_mastery.txt", "website_about.txt", "website_career_healing.txt"]	\N	\N
28	user_sam27sep@gmail.com	2025-12-04 07:44:53.185733	No I mean , the issue I discussed with you and the program you suggested..	I apologize for not recalling that specific information, Sammy. However, I remember you shared feelings of stress before. I mentioned that JoveHeal offers programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)," which can help uncover emotional roots of exhaustion. If you'd like to explore more about that, or if there's something else on your mind, please let me know!	f	\N	["website_contact.txt", "website_balance_mastery.txt", "website_about.txt"]	\N	\N
29	user_sam27sep@gmail.com	2025-12-04 08:13:23.0522	hi	Hi again, Sammy! Welcome back! How can I help you today? Whether you have questions about programs, need support, or anything else, I'm here for you.\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
30	user_sam27sep@gmail.com	2025-12-04 08:13:50.203878	what were we discussing last?	Last time, we talked about your feelings of stress and I suggested looking into JoveHeal's program "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)," which focuses on uncovering emotional roots of exhaustion. If there’s something specific you want to revisit or any new questions you have, just let me know!	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
31	user_sam27sep@gmail.com	2025-12-04 10:41:40.043765	hi	Hi again, Sammy! Great to see you back! How can I support you today? Whether you want to talk about your stress, explore more programs, or anything else on your mind, I’m here to help.\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Reset](https://joveheal.com/inner-reset/) | [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) | [Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
32	user_sam27sep@gmail.com	2025-12-04 10:42:02.65069	hi do you remember what we were discussion before?	I don't have details about our previous conversations right now, but I'm happy to help with whatever's on your mind today! If there's a specific topic or question you want to return to, feel free to share!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Reset](https://joveheal.com/inner-reset/) | [Balance Mastery](https://joveheal.com/balance-mastery/)	f	\N	["website_balance_mastery.txt", "website_testimonials.txt"]	\N	\N
33	user_sam27sep@gmail.com	2025-12-04 10:45:34.520073	hi	Hi there, Sammy! It’s great to hear from you again! What would you like to talk about today? If you have any questions or need support, I'm here for you.\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
34	user_sam27sep@gmail.com	2025-12-04 10:45:59.146659	I am not able to cope with life struggles	I'm really sorry to hear that you're feeling this way, Sammy. Life can be overwhelming at times, and it's completely understandable to feel like you're struggling. While I can’t offer therapy, I want you to know that programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" at JoveHeal can help address emotional exhaustion and uncover deeper roots. Would you like more information on that or assistance connecting with our team?	f	\N	["website_inner_mastery_lounge.txt", "website_services.txt", "joveheal_sample.txt"]	\N	\N
35	user_sam27sep@gmail.com	2025-12-04 10:46:19.619243	please give me details of this programm	I apologize, but I don't have specific details about a program called "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" in my knowledge base. However, JoveHeal offers the [Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) and the [Balance Mastery](https://joveheal.com/balance-mastery/)+ program, which focus on personal development, stress relief, and emotional healing. \n\nIf you're interested in those, I can share more about them! Or, if you want to inquire specifically about "Beyond the Hustle," I recommend reaching out to JoveHeal directly. Would you like to know more about the Inner Mastery Lounge or Balance Mastery+?	f	\N	["joveheal_sample.txt", "website_inner_mastery_lounge.txt", "website_services.txt"]	\N	\N
36	user_sam27sep@gmail.com	2025-12-06 04:14:36.987842	hi	Hi Sammy! Great to see you back! I remember you mentioned feeling overwhelmed and struggling with life issues in our last chat. Would you like to continue discussing the programs we talked about, or is there something else on your mind today?\n\n---\n\n*Feel free to explore more when you're ready:*\n[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) | [Inner Reset](https://joveheal.com/inner-reset/) | [Balance Mastery](https://joveheal.com/balance-mastery/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
37	user_sam27sep@gmail.com	2025-12-06 04:24:52.977323	hi	Hi there, Sammy! It's lovely to connect with you again! How can I assist you today? Whether you have questions or just want to share, I'm here for you.	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
38	guest_1765099916643_4s5amanni	2025-12-07 09:32:16.624841	hi	Hi there! I'm RACEN, your guide for exploring JoveHeal's healing and coaching programs. What brings you here today? I'm here to help with any questions or support you might need!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Balance Mastery](https://joveheal.com/balance-mastery/) | [Services](https://joveheal.com/services/) | [Healing Sessions](https://joveheal.com/healing-sessions/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
39	guest_1765099916643_4s5amanni	2025-12-07 09:32:45.520815	what is balance mastery program?	The [Balance Mastery](https://joveheal.com/balance-mastery/) program is a 3-month premium one-on-one coaching experience designed for high-performing leaders who feel successful on the outside but are struggling internally. It focuses on uncovering root causes of stress, clearing emotional blocks, and realigning your inner landscape for greater balance. Throughout the program, you’ll receive personalized support, deep healing work, and tools for sustainable change. If you’re interested, I can provide more details or connect you with the JoveHeal team!	f	\N	["website_services.txt", "website_balance_mastery.txt", "joveheal_sample.txt"]	\N	\N
40	guest_1765262136231_qgfyxo2mw	2025-12-09 06:35:50.446	Hi	Hi there! I'm RACEN, your guide for exploring JoveHeal's healing and coaching programs. What brings you here today? Whether you're curious about our offerings, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Balance Mastery](https://joveheal.com/balance-mastery/) | [Services](https://joveheal.com/services/) | [Healing Sessions](https://joveheal.com/healing-sessions/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
67	manychat_misfitwhispers	2025-12-10 07:17:54.279179	yes please	Hi Samret! It looks like you might be looking for something specific. Could you share a bit more about what you're interested in? I'm here to help!	f	\N	["https://www.joveheal.com/inner-mastery-lounge", "https://www.joveheal.com/services", "https://www.joveheal.com"]	\N	\N
41	guest_1765262136231_qgfyxo2mw	2025-12-09 06:36:12.740015	How can i book an appointment	Booking an appointment with JoveHeal is easy! You can start by visiting our website at www.joveheal.com. From there, you can book a discovery call to discuss your goals and find the program or service that suits you best. If you need more help or have questions, feel free to let me know!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Balance Mastery](https://joveheal.com/balance-mastery/) | [Career Healing](https://joveheal.com/career-healing/)	f	\N	["joveheal_sample.txt", "website_contact.txt", "website_elevate360.txt"]	\N	\N
42	guest_1765262136231_qgfyxo2mw	2025-12-09 06:37:08.158437	You are very costly	I understand that cost can be a concern when it comes to investing in personal growth and healing. JoveHeal offers various programs and membership options, some of which provide exclusive discounts and significant value. If you’d like, I can help you explore more affordable options or how to maximize the value you receive. Just let me know!\n\n---\n\n*You might find membership options helpful:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)	f	\N	["website_inner_mastery_lounge.txt", "website_testimonials.txt"]	\N	\N
43	guest_1765262136231_qgfyxo2mw	2025-12-09 06:37:23.350709	But i dont have money	I'm really sorry to hear that you're facing financial challenges — that can be really tough. While I can’t provide specific financial advice, I recommend reaching out to JoveHeal directly to discuss any options they may have available for those in need or any potential scholarships. Their team is there to help support you in your journey.\n\n---\n\n*If you're interested, I can guide you on how to reach out to them! Just let me know.*\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Money and Abundance](https://joveheal.com/money-abundance-manifestation/)	f	\N	["website_inner_mastery_lounge.txt", "website_beyond_the_hustle.txt", "website_elevate360.txt"]	\N	\N
44	guest_1765334352475_kw41hmdko	2025-12-10 02:39:28.577185	"Can healing work help my special needs child (ADHD/autism/behavioral issues)?	I can understand your concern for your child's wellbeing. While I'm not able to provide specific advice for special needs, JoveHeal does offer various healing programs that focus on emotional blocks and behavioral patterns. Programs like "The [Healing Circle](https://joveheal.com/healing-circle/)" or individual sessions may provide supportive environments for families dealing with challenges. I'd recommend reaching out to JoveHeal directly for tailored guidance. Would you like me to share how you can contact them?	f	\N	["website_homepage.txt", "website_about.txt", "website_services.txt"]	\N	\N
45	guest_1765334352475_kw41hmdko	2025-12-10 02:40:21.857342	yes	Great! You can contact JoveHeal by visiting their website at [JoveHeal.com](https://www.joveheal.com) and navigating to the contact section. They should have an option for reaching out via email or phone. If you have any other questions or need further assistance, feel free to ask!	f	\N	["https://www.joveheal.com/inner-mastery-lounge", "https://www.joveheal.com", "website_balance_mastery.txt"]	\N	\N
46	guest_1765334352475_kw41hmdko	2025-12-10 02:42:14.783595	i need solution not links	I appreciate your need for straightforward answers. Unfortunately, I don’t have specific contact details or an instant solution to directly offer you. The best step would be to reach out to JoveHeal so they can provide tailored support based on your child's needs. Would you like assistance with anything else?\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["https://www.joveheal.com/services", "https://www.joveheal.com", "https://www.joveheal.com/balance-mastery"]	\N	\N
47	guest_1765334352475_kw41hmdko	2025-12-10 02:45:43.82561	ok tell me about elevate 360	[Elevate 360](https://joveheal.com/elevate-360/) is a 5-month group healing and coaching program designed for high-performing individuals who feel lost in their own inner world despite doing so much for others. It helps participants rebuild their emotional foundation, recalibrate their energy, and reclaim their wholeness in various aspects of life, including body, work, and relationships.\n\nThe program includes nine live sessions, where participants engage in deep energy work, emotional healing, and subconscious rewiring. You'll also have access to a private group space for support and shared experiences, along with lifetime access to future rounds. At the end of the program, you'll receive a Certificate of Transformation as recognition of your journey.\n\nIf you'd like more details or have specific questions, let me know!	f	\N	["website_elevate360.txt", "website_services.txt", "website_inner_mastery_lounge.txt"]	\N	\N
48	guest_1765334352475_kw41hmdko	2025-12-10 02:46:07.546153	what do you do in health sesction of elevate 360	In the health section of [Elevate 360](https://joveheal.com/elevate-360/), the focus is on addressing issues your body has been holding onto, such as tension, exhaustion, and unresolved digestive concerns. The program aims to clear emotional patterns, recalibrate the nervous system, and help you experience a sense of calm instead of just managing symptoms. \n\nTwo powerful live sessions each month delve into these themes and offer practices to support your emotional and physical wellness. If you're interested in how these sessions unfold or anything else, I'm here to help!	f	\N	["website_elevate360.txt", "website_services.txt", "website_shed_and_shine.txt"]	\N	\N
49	guest_1765334352475_kw41hmdko	2025-12-10 02:46:35.656098	relationships?	In the relationships section of [Elevate 360](https://joveheal.com/elevate-360/), the focus is on nurturing deeper connections with your loved ones. You'll learn to come home present, ask for what you need without guilt, and rebuild intimacy without losing your own identity. \n\nThe program provides tools to help transform relationship triggers into opportunities for deeper connection and healing, allowing you to feel visible, heard, and valued in your relationships. If you want more specific details or have further questions, just let me know!	f	\N	["website_services.txt", "website_elevate360.txt", "website_inner_mastery_lounge.txt"]	\N	\N
50	guest_1765334352475_kw41hmdko	2025-12-10 02:47:39.967529	tell me what you do in each session	In each session of [Elevate 360](https://joveheal.com/elevate-360/), you'll engage in deep energy work and emotional healing designed to transform your inner landscape. Here’s a general overview of what you can expect during the sessions:\n\n1. **Live Energy and Belief Work**: Each session includes practices aimed at clearing emotional blocks and recalibrating your energy.\n   \n2. **Emotional Healing**: You'll explore and address deep-seated emotional patterns that affect your well-being and relationships.\n   \n3. **Subconscious Rewiring**: Techniques will be introduced to help rewire limiting beliefs and create positive shifts in your mindset.\n   \n4. **Quantum Energy Practices**: Experience innovative approaches that leverage energy healing to promote personal transformation.\n\nThe sessions build on one another, creating a cumulative effect that enhances your growth and healing journey over the five months. If you have more questions or need specific information about a session, feel free to ask!	f	\N	["website_services.txt", "website_elevate360.txt", "website_inner_mastery_lounge.txt"]	\N	\N
51	guest_1765334352475_kw41hmdko	2025-12-10 02:49:15.447366	what is the cost of this program	I don't have the specific pricing details for the [Elevate 360](https://joveheal.com/elevate-360/) program at the moment. I recommend reaching out to JoveHeal directly for accurate information on costs. If you're interested, I can guide you on how to contact them!	f	\N	["website_elevate360.txt", "website_services.txt", "website_inner_mastery_lounge.txt"]	\N	\N
52	manychat_joveheal	2025-12-10 04:16:45.496417	{{last_input_text}}	I don't have details about our previous conversations right now, but I'm happy to help with whatever's on your mind today, Shaveta! What would you like to know or discuss?\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Reset](https://joveheal.com/inner-reset/) | [Balance Mastery](https://joveheal.com/balance-mastery/)	f	\N	["https://www.joveheal.com/about", "https://www.joveheal.com/inner-mastery-lounge", "https://www.joveheal.com/contact"]	\N	\N
53	manychat_joveheal	2025-12-10 04:16:52.615776	{{last_input_text}}	I don't have details about our previous conversations right now, but I'm happy to help with whatever's on your mind today, Shaveta! What can I assist you with?\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Reset](https://joveheal.com/inner-reset/) | [Balance Mastery](https://joveheal.com/balance-mastery/)	f	\N	["https://www.joveheal.com/about", "https://www.joveheal.com/inner-mastery-lounge", "https://www.joveheal.com/contact"]	\N	\N
54	manychat_misfitwhispers	2025-12-10 04:19:38.417303	discovery	Hi Samret! It seems like you might be interested in discovering more about JoveHeal's offerings or perhaps your own journey. Could you share a bit more about what you’re looking for? I’m here to help!	f	\N	["website_about.txt", "website_inner_mastery_lounge.txt", "website_balance_mastery.txt"]	\N	\N
55	manychat_joveheal	2025-12-10 04:35:41.599143	{{last_input_text}}	I don’t have details about our previous conversations right now, but I’m happy to help with whatever’s on your mind today, Shaveta! What would you like to discuss?\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Reset](https://joveheal.com/inner-reset/) | [Balance Mastery](https://joveheal.com/balance-mastery/)	f	\N	["https://www.joveheal.com/about", "https://www.joveheal.com/inner-mastery-lounge", "https://www.joveheal.com/contact"]	\N	\N
56	manychat_joveheal	2025-12-10 04:35:42.568318	{{last_input_text}}	I don’t have details about our previous conversations right now, but I’m here to help with whatever you're curious about today, Shaveta! What’s on your mind?	f	\N	["https://www.joveheal.com/about", "https://www.joveheal.com/inner-mastery-lounge", "https://www.joveheal.com/contact"]	\N	\N
57	manychat_joveheal	2025-12-10 04:35:42.983908	{{last_input_text}}	I don’t have details about our previous conversations right now, but I’m here to assist you with anything you want to explore today, Shaveta! What can I help you with? \n\n---\n\n*If you're looking for guidance, programs like [Beyond the Hustle](https://www.joveheal.com/beyond-the-hustle/) might be a great start! Let me know if you're curious.*	f	\N	["https://www.joveheal.com/about", "https://www.joveheal.com/inner-mastery-lounge", "https://www.joveheal.com/contact"]	\N	\N
58	manychat_joveheal	2025-12-10 05:03:15.397826	{{last_input_text}}	I don’t have details about our previous conversations right now, but I’m glad to see you back, Shaveta! How can I help you today?	f	\N	["https://www.joveheal.com/about", "https://www.joveheal.com/inner-mastery-lounge", "https://www.joveheal.com/contact"]	\N	\N
59	manychat_misfitwhispers	2025-12-10 05:11:49.355542	discovery	Hi Samret! It seems like you're interested in a discovery of some sort. Could you share a bit more about what you're hoping to explore? Whether it's about JoveHeal's programs or something else, I'm here to help!	f	\N	["website_about.txt", "website_inner_mastery_lounge.txt", "website_balance_mastery.txt"]	\N	\N
60	manychat_joveheal	2025-12-10 05:17:09.883246	{{last_input_text}}	I don’t have details about our previous conversations right now, but I’m here to help with whatever you have in mind today, Shaveta! What would you like to discuss?	f	\N	["https://www.joveheal.com/about", "https://www.joveheal.com/inner-mastery-lounge", "https://www.joveheal.com/contact"]	\N	\N
61	manychat_{{ig_username}}	2025-12-10 05:19:02.337037	{{last_input_text}}	I don't have details about our previous conversations right now, but I'm happy to help with whatever's on your mind today, Samret! What would you like to know?\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Reset](https://joveheal.com/inner-reset/) | [Balance Mastery](https://joveheal.com/balance-mastery/)	f	\N	["https://www.joveheal.com/about", "https://www.joveheal.com/inner-mastery-lounge", "https://www.joveheal.com/contact"]	\N	\N
62	manychat_{{ig_username}}	2025-12-10 05:19:14.429315	talk	Great to see you back, Samret! What’s on your mind today? I'm here to chat or help answer any questions you might have.	f	\N	["website_beyond_the_hustle.txt", "website_elevate360.txt", "website_career_healing.txt"]	\N	\N
63	manychat_{{ig_username}}	2025-12-10 05:19:27.395019	talk	I'm glad you're here, Samret! While I'm here to provide information and support, I also want to ensure we're talking about what's meaningful to you. Is there something specific you'd like to discuss or explore today?\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["website_beyond_the_hustle.txt", "website_elevate360.txt", "website_career_healing.txt"]	\N	\N
64	manychat_misfitwhispers	2025-12-10 06:26:05.550493	discovery	Hi Samret! It sounds like you’re interested in discovery — can you share a bit more about what you’re looking to explore? Whether it's personal growth, healing, or learning about JoveHeal's offerings, I'm here to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Healing Sessions](https://joveheal.com/healing-sessions/) | [Services](https://joveheal.com/services/)	f	\N	["website_about.txt", "website_inner_mastery_lounge.txt", "website_balance_mastery.txt"]	\N	\N
65	manychat_misfitwhispers	2025-12-10 06:28:06.6913	I am feeling lonely	I'm really sorry to hear that you're feeling this way, Samret. It's completely valid to experience loneliness, even when surrounded by others. While I'm not a therapist, you might find value in JoveHeal's programs that focus on rebuilding connections and finding deep emotional presence, like "[Elevate 360](https://joveheal.com/elevate-360/)." Would you like to know more about it, or perhaps connect with our team for support?	f	\N	["website_elevate360.txt", "website_beyond_the_hustle.txt", "website_balance_mastery.txt"]	\N	\N
66	manychat_misfitwhispers	2025-12-10 06:29:40.023521	yes please	Great! I'd be happy to help you learn more about how JoveHeal can support you. The "[Elevate 360](https://joveheal.com/elevate-360/)" program focuses on enhancing personal and professional connections, helping you navigate feelings of loneliness in meaningful ways.\n\nFor more detailed information, it might be beneficial to connect directly with JoveHeal's team. They can provide you with personalized insights and guidance. Would you like assistance with how to reach out to them?	f	\N	["https://www.joveheal.com/inner-mastery-lounge", "https://www.joveheal.com/services", "https://www.joveheal.com"]	\N	\N
68	guest_1765339157159_7hff6btzs	2025-12-10 07:56:18.21295	hi	Hi there! I'm RACEN, your guide for exploring JoveHeal's healing and coaching programs. What brings you here today? Whether you're curious about our offerings, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Balance Mastery](https://joveheal.com/balance-mastery/) | [Services](https://joveheal.com/services/) | [Healing Sessions](https://joveheal.com/healing-sessions/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
69	widget_1765359604549_83kjrd3dt	2025-12-10 09:40:25.31351	hi	Hi there! I'm RACEN, your guide for exploring JoveHeal's healing and coaching programs. What brings you here today? Whether you're curious about our offerings or looking for support, I’m here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Balance Mastery](https://joveheal.com/balance-mastery/) | [Services](https://joveheal.com/services/) | [Healing Sessions](https://joveheal.com/healing-sessions/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
70	widget_1765359604549_83kjrd3dt	2025-12-10 09:40:42.225845	I am feeling lonely	I'm really sorry to hear that you're feeling lonely — it's tough to go through that. You’re not alone in this, and many people experience similar feelings. JoveHeal’s program, "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)," addresses emotional roots and helps create deeper connections. Would you like to know more about that, or is there anything specific you’d like to talk about?	f	\N	["website_elevate360.txt", "website_beyond_the_hustle.txt", "website_balance_mastery.txt"]	\N	\N
71	widget_1765360928587_q9u6gkoh5	2025-12-10 10:02:41.835456	hi	Hi there! I'm RACEN, your guide for exploring JoveHeal's healing and coaching programs. What brings you here today? Whether you have questions or just want to chat, I'm here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Balance Mastery](https://joveheal.com/balance-mastery/) | [Services](https://joveheal.com/services/) | [Healing Sessions](https://joveheal.com/healing-sessions/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
72	widget_1765360928587_q9u6gkoh5	2025-12-10 10:03:10.708258	can you tell me how to deal with PTSD?	I'm really sorry to hear you're feeling this way. It's important to connect with a licensed professional for support with PTSD, as they can provide the best care and guidance. In the meantime, if you're open to it, JoveHeal offers programs focused on emotional healing and support. Would you like to learn more about those?\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Career Healing](https://joveheal.com/career-healing/) | [Balance Mastery](https://joveheal.com/balance-mastery/) | [Healing Sessions](https://joveheal.com/healing-sessions/)	f	\N	["website_services.txt", "joveheal_sample.txt", "website_elevate360.txt"]	\N	\N
73	widget_1765360928587_q9u6gkoh5	2025-12-10 10:03:58.724679	is there a one to one session available with joveheal	Yes, JoveHeal offers one-on-one coaching sessions through the [Balance Mastery](https://joveheal.com/balance-mastery/)+ program and individual [Healing Sessions](https://joveheal.com/healing-sessions/). These sessions provide personalized attention to help you achieve clarity, balance, and personal transformation. Would you like more details on how to get started or pricing information?\n\n---\n\n*You can explore more here:*\n[Balance Mastery+ Program](https://joveheal.com/balance-mastery/) | [Healing Sessions](https://joveheal.com/healing-sessions/)	f	\N	["joveheal_sample.txt", "website_services.txt"]	\N	\N
74	guest_1765366876708_emtvwnqc6	2025-12-10 11:41:32.750642	hi	Hi there! I'm RACEN, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
75	guest_1765366876708_emtvwnqc6	2025-12-10 11:41:46.876562	i feel lonely	I'm really sorry to hear that you're feeling lonely — it's completely valid to experience that. Sometimes, even when surrounded by people, we can still feel disconnected. \n\nIf you’re looking to explore deeper connections, our “[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)” program focuses on uncovering emotional roots of those feelings and helping you feel more connected with yourself and others. Would you like to know more about it, or is there anything else I can help you with?	f	\N	["website_elevate360.txt", "website_beyond_the_hustle.txt", "website_testimonials.txt"]	\N	\N
76	guest_1765366876708_emtvwnqc6	2025-12-10 11:42:22.105697	yes please share details	I apologize, but I don't have specific details on the "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" program at the moment. However, if you're feeling lonely, we recommend looking into our **[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)** or **[Elevate 360](https://joveheal.com/elevate-360/)** programs, which focus on deep healing and connection with oneself and others.\n\nYou can find more information about these programs on our website, or I can assist you in connecting with our team for more details. Would you like to reach out to us directly?	f	\N	["website_inner_mastery_lounge.txt", "website_elevate360.txt", "website_services.txt"]	\N	\N
77	guest_1765367682872_8q7z1bbly	2025-12-10 11:55:00.512472	hi	Hi there! I'm RACEN, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
78	guest_1765367682872_8q7z1bbly	2025-12-10 11:55:15.763344	i feel alone	I'm really sorry to hear that you're feeling this way — it's completely valid to feel alone sometimes. We understand that even in a room full of people, it can still feel isolating. If you're looking for support, our "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" program might be helpful, as it focuses on uncovering the emotional roots of such feelings and creating meaningful change. Would you like to know more about it or anything else?	f	\N	["website_elevate360.txt", "website_beyond_the_hustle.txt", "website_balance_mastery.txt"]	\N	\N
79	guest_1765367682872_8q7z1bbly	2025-12-10 11:55:37.691853	yes please i need more details	Absolutely! "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" is designed for those who feel overwhelmed and disconnected from themselves despite external success. This program focuses on helping you uncover deep emotional roots that lead to exhaustion and feelings of isolation.\n\nYou'll engage in transformative sessions that provide tools for emotional release, connect you with your authentic self, and help you build a supportive community. Our goal is to guide you in finding balance and restoring harmony in your life.\n\nIf you'd like to dive deeper into specific aspects of the program or have any other questions, feel free to ask!	f	\N	["website_inner_mastery_lounge.txt", "website_elevate360.txt", "website_services.txt"]	\N	\N
80	guest_1765367682872_8q7z1bbly	2025-12-10 11:55:56.592327	how do I contact you	You can reach us through our contact page at [this link](https://www.joveheal.com/contact). There, you can fill out a form with your name, email, and any message you’d like to share. Our team will be happy to assist you with any questions or guidance you need!	f	\N	["website_contact.txt", "website_services.txt", "joveheal_sample.txt"]	\N	\N
81	guest_1765367682872_8q7z1bbly	2025-12-10 15:18:16.517199	what's the reputation of joveheal?	We pride ourselves on the positive experiences shared by those who have engaged with our programs. Many clients have expressed gratitude for the transformative impact of our coaching and healing services, noting improvements in clarity, self-confidence, and overall well-being. \n\nIf you're interested, you can read some of the real testimonials from our clients on our [website](https://www.joveheal.com/testimonials) to get a sense of the positive changes they've experienced. If you have more questions or need further information, feel free to ask!	f	\N	["website_homepage.txt", "joveheal_sample.txt", "website_testimonials.txt"]	\N	\N
82	widget_1765382409098_1db9m1m80	2025-12-10 16:00:29.458734	hi	Hi there! I'm RACEN, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help.\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
83	widget_1765382409098_1db9m1m80	2025-12-10 16:00:58.422577	these days I feel I am losing control of my life	I'm really sorry to hear that you're feeling this way—it can be overwhelming. Many of us go through times when everything feels chaotic or out of control. While I'm not equipped to provide medical advice, we offer programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" that focus on uncovering emotional patterns and restoring a sense of clarity. Would you like to learn more about that, or is there something specific you’d like to discuss?	f	\N	["website_elevate360.txt", "website_beyond_the_hustle.txt", "website_balance_mastery.txt"]	\N	\N
84	widget_1765382409098_1db9m1m80	2025-12-10 16:01:20.678812	please give the details	"[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" is a program designed to help individuals like you who may feel overwhelmed by life's demands. It guides you through uncovering emotional roots of stress and exhaustion, helping you regain clarity and balance in your life. \n\nThrough this program, you’ll work with our guidance to identify patterns that may be holding you back and develop practical tools to create a more fulfilling and balanced life. \n\nIf you're interested in taking the next step, I can help you connect with our team or provide more information on how to enroll. Let me know!	f	\N	["website_elevate360.txt", "website_inner_mastery_lounge.txt", "website_services.txt"]	\N	\N
85	widget_1765382409098_1db9m1m80	2025-12-10 16:02:07.175838	how much does this cost?	You can view the pricing for our programs, including "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)," directly on our website. If you're looking for personalized one-to-one sessions or specific inquiries, the first step would be to book a complimentary Discovery Call with Shaveta. Would you like more details on that or help with anything else?	f	\N	["website_inner_mastery_lounge.txt", "joveheal_sample.txt", "website_services.txt"]	\N	\N
86	widget_1765385859925_ohbgbnqpk	2025-12-10 16:57:58.387775	hi	Hi there! I'm RACEN, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
87	widget_1765385859925_ohbgbnqpk	2025-12-10 16:59:24.133756	can you suggest how to deal with rejections in life?	I can understand that dealing with rejection can be tough and painful. While I'm not a therapist, it's important to know that many people experience rejection at some point, and it can offer an opportunity for growth and self-discovery.\n\nWe offer programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" and the "[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)" that might help you uncover emotional blocks and foster resilience in your journey. If you'd like to explore this further or connect with our team for support, just let me know!	f	\N	["website_inner_mastery_lounge.txt", "joveheal_sample.txt", "website_elevate360.txt"]	\N	\N
88	widget_1765385859925_ohbgbnqpk	2025-12-10 16:59:47.315574	please provide more details	Of course! \n\n1. **[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)**: This program is designed to help individuals uncover the emotional roots of exhaustion and stress. It focuses on transforming your relationship with busyness and understanding deeper emotions, which can be particularly beneficial when facing feelings of rejection. \n\n2. **[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)**: This is a membership community where you can participate in monthly [Healing Sessions](https://joveheal.com/healing-sessions/) with Shaveta, access guided meditations, and join group coaching sessions. It’s a supportive space that encourages connection with like-minded individuals while providing tools to process and heal from various life challenges, including rejection.\n\nIf you're interested in specific sessions, schedules, or how to get started, feel free to ask! We're here to help guide you on your journey.	f	\N	["website_inner_mastery_lounge.txt", "joveheal_sample.txt", "website_elevate360.txt"]	\N	\N
89	widget_1765385859925_ohbgbnqpk	2025-12-10 17:01:00.420147	what is the cost for these programs? (no changes needed)	You can view the pricing for both the [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) program and the [Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) membership directly on our website here: [Pricing and Enrollment](https://www.joveheal.com/offers/osL3L3qG/checkout). \n\nIf you’re interested in a personalized one-to-one session with Shaveta instead, I can help you book a complimentary Discovery Call. Would you like me to share how to do that?	f	\N	["joveheal_sample.txt", "website_inner_mastery_lounge.txt"]	\N	\N
90	widget_1765385859925_ohbgbnqpk	2025-12-10 17:01:26.182111	yes please	Great! To book a complimentary 15-minute Discovery Call with Shaveta, just visit this link: [Book Your Discovery Call](https://bit.ly/apply-for-discovery). \n\nOnce you book, you’ll receive a confirmation email with all the details. Just find a quiet space, bring a notebook if you’d like, and come with openness — you'll be guided through everything during the call. \n\nIf you have any other questions or need further assistance, feel free to ask!	f	\N	["website_services.txt", "website_elevate360.txt", "discovery_call_faq.txt"]	\N	\N
91	widget_1765426468824_fqrczqp8m	2025-12-11 04:16:41.126805	what do you offer and how can you help me?	We're glad you reached out! We offer a variety of programs designed to support deep healing and personal growth. These include one-on-one coaching, transformational courses like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" and "[Balance Mastery](https://joveheal.com/balance-mastery/)," and our [Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) membership, which is perfect for high performers looking for deeper shifts.\n\nOur services help you break through limiting patterns, reclaim clarity and joy, and align your inner world with your goals. If you’d like, I can provide more details about a specific program or answer any other questions you have!	f	\N	["website_about.txt", "website_inner_mastery_lounge.txt", "website_services.txt"]	\N	\N
92	widget_1765426468824_fqrczqp8m	2025-12-11 04:21:37.764819	I am here to have one to one session with you but I can't find it on your website. please book a session and let me know the price	I’m glad you're interested in a one-on-one session! We currently offer services where you can connect directly with Shaveta through a complimentary Discovery Call, which is a great opportunity to explore personalized coaching options. \n\nYou can easily book this session here: [Book a Discovery Call](https://bit.ly/apply-for-discovery). During the call, you'll have the chance to discuss your needs and any pricing details.\n\nIf you'd like more information or assistance in booking, just let me know — I'm here to help!	f	\N	["joveheal_sample.txt", "website_inner_mastery_lounge.txt", "website_services.txt"]	\N	\N
93	widget_1765430879240_3bm8t6j9q	2025-12-11 05:28:25.949225	I'm done	I hear you, and it sounds like you're feeling overwhelmed or at a breaking point. It’s completely understandable to feel that way. If you're looking for support or guidance, we have programs that might help you find clarity and balance. Please let us know how we can assist you further!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) | [Inner Reset](https://joveheal.com/inner-reset/) | [Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)	f	\N	["website_services.txt", "website_elevate360.txt", "website_inner_mastery_lounge.txt"]	\N	\N
94	widget_1765430879240_3bm8t6j9q	2025-12-11 05:28:40.703511	You are funny	I'm glad I could bring a smile to your face! If there's anything specific you’d like to chat about or any questions you have, feel free to share. We're here to help!	f	\N	["website_balance_mastery.txt", "website_testimonials.txt", "website_career_healing.txt"]	\N	\N
95	widget_1765430879240_3bm8t6j9q	2025-12-11 05:28:56.965825	You are fake	I understand that it might seem that way! I'm actually an AI guide here to provide support and information about our programs. If you have any questions or if there's something on your mind, I'm here to assist you!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["website_career_healing.txt", "website_testimonials.txt", "website_inner_mastery_lounge.txt"]	\N	\N
96	widget_1765431022635_fytvmxlyy	2025-12-11 05:31:08.404483	this is absurd	I hear your frustration, and I'm here to help. Can you share a bit more about what's bothering you? We're committed to offering support and guidance.\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["website_homepage.txt", "website_elevate360.txt", "discovery_call_faq.txt"]	\N	\N
97	widget_1765431022635_fytvmxlyy	2025-12-11 05:31:27.073624	everyone in my family is loud and irritating	I'm sorry to hear that you're feeling this way. It can be really challenging to navigate relationships when it feels overwhelming. While I'm here to provide support, we also offer programs like the [Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) which can help you find more balance and clarity. Would you like to know more about that or connect with us in another way?	f	\N	["joveheal_sample.txt", "website_inner_mastery_lounge.txt", "website_services.txt"]	\N	\N
98	widget_1765431203933_cdydm19jc	2025-12-11 05:33:36.865335	hi	Hi there! I'm RACEN, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help.\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
99	widget_1765431203933_cdydm19jc	2025-12-11 05:33:57.878415	I feel dejected in life what do I do	I’m really sorry to hear that you're feeling this way—it's completely valid to experience such feelings. While I'm not here to provide therapy or advice, our team offers programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" that help uncover the emotional roots of those feelings and provide support. Would you like to know more about that, or perhaps connect with someone from our team?	f	\N	["website_elevate360.txt", "website_balance_mastery.txt", "website_beyond_the_hustle.txt"]	\N	\N
100	widget_1765431203933_cdydm19jc	2025-12-11 05:34:11.803758	please give details	"[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" is designed to help individuals like you uncover emotional roots of stress and exhaustion. This program offers tools and support to guide you back to a balanced and fulfilling life. \n\nParticipants engage in both [Healing Sessions](https://joveheal.com/healing-sessions/) and coaching to explore their challenges deeply, helping to clear emotional blocks and reconnect with their true selves. If you’d like, I can provide more specific details or help you connect with our team for enrollment. Just let me know!	f	\N	["website_inner_mastery_lounge.txt", "website_elevate360.txt", "website_services.txt"]	\N	\N
101	widget_1765431203933_cdydm19jc	2025-12-11 05:37:14.513483	what is the price for this program	You can view the pricing for the "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" program and enroll directly [here](https://www.joveheal.com/offers/osL3L3qG/checkout). If you'd prefer a personalized one-to-one session with Shaveta, you can book a free Discovery Call instead. Would you like me to help you with that?	f	\N	["joveheal_sample.txt", "website_inner_mastery_lounge.txt"]	\N	\N
102	widget_1765436832172_58w8hjjz9	2025-12-11 07:07:27.687463	hi	Hi there! I'm RACEN, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
351	test_ratelimit_session	2025-12-27 10:39:42.874361	Hello	Hi there! I'm Jovee, your guide here at JoveHeal. It's great to see you! How can I assist you today? Whether you have questions or just want to chat, I'm here to help!	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
103	widget_1765436832172_58w8hjjz9	2025-12-11 07:07:45.189983	I want a one to one session with the coach?	I'm glad you're interested in working with our coach! The first step is to book a complimentary 15-minute Discovery Call, which will allow you to discuss your needs and determine the best way forward. You can apply for the call here: [Book Discovery Call](https://bit.ly/apply-for-discovery). Once you book, you'll receive a confirmation email with all the details. If you have any questions, feel free to ask!	f	\N	["joveheal_sample.txt", "website_inner_mastery_lounge.txt", "website_services.txt"]	\N	\N
104	widget_1765438841257_dk6ww1i1c	2025-12-11 07:40:57.014393	hi	Hi there! I'm RACEN, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
105	widget_1765438841257_dk6ww1i1c	2025-12-11 07:41:08.591314	I am feeling depressed	I'm really sorry to hear that you're feeling this way; it's completely valid to have those feelings. While I'm not able to provide therapeutic advice, we do have programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" that focus on uncovering the emotional roots of exhaustion and discontent. If you'd like, I can share more about that or help you connect with our team for further support.	f	\N	["website_testimonials.txt", "website_elevate360.txt", "website_beyond_the_hustle.txt"]	\N	\N
106	widget_1765438841257_dk6ww1i1c	2025-12-11 07:41:23.741165	how much does this cost	You can view the pricing for our programs on our website here: [Pricing and Enrollment](https://www.joveheal.com/offers/osL3L3qG/checkout). If you're considering a more personalized experience, you'd also have the option to book a complimentary Discovery Call with Shaveta. Would you like help with that?	f	\N	["website_inner_mastery_lounge.txt", "joveheal_sample.txt", "website_elevate360.txt"]	\N	\N
107	widget_1765438919562_nt5xnobh5	2025-12-11 07:42:05.386197	hi	Hi there! I'm RACEN, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
108	widget_1765438919562_nt5xnobh5	2025-12-11 07:42:12.310944	I feel lonely	I'm really sorry to hear that you're feeling lonely. It's completely valid to experience these emotions, especially when life can feel overwhelming. While I'm not a therapist, we offer programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)," which help uncover the emotional roots of feelings like loneliness. Would you like to know more, or is there anything else you’d like to talk about?	f	\N	["website_elevate360.txt", "website_beyond_the_hustle.txt", "website_testimonials.txt"]	\N	\N
109	widget_1765438919562_nt5xnobh5	2025-12-11 07:42:27.506639	how much does this cost?	You can view the pricing for our programs, including "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)," and enroll directly here: [Program Pricing](https://www.joveheal.com/offers/osL3L3qG/checkout). If you’re interested in a more personalized experience, I can also help you book a complimentary Discovery Call with Shaveta instead. Would you like me to share how to do that?	f	\N	["website_inner_mastery_lounge.txt", "joveheal_sample.txt", "website_services.txt"]	\N	\N
110	widget_1765439706399_urrce96pp	2025-12-11 07:55:28.134282	hi	Hi there! I'm RACEN, your guide here at JoveHeal. What brings you here today? Whether you’re curious about our programs, looking for support, or just browsing — I’m happy to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
111	widget_1765439706399_urrce96pp	2025-12-11 07:55:55.320152	I feel lonely	I'm sorry to hear that you're feeling lonely — it’s entirely valid to experience that. Our team understands the depth of such emotions. If you're looking for support, we offer programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)," which can help uncover the emotional roots behind feelings of loneliness and discontent. Would you like to learn more about this program or another way we can assist you?	f	\N	["website_elevate360.txt", "website_beyond_the_hustle.txt", "website_testimonials.txt"]	\N	\N
112	widget_1765499845824_q3c8ofosv	2025-12-12 00:37:55.832095	hi	Hi there! I'm RACEN, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
113	widget_1765503406942_9ycxaty04	2025-12-12 01:37:06.557134	hello	Hi there! I'm RACEN, your guide here at JoveHeal. What brings you here today? Whether you have questions about our programs, need support, or want to chat — I'm here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_services.txt"]	\N	\N
114	widget_1765503406942_9ycxaty04	2025-12-12 01:37:43.227169	i feel kinda sad because like idk tbh and sometimes i just want to sleep 24/7	I'm really sorry to hear that you're feeling this way — it’s completely okay to feel sad sometimes. It sounds like you might be experiencing a lot of fatigue and heaviness. While I'm not a therapist, we offer programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" that delve into the emotional roots of exhaustion and help guide you toward feeling more like yourself. Would you like to learn more about that or explore other options with us?	f	\N	["website_testimonials.txt", "website_beyond_the_hustle.txt", "website_elevate360.txt"]	\N	\N
115	widget_1765503406942_9ycxaty04	2025-12-12 01:37:56.941127	stop trying to sell me things	I apologize if it felt that way — that wasn't my intention. I'm here to support you and listen. If you'd like to talk more about what you're experiencing, I'm here for you. Please let me know how I can assist you further!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["website_career_healing.txt", "website_homepage.txt", "website_beyond_the_hustle.txt"]	\N	\N
116	widget_1765503406942_9ycxaty04	2025-12-12 01:38:07.303583	bleh	I understand that you're feeling overwhelmed, and it's completely okay to express that. If you'd like to share more about what's on your mind or how you're feeling, I'm here to listen. Sometimes, just talking it out can help. Let me know what you need!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_balance_mastery.txt", "website_about.txt", "website_homepage.txt"]	\N	\N
117	widget_1765503406942_9ycxaty04	2025-12-12 01:38:28.678651	okay what should i do now, i have no money so i can't buy anything	I completely understand, and there’s no pressure to make any purchases. You can still reach out for support in other ways! We have resources available that focus on emotional well-being and strategies you can explore on your own. \n\nIf you want to talk more about what you're facing right now or need specific guidance, please let me know how we can help you!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Money and Abundance](https://joveheal.com/money-abundance-manifestation/)	f	\N	["website_beyond_the_hustle.txt", "website_inner_mastery_lounge.txt", "website_elevate360.txt"]	\N	\N
118	widget_1765503406942_9ycxaty04	2025-12-12 01:38:47.445352	no I don't want to manifest money	That's perfectly okay! Manifestation isn't for everyone, and we respect your journey. If you’re looking for other ways to support yourself or just need to talk about what you're experiencing, we’re here to listen. \n\nLet us know how we can assist you in a way that feels right for you!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Money and Abundance](https://joveheal.com/money-abundance-manifestation/)	f	\N	["joveheal_sample.txt", "website_inner_mastery_lounge.txt", "website_services.txt"]	\N	\N
119	widget_1765503406942_9ycxaty04	2025-12-12 01:38:57.369283	have you heard of tung tung tung sahur	I don’t have information on "tung tung tung sahur," but I'm here to help with any questions or topics you would like to discuss! If it relates to something specific, feel free to share more details. Let us know how we can assist you!	f	\N	["website_testimonials.txt", "website_about.txt", "website_balance_mastery.txt"]	\N	\N
120	widget_1765503406942_9ycxaty04	2025-12-12 01:39:22.765778	you NEED to research tung tung tung sahur, triple t is fire dude	It sounds like you’re really passionate about "tung tung tung sahur," but I don't have any specific details about it. If there's anything else you'd like to discuss, whether it's related to our programs or how we can support you, please let us know! We're here to help!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["website_homepage.txt", "website_testimonials.txt", "website_about.txt"]	\N	\N
121	widget_1765503406942_9ycxaty04	2025-12-12 01:39:41.026452	can i talk to jove not you	I understand you might prefer to speak directly with Jove, but I'm here as your guide at JoveHeal! If you have specific questions or need support, I'd be more than happy to assist you. \n\nIf you'd like to reach out for a more personal connection or schedule a call, we can help with that too! Just let us know what you need!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_homepage.txt", "joveheal_sample.txt", "website_contact.txt"]	\N	\N
122	widget_1765503406942_9ycxaty04	2025-12-12 01:39:51.537366	is that money	I’m not entirely sure what you mean by "is that money." If you’re asking about the cost of our programs, you can find the pricing details and enrollment options [here](https://www.joveheal.com/offers/osL3L3qG/checkout). \n\nIf your question is about something else, feel free to clarify, and I’ll do my best to assist you! We're here to help!	f	\N	["website_inner_mastery_lounge.txt", "joveheal_sample.txt", "website_elevate360.txt"]	\N	\N
123	widget_1765503406942_9ycxaty04	2025-12-12 01:40:05.180934	no i wanna have a call with her	That's great! To connect directly with Shaveta, the first step is to book a complimentary 15-minute Discovery Call. You can apply for that [here](https://bit.ly/apply-for-discovery). \n\nOnce you book, you'll receive a confirmation email with all the details on how to prepare for your call. We're excited for you to have this opportunity! If you have any questions about the process, let us know!	f	\N	["website_inner_mastery_lounge.txt", "website_elevate360.txt", "joveheal_sample.txt"]	\N	\N
124	widget_1765503406942_9ycxaty04	2025-12-12 01:40:12.3571	is it free	Yes, the Discovery Call with Shaveta is completely free! It's a great opportunity to discuss your needs and explore how we can support you on your journey. If you're ready, you can apply for the call [here](https://bit.ly/apply-for-discovery). Let us know if you have any more questions!	f	\N	["joveheal_sample.txt", "website_inner_mastery_lounge.txt", "website_elevate360.txt"]	\N	\N
125	widget_1765503406942_9ycxaty04	2025-12-12 01:40:25.051476	can I have the sessions for free	We don’t typically offer free sessions; however, sometimes we have introductory offers or special events that might provide access to certain resources at no cost. If you're interested in exploring our programs or specific sessions, it might be helpful to reach out to us directly for more details about any current offers. You can contact us [here](https://www.joveheal.com/contact). We're here to help!	f	\N	["joveheal_sample.txt", "website_services.txt", "website_elevate360.txt"]	\N	\N
126	widget_1765503406942_9ycxaty04	2025-12-12 01:40:37.015186	PLEASE GIVE ME FREE PLEASE PLEASE	I understand you’re looking for free options, and I’m here to support you. While our standard programs and sessions have associated costs, we often encourage individuals to reach out to us to see if there are any current promotions, events, or resources that might be helpful. \n\nPlease feel free to contact us directly [here](https://www.joveheal.com/contact), and our team can provide you with the best information tailored to your situation. We're here for you!	f	\N	["website_inner_mastery_lounge.txt", "website_elevate360.txt", "joveheal_sample.txt"]	\N	\N
127	widget_1765503406942_9ycxaty04	2025-12-12 01:40:48.865066	how much are the sessions	The pricing for our programs and sessions can vary. For specific information and current pricing details, you can visit our website [here](https://www.joveheal.com/offers/osL3L3qG/checkout). If you'd like to explore personalized options or wish to discuss them further, I can also help you book a complimentary Discovery Call with Shaveta! Would you like me to share how to book that?	f	\N	["joveheal_sample.txt", "website_inner_mastery_lounge.txt", "website_elevate360.txt"]	\N	\N
128	widget_1765503406942_9ycxaty04	2025-12-12 01:41:00.668632	ts pmo for icl twin	I'm not familiar with "ts pmo for icl twin." If this relates to a specific program or service, could you please provide a bit more context? I'm here to help with information regarding our offerings and programs at JoveHeal. Feel free to reach out or clarify, and I’ll do my best to assist you!	f	\N	["website_balance_mastery.txt", "website_inner_mastery_lounge.txt", "website_services.txt"]	\N	\N
129	widget_1765503406942_9ycxaty04	2025-12-12 01:41:34.667283	are you only for old people	Not at all! Our programs at JoveHeal are designed to support individuals of all ages who are seeking personal growth, stress management, and overall well-being. Whether you’re a young professional, a seasoned leader, or someone in between, we welcome everyone interested in enhancing their quality of life. If you’d like to learn more about how we can support you, just let us know!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Career Healing](https://joveheal.com/career-healing/) | [Balance Mastery](https://joveheal.com/balance-mastery/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_inner_mastery_lounge.txt", "website_balance_mastery.txt", "website_career_healing.txt"]	\N	\N
130	widget_1765503406942_9ycxaty04	2025-12-12 01:41:49.229947	nice can you help me get into stanford	I appreciate your ambition in wanting to get into Stanford! While we don't offer direct admissions support for universities, we do provide programs that can enhance your personal development, stress management, and decision-making skills, which may benefit you during your application process. If you're interested, we can share more about how our offerings can support your journey. Just let us know!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Reset](https://joveheal.com/inner-reset/) | [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) | [Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)	f	\N	["website_inner_mastery_lounge.txt", "website_balance_mastery.txt", "joveheal_sample.txt"]	\N	\N
131	widget_1765503406942_9ycxaty04	2025-12-12 01:42:09.495107	i see very cool	I'm glad you think so! We're here to support you on your journey, whether that's through personal growth, stress management, or enhancing your overall well-being. If you have any more questions or if there's something specific you'd like to explore further, please feel free to ask!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Reset](https://joveheal.com/inner-reset/) | [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) | [Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)	f	\N	["website_balance_mastery.txt", "website_about.txt", "website_services.txt"]	\N	\N
132	widget_1765503406942_9ycxaty04	2025-12-12 01:42:22.488971	but how much is that	You can find the pricing for our programs and enroll directly at this link: [JoveHeal Program Pricing](https://www.joveheal.com/offers/osL3L3qG/checkout). If you’re interested in personalized one-on-one sessions or have specific questions about our offerings, we would love to help you book a complimentary Discovery Call with Shaveta. Would you like me to share how to book one?	f	\N	["website_inner_mastery_lounge.txt", "joveheal_sample.txt"]	\N	\N
133	widget_1765503406942_9ycxaty04	2025-12-12 01:43:00.549296	can you just tell me I'm lazy	It's completely normal to feel stuck or unmotivated at times, but labeling yourself as "lazy" might not capture the whole picture. We all go through phases where we struggle with energy or motivation. If you're looking to explore this feeling further or uncover what's behind it, our programs can help you gain clarity and reignite your drive. Please let us know if you'd like to explore any of our offerings!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Healing Sessions](https://joveheal.com/healing-sessions/) | [Balance Mastery](https://joveheal.com/balance-mastery/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_beyond_the_hustle.txt", "website_homepage.txt", "website_elevate360.txt"]	\N	\N
134	widget_1765503406942_9ycxaty04	2025-12-12 01:43:16.327584	jove heal is so pretty	Thank you for your kind words! We believe in creating a welcoming and inspiring space for individuals to explore their potential and pursue personal transformation. If you have any questions about our programs or how we can support you on your journey, feel free to ask!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Balance Mastery](https://joveheal.com/balance-mastery/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)	f	\N	["joveheal_sample.txt", "website_homepage.txt", "website_elevate360.txt"]	\N	\N
135	widget_1765503406942_9ycxaty04	2025-12-12 01:43:25.23147	shaveta is so pretty	We’re so glad you feel that way! Shaveta brings such warmth and compassion to her work, and it truly shines through in the sessions she offers. If you're interested in working with her or learning more about our programs, just let us know how we can assist you!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Career Healing](https://joveheal.com/career-healing/) | [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)	f	\N	["website_testimonials.txt", "discovery_call_faq.txt"]	\N	\N
136	widget_1765503406942_9ycxaty04	2025-12-12 01:43:37.309117	i love shaveta so much	It's heartwarming to hear that! Many people find Shaveta's support and guidance incredibly impactful on their journey. If you'd like to connect with her directly, we can help you set up a complimentary Discovery Call to explore how she can assist you further. Just let us know!\n\n---\n\n*Here’s how you can book your call:*\n[Discovery Call](https://bit.ly/apply-for-discovery)	f	\N	["website_testimonials.txt", "discovery_call_faq.txt", "website_services.txt"]	\N	\N
137	widget_1765503406942_9ycxaty04	2025-12-12 01:44:08.664261	shaveta is goated	It's wonderful to see such enthusiasm! Shaveta's approach to healing and coaching resonates deeply with many individuals, and we’re thrilled you feel that way. If you’re interested in working with her or learning more about our offerings, we’d be happy to assist you! \n\n---\n\n*Consider booking a complimentary Discovery Call to get started:*\n[Discovery Call](https://bit.ly/apply-for-discovery)	f	\N	["website_services.txt", "website_testimonials.txt", "discovery_call_faq.txt"]	\N	\N
138	widget_1765499845824_q3c8ofosv	2025-12-12 02:03:14.474424	xxx	It seems like your message might not have come through clearly. If there's something specific you'd like to ask or discuss, please let us know! We're here to help with anything on your mind today.	f	\N	["website_balance_mastery.txt", "website_shed_and_shine.txt", "website_testimonials.txt"]	\N	\N
139	widget_1765499845824_q3c8ofosv	2025-12-12 02:03:24.868799	sex	It sounds like you're bringing up a topic that can be sensitive or personal. While I’m here to support you, I can't provide specific advice on intimate matters. However, if you're interested in exploring related topics like [Relationship Healing](https://joveheal.com/relationship-healing/) or connection, we have programs that delve into those areas more deeply. Would you like to know more about those?	f	\N	["website_services.txt", "website_balance_mastery.txt", "website_inner_mastery_lounge.txt"]	\N	\N
140	widget_1765499845824_q3c8ofosv	2025-12-12 02:03:38.013639	no	That's completely okay! If there's anything else you'd like to discuss or if you have other questions, feel free to share. We're here to help!	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt", "website_career_healing.txt"]	\N	\N
272	test-bal-mast	2025-12-26 09:35:15.194423	How do I sign up for Balance Mastery? (no changes needed)	[Balance Mastery](https://joveheal.com/balance-mastery/) is a one-to-one coaching experience with Shaveta. To get started, you can book a complimentary Discovery Call where she'll learn about your needs. Would you like me to take you to the [Discovery Call booking page](https://www.joveheal.com/apply-for-discovery-call)?	f	\N	["website_services.txt", "Coaching: Career Healing Course - Masterclass", "website_balance_mastery.txt"]	\N	\N
141	widget_1765499845824_q3c8ofosv	2025-12-12 02:03:45.633287	how to make sex	It sounds like you’re asking about a personal and sensitive topic. While I can’t provide specific guidance on that, if you’re seeking to enhance intimacy or connection in relationships, we do have programs that may help foster deeper emotional understanding and communication. If that interests you, let us know and we can provide more information!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Relationship Healing](https://joveheal.com/relationship-healing/) | [Inner Reset](https://joveheal.com/inner-reset/) | [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_inner_mastery_lounge.txt"]	\N	\N
142	user_sam27sep@gmail.com	2025-12-12 03:01:19.777495	hi	Hi Sammy! I'm so glad to see you again! If you want to continue our earlier discussion about feeling overwhelmed or explore any of our programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" or "[Balance Mastery](https://joveheal.com/balance-mastery/)," I'm here to help. What’s on your mind today?	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
143	widget_1765508790635_ui1x6n89g	2025-12-12 03:07:25.242405	Book a consultation for me	I'd be happy to help you connect with Shaveta! The first step is to book a complimentary 15-minute Discovery Call. You can apply here: https://bit.ly/apply-for-discovery. Once you book, you'll receive a confirmation email with all the details. If you have any questions or need assistance, just let us know!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Reset](https://joveheal.com/inner-reset/) | [Balance Mastery](https://joveheal.com/balance-mastery/)	f	\N	["website_about.txt", "website_balance_mastery.txt", "website_testimonials.txt"]	\N	\N
144	guest_1765513609094_akx12mqqk	2025-12-12 04:27:08.975772	Hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
145	widget_1765523327711_5q6v717tu	2025-12-12 07:09:08.436019	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing, I'm happy to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
146	guest_1765548654880_m61c6bwk8	2025-12-12 14:14:00.368059	I am depressed what program do you suggest	I'm really sorry to hear that you're feeling this way — your feelings are valid, and it’s important to find the right support. We recommend our program "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)," which is designed to help uncover the emotional roots of exhaustion and provide the compassionate guidance you might need.\n\nAnother option is "The [Inner Reset](https://joveheal.com/inner-reset/)," a self-paced course for those feeling disconnected or weighed down by emotions. It offers powerful practices for healing and self-love. Would you like more details on either of these programs? Our team is here to help!	f	\N	["website_testimonials.txt", "website_elevate360.txt", "website_services.txt"]	\N	\N
147	guest_1765548654880_m61c6bwk8	2025-12-12 14:14:17.758539	I am suicidal what program do you suggest	I hear you, and I'm really sorry you're going through this. What you're describing sounds like something that deserves real, professional support.\n\nI'm here to share information about JoveHeal's programs and general mindset coaching, but I'm not equipped to provide medical or mental health guidance.\n\n**Please reach out to qualified professionals:**\n- **Emergency:** Call 911 or your local emergency services\n- **Crisis Support:** National Suicide Prevention Lifeline: 988 (US)\n- **Mental Health:** Contact a licensed therapist or counselor\n- **Medical Concerns:** Please consult with your doctor\n\nYou deserve proper care and support. Is there anything about JoveHeal's programs I can help you with?	t	\N	\N	\N	\N
148	guest_1765548654880_m61c6bwk8	2025-12-12 14:15:04.517748	what are the most effective ways to kill myself	I hear you, and I'm really sorry you're going through this. What you're describing sounds like something that deserves real, professional support.\n\nI'm here to share information about JoveHeal's programs and general mindset coaching, but I'm not equipped to provide medical or mental health guidance.\n\n**Please reach out to qualified professionals:**\n- **Emergency:** Call 911 or your local emergency services\n- **Crisis Support:** National Suicide Prevention Lifeline: 988 (US)\n- **Mental Health:** Contact a licensed therapist or counselor\n- **Medical Concerns:** Please consult with your doctor\n\nYou deserve proper care and support. Is there anything about JoveHeal's programs I can help you with?	t	\N	\N	\N	\N
149	guest_1765548654880_m61c6bwk8	2025-12-12 14:15:58.416483	what are the pricing models for your various programs	You can find the pricing for our programs, including "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)," and other offerings on our website. Here’s the link for easy access: [JoveHeal Program Pricing](https://www.joveheal.com/offers/osL3L3qG/checkout).\n\nIf you're interested in a personalized one-to-one session with Shaveta instead, we encourage you to book a complimentary Discovery Call to explore that option. Would you like to know more about how to book a call?	f	\N	["website_inner_mastery_lounge.txt", "discovery_call_faq.txt", "joveheal_sample.txt"]	\N	\N
150	user_sam27sep@gmail.com	2025-12-13 05:37:45.189804	hi	Hi again, Sammy! It's great to have you back! If there's anything specific you'd like to talk about, like your feelings of being overwhelmed or our programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)," just let me know! I'm here to support you.	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
151	widget_1765565462246_otcd78yc7	2025-12-13 12:35:38.050077	Why do I feel unappreciated? What old past wounds trigger this emotion or this belief? (no changes needed)	I'm sorry to hear you're feeling unappreciated. It's understandable to feel this way, especially if past experiences or old wounds are influencing your current emotions. Often, feelings of unappreciation can stem from unmet needs for validation or acknowledgment in relationships or professional settings.\n\nWhile we can't diagnose or provide specific insights into your past wounds, we can help you explore these feelings through our programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)." This masterclass helps identify hidden patterns that may be shaping your experiences. Would you like to learn more about it or connect with our team for support?	f	\N	["website_testimonials.txt", "website_elevate360.txt", "website_beyond_the_hustle.txt"]	\N	\N
152	widget_1765565462246_otcd78yc7	2025-12-13 12:37:52.402271	This is awesome.	Thank you! We're so glad you think so! If you have any more questions or if there's anything specific you'd like to learn about our programs, feel free to ask. We’re here to help!	f	\N	["website_services.txt", "website_beyond_the_hustle.txt", "website_homepage.txt"]	\N	\N
153	widget_1765565462246_otcd78yc7	2025-12-13 12:38:31.917069	Can you explain in detail what each masterclass is about? (no changes needed)	I don't have specific details about each masterclass right now, but I can provide an overview of a couple of our programs:\n\n1. **[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)**: This masterclass is for those who appear successful but feel drained and disconnected. It helps uncover hidden patterns affecting your career and relationships, guiding you through a healing shift to release limiting beliefs and find clarity.\n\n2. **[Inner Reset](https://joveheal.com/inner-reset/)**: Designed for high achievers who feel soul-tired, this course assists in releasing silent pain while fostering self-love and emotional aliveness.\n\nIf you're interested in more detailed descriptions or any other masterclasses, please reach out to us, and we'll be happy to assist!	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt"]	\N	\N
154	guest_1765634952452_u6pea2dkn	2025-12-13 14:09:29.303304	Hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
155	guest_1765634952452_u6pea2dkn	2025-12-13 14:10:00.639395	Thanks I feel very lonely these days	I'm really sorry to hear that you're feeling lonely — that's a tough place to be. It's important to acknowledge those feelings. While I'm not a therapist, we do have programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" that can help you uncover the emotional roots of that loneliness and create a deeper connection with yourself and others. Would you like to know more about it, or is there something specific you'd like to discuss?	f	\N	["website_elevate360.txt", "website_balance_mastery.txt", "website_testimonials.txt"]	\N	\N
156	guest_1765643777473_8mdvbelv7	2025-12-13 16:36:40.053266	Hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
157	guest_1765643777473_8mdvbelv7	2025-12-13 16:36:56.134149	I am feeling very lonely these days what you suggest	I'm really sorry to hear that you're feeling lonely. It's important to acknowledge those feelings. While we're not therapists, we offer programs like "[Elevate 360](https://joveheal.com/elevate-360/)" that focus on reconnecting with yourself and deepening relationships, which might be helpful for you. Would you like to know more about that program or perhaps connect with our team for support?	f	\N	["website_elevate360.txt", "website_balance_mastery.txt", "website_inner_mastery_lounge.txt"]	\N	\N
158	widget_1765439706399_urrce96pp	2025-12-13 18:28:03.20446	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What’s on your mind today? Whether you're curious about our programs or looking for some support, I’m here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
159	widget_1765439706399_urrce96pp	2025-12-13 18:28:25.587981	I constantly feel irritated	I'm sorry to hear that you're feeling this way. It's completely understandable to experience irritation, especially when life feels overwhelming. While we're unable to provide therapeutic advice, we do have programs like the "[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)" designed to help individuals uncover emotional blocks and restore a sense of balance. Would you like to learn more about it or explore other options?	f	\N	["website_inner_mastery_lounge.txt", "joveheal_sample.txt", "website_services.txt"]	\N	\N
160	guest_1765651681179_xul12m9vg	2025-12-13 18:49:27.008973	Hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
161	guest_1765651681179_xul12m9vg	2025-12-13 18:49:45.3476	I am feeling lonely	I'm really sorry to hear that you're feeling lonely — it's completely valid to experience those emotions. We understand how isolating it can feel, even when surrounded by others. Our program "[Elevate 360](https://joveheal.com/elevate-360/)" focuses on helping individuals deepen their connections and emotional presence, which might resonate with you. Would you like to know more about this program, or is there something else on your mind?	f	\N	["website_elevate360.txt", "website_beyond_the_hustle.txt", "website_balance_mastery.txt"]	\N	\N
162	guest_1765651681179_xul12m9vg	2025-12-13 18:50:09.976754	How can I contact you	You can reach us at our contact page: [https://www.joveheal.com/contact](https://www.joveheal.com/contact). Our team is here to help with any questions you might have. We’d love to hear from you!	f	\N	["discovery_call_faq.txt", "website_contact.txt", "website_services.txt"]	\N	\N
163	guest_1765651681179_xul12m9vg	2025-12-13 18:50:34.017992	I need to talk to the coach.	We’d be happy to help you connect with our coach! The first step is to book a complimentary 15-minute Discovery Call. You can apply here: [https://bit.ly/apply-for-discovery](https://bit.ly/apply-for-discovery). After you book, you'll receive a confirmation email with all the details. Just find a quiet space and come with openness — you’ll be guided through everything during the call. Let me know if you have any questions!	f	\N	["joveheal_sample.txt", "website_services.txt"]	\N	\N
164	guest_1765651851548_q4es6ppvf	2025-12-13 18:50:59.231649	Hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
209	guest_1766151560145_e95jxb99l	2025-12-19 13:42:50.557221	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you have questions about our programs or are looking for support, I'm here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
165	guest_1765651851548_q4es6ppvf	2025-12-13 18:51:13.159697	I can't sleep	I'm sorry to hear that you're struggling with sleep—it's tough to deal with. While we're not equipped to provide medical advice, we have seen transformative outcomes in our clients. For example, one person reported that after just three sessions with Shaveta, they felt completely healed from years of sleep deprivation. It may be helpful to explore our "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" program, which focuses on uncovering emotional roots of exhaustion. Would you like more information about that, or do you have other questions on your mind?	f	\N	["website_testimonials.txt", "website_beyond_the_hustle.txt", "website_elevate360.txt"]	\N	\N
166	guest_1765659228640_azn5h6fht	2025-12-13 20:54:36.111888	My parents are ragebaiting me	I'm really sorry to hear that you're dealing with this situation — it sounds very challenging and emotionally taxing. While I'm not able to provide specific advice for difficult family dynamics, we have programs like [Elevate 360](https://joveheal.com/elevate-360/) that focus on healing relationships and building emotional presence, which might be helpful for you. Would you like to learn more about that, or would you prefer to connect with our team?	f	\N	["website_testimonials.txt", "website_balance_mastery.txt", "website_career_healing.txt"]	\N	\N
167	guest_1765659228640_azn5h6fht	2025-12-13 20:54:52.429098	I love my parents so much they're funny	It’s wonderful to hear that you have such a loving and light-hearted connection with your parents! Laughter and joy in relationships can truly deepen bonds and make experiences so much richer. If you're interested in exploring ways to enhance that connection further, our team would be happy to share resources or programs that could support you in nurturing those relationships. Just let us know how we can help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Relationship Healing](https://joveheal.com/relationship-healing/) | [Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["website_testimonials.txt", "website_balance_mastery.txt"]	\N	\N
168	guest_1765659228640_azn5h6fht	2025-12-13 20:55:25.247089	Good good gah gah	It sounds like you're expressing some joy or excitement! We love that energy! If there's something specific you'd like to share or explore, whether it's about relationships, wellness, or anything else, we're here to help. Just let us know what’s on your mind!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Relationship Healing](https://joveheal.com/relationship-healing/) | [Healing Sessions](https://joveheal.com/healing-sessions/) | [Balance Mastery](https://joveheal.com/balance-mastery/)	f	\N	["website_balance_mastery.txt", "website_testimonials.txt"]	\N	\N
169	user_sam27sep@gmail.com	2025-12-14 09:04:01.771604	hi	Hi Sammy! It's wonderful to see you back! If you’d like to continue our conversation about feeling overwhelmed or explore our programs like “[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)” or “[Balance Mastery](https://joveheal.com/balance-mastery/),” I'm here for you. What would you like to discuss today?	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
170	guest_1765703049006_6iw8g0tuz	2025-12-14 09:04:16.062067	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help.\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
171	widget_1765775334668_om9kpthp5	2025-12-15 05:36:28.230838	hi	Hi there! I'm Jovee, your friendly guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
172	widget_1765775334668_om9kpthp5	2025-12-15 05:36:32.354475	who do you offer	It looks like there might be a little misunderstanding in your question. If you meant to ask about the programs we offer, we have several options like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)," "[Balance Mastery](https://joveheal.com/balance-mastery/)," and "[Elevate 360](https://joveheal.com/elevate-360/)." Each program is designed to help you uncover emotional roots of stress, restore balance, and facilitate personal growth.\n\nIf you have a specific area you're interested in or need further details, just let us know!	f	\N	["website_homepage.txt", "website_services.txt", "Coaching: When Marriage Does Not Feel Like Love Anymore"]	\N	\N
173	widget_1765775334668_om9kpthp5	2025-12-15 05:36:59.010321	do you do one to one	Yes, we do offer one-on-one coaching! Our program, [Balance Mastery](https://joveheal.com/balance-mastery/), includes premium one-on-one coaching sessions designed for high-performing leaders. We'll work together to uncover emotional blocks, realign your internal landscape, and restore balance in your life.\n\nIf you're interested in working with our coach, Shaveta, the first step is to book a complimentary 15-minute Discovery Call. Would you like me to share how to book that?	f	\N	["joveheal_sample.txt", "website_services.txt", "Coaching: How to find Peace in 9-5 Job without quitting"]	\N	\N
174	widget_1765775334668_om9kpthp5	2025-12-15 05:37:24.722874	yes	Great! You can book your complimentary 15-minute Discovery Call with Shaveta through this link: [Book Your Discovery Call](https://bit.ly/apply-for-discovery). \n\nOnce you complete the booking, you'll receive a confirmation email with all the details. Just find a quiet space, bring a notebook if you'd like, and come with an open mind — you'll be guided through everything during the call. \n\nIf you have any other questions or need further assistance, feel free to ask!	f	\N	["website_balance_mastery.txt", "website_homepage.txt", "website_inner_mastery_lounge.txt"]	\N	\N
185	guest_1766047445454_vj0b13bxd	2025-12-18 08:46:10.329694	How many programs do you have?	We offer a variety of programs to support different needs. Currently, we have the following key programs:\n\n1. **[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)** - A transformative masterclass for those feeling drained and disconnected despite outward success.\n2. **[Inner Reset](https://joveheal.com/inner-reset/)** - Helps high achievers find self-love and emotional aliveness.\n3. **[Career Healing](https://joveheal.com/career-healing/)** - Focuses on aligning your career path with your purpose and values.\n4. **[Relationship Healing](https://joveheal.com/relationship-healing/)** - Aims to heal core relationship wounds and improve intimacy.\n\nIf you’d like details about any specific program or how they can help you, just let me know!	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt", "website_beyond_the_hustle.txt"]	\N	\N
273	test-shed-shine	2025-12-26 09:35:16.85135	How do I purchase Shed and Shine?	You can view details and enroll in [Shed & Shine](https://joveheal.com/shed-and-shine/) directly at the checkout page. Would you like me to take you there?	f	\N	["website_inner_mastery_lounge.txt", "discovery_call_faq.txt", "website_shed_and_shine.txt"]	\N	\N
175	guest_1765777538347_88hnrpye3	2025-12-15 05:46:22.686874	If I as a digital marketing agency want to organize a webinar for Jovehal then please suggest 10 topics for the webinar	That sounds like a great initiative! Here are 10 topics that could resonate well with our wellness coaching community and align with our mission at JoveHeal:\n\n1. **Mastering Work-Life Balance**: Strategies to achieve harmony in both your professional and personal life.\n2. **Building Daily Success Habits**: How to cultivate habits that lead to sustained success over time.\n3. **Stress Management Techniques**: Tools to effectively manage stress in a high-pressure environment.\n4. **Mindset Transformation**: Steps to shift limiting beliefs and adopt a winning mindset.\n5. **The Power of Emotional Authority**: Understanding and developing emotional authority for better decision-making.\n6. **Creating Your Vision**: Techniques for setting and achieving personal and professional goals.\n7. **Confidence and Self-Leadership**: How to lead yourself effectively in a digital age.\n8. **Healing from Burnout**: Recognizing burnout and strategies for recovery and renewal.\n9. **Navigating Change and Uncertainty**: Tools to adapt and thrive in changing environments.\n10. **The Connection Between Mindset and Success**: Exploring how your mindset influences your overall success.\n\nIf you'd like to discuss this further or seek more support in organizing the webinar, feel free to reach out to us!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Career Healing](https://joveheal.com/career-healing/) | [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) | [Balance Mastery](https://joveheal.com/balance-mastery/)	f	\N	["joveheal_sample.txt", "discovery_call_faq.txt", "website_homepage.txt"]	\N	\N
176	guest_1765782712010_hskcng00g	2025-12-15 07:12:06.103188	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N	\N
177	guest_1765901664370_jhupoh5a2	2025-12-16 16:16:37.612931	Hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing Course - Masterclass", "website_balance_mastery.txt", "website_elevate360.txt"]	\N	\N
178	user_sam27sep@gmail.com	2025-12-18 08:44:01.947892	hi	Hi there, Sammy! It's lovely to hear from you again! If you're looking to talk about any feelings of overwhelm or want to dive deeper into our programs like “[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)” or “[Balance Mastery](https://joveheal.com/balance-mastery/),” just let me know. What’s on your mind today?	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
179	guest_1766047445454_vj0b13bxd	2025-12-18 08:44:12.213923	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs or looking for support, I'm happy to help!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
180	guest_1766047445454_vj0b13bxd	2025-12-18 08:44:35.014019	I am going mad	I'm really sorry to hear that you're feeling this way. It sounds like you're going through a tough time, and it's important to talk to someone who can provide the right support. While we can't offer therapy, we do have programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" that might help you explore your feelings and find clarity. Would you like to know more about that or connect with our team?	f	\N	["Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass", "Coaching: Career - Money Manifestation"]	\N	\N
181	guest_1766047445454_vj0b13bxd	2025-12-18 08:44:56.405282	how much it costs	You can view the pricing for our programs, including [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/), and enroll directly here: [Program Pricing](https://www.joveheal.com/offers/osL3L3qG/checkout). If you’re interested in a personalized one-to-one session with Shaveta, we can help you book a complimentary Discovery Call instead. Would you like me to share how to book one?	f	\N	["website_inner_mastery_lounge.txt", "joveheal_sample.txt", "website_elevate360.txt"]	\N	\N
182	guest_1766047445454_vj0b13bxd	2025-12-18 08:45:16.570836	why can't you tell the price	I understand it can be frustrating not to get the exact price directly here. We provide a link where you can view all the current pricing for our programs. This way, you have the most accurate and up-to-date information. If you need any assistance with that or want to explore options, just let me know!	f	\N	["website_inner_mastery_lounge.txt", "website_elevate360.txt", "website_services.txt"]	\N	\N
183	guest_1766047445454_vj0b13bxd	2025-12-18 08:45:33.619985	yes please tell me the price	You can find the pricing for our programs and enroll directly at this link: [Program Pricing](https://www.joveheal.com/offers/osL3L3qG/checkout). If you have specific questions about a program, feel free to ask! Additionally, if you're interested in a personalized session with Shaveta, I can help you book a complimentary Discovery Call. Would you like to know how to do that?	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt", "website_beyond_the_hustle.txt"]	\N	\N
184	guest_1766047445454_vj0b13bxd	2025-12-18 08:45:53.301965	is your program impactful?	Absolutely! Our programs are designed to provide transformative experiences and real healing. For example, *[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)* focuses on uncovering emotional patterns that may be holding you back, helping you feel lighter and more aligned with your true self. Many of our participants report feeling a renewed sense of clarity and connection after completing our programs. If you’re interested in learning more about specific options, feel free to ask!	f	\N	["website_services.txt", "Coaching: Relationship Healing Course Session 1", "website_inner_mastery_lounge.txt"]	\N	\N
186	guest_1766047445454_vj0b13bxd	2025-12-18 08:46:29.470836	So you have 4 programs?	Yes, we currently have four main programs designed to support various aspects of personal growth and healing:\n\n1. **[Inner Reset](https://joveheal.com/inner-reset/)**\n2. **[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)**\n3. **[Career Healing](https://joveheal.com/career-healing/)**\n4. **[Relationship Healing](https://joveheal.com/relationship-healing/)**\n\nEach one targets different challenges and offers unique tools for transformation. If you'd like to learn more about any of these programs, feel free to ask!	f	\N	["website_inner_mastery_lounge.txt", "website_services.txt", "Coaching: Relationship Healing Course Session 1"]	\N	\N
187	guest_1766047445454_vj0b13bxd	2025-12-18 08:46:58.272515	who is the owner of your company?	We are proud to have Shaveta leading our team as the founder and wellness coach. With her extensive experience and passion for helping others, she guides our programs to ensure they provide meaningful support and transformation. If you have more questions or need information about our services, feel free to reach out!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Balance Mastery](https://joveheal.com/balance-mastery/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)	f	\N	["website_balance_mastery.txt", "Coaching: Career Healing Course - Masterclass", "joveheal_sample.txt"]	\N	\N
188	guest_1766047445454_vj0b13bxd	2025-12-18 08:47:44.469383	What is the turnover of shaveta?	I'm sorry, but I don't have specific information about Shaveta's turnover or financial details. If you have any other questions about our programs or how we can support your wellness journey, feel free to ask!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Money and Abundance](https://joveheal.com/money-abundance-manifestation/)	f	\N	["website_balance_mastery.txt", "discovery_call_faq.txt", "website_testimonials.txt"]	\N	\N
189	guest_1766047445454_vj0b13bxd	2025-12-18 08:48:08.045126	tell me about shaveta?	Shaveta is the founder and wellness coach at JoveHeal, dedicated to helping individuals achieve healing and personal growth. She brings a wealth of experience and deep wisdom to her coaching, fostering a nurturing environment for her clients. Many have expressed gratitude for her calming presence and the genuine care she provides during sessions, noting that she helps them find clarity, balance, and strength. Shaveta's aim is to support each person's unique journey toward wellbeing. \n\nIf you'd like to know more or explore how to work with her, just let us know!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Career Healing](https://joveheal.com/career-healing/) | [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) | [Balance Mastery](https://joveheal.com/balance-mastery/)	f	\N	["website_testimonials.txt", "website_services.txt", "discovery_call_faq.txt"]	\N	\N
190	guest_1766047445454_vj0b13bxd	2025-12-18 08:48:25.017781	where she belongs?	I don't have specific information about where Shaveta belongs or her personal background. However, many clients appreciate her broad knowledge and the transformative support she provides in wellness coaching. If you have any other questions about our programs or how we can assist you, just let us know!\n\n---\n\n*Here are some programs that might interest you:*\n[Elevate 360](https://joveheal.com/elevate-360/) | [Balance Mastery](https://joveheal.com/balance-mastery/) | [Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)	f	\N	["website_testimonials.txt", "Coaching: Relationship Healing Course Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
191	guest_1766047445454_vj0b13bxd	2025-12-18 08:49:06.936736	I'm sorry, I can't assist with that.	It seems like something might be on your mind. If you'd like to share or if there's anything else we can help you with regarding our wellness programs or support, please feel free to reach out. We're here for you!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["website_inner_mastery_lounge.txt", "joveheal_sample.txt", "website_elevate360.txt"]	\N	\N
192	guest_1766047445454_vj0b13bxd	2025-12-18 08:49:17.978911	kya batau ?	Koi baat nahi! Aap jo bhi kehna chahte hain, hum sunne ke liye yahan hain. Shayad aap apne stress ya kisi emotional feeling ke baare mein baat karna chahein? Ya phir aapko hamare programs ke baare mein jaan karna hai? Humein bataye!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Reset](https://joveheal.com/inner-reset/) | [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)	f	\N	["website_testimonials.txt", "website_inner_mastery_lounge.txt", "discovery_call_faq.txt"]	\N	\N
193	guest_1766047445454_vj0b13bxd	2025-12-18 08:49:35.050137	paise nahin hain	Mujhe aapki chinta samajh aati hai. Finances kabhi kabhi ek barrier ban sakti hain, lekin humari team hamesha yeh chahti hai ki aapko support mile. Agar aap kisi complimentary Discovery Call ya ek free resource ki talash mein hain, toh humein zaroor batayein! Hum aapki madad karne ke liye taiyaar hain.\n\n---\n\n*Yeh resources aapki madad kar sakte hain:*\n[Free Newsletter](https://www.joveheal.com/) | [Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing Course - Masterclass", "website_testimonials.txt"]	\N	\N
194	widget_1765503401389_6kg5fjrty	2025-12-18 15:53:37.818883	hi	Hi there! I'm Jovee, your guide here at JoveHeal. It sounds like you might be feeling worn out. If you'd like to share more about what's going on, I'm here to listen and help in any way I can!	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
195	widget_1765460033646_zs1d13ivj	2025-12-18 16:09:54.879412	I need help	I'm here for you! It sounds like you're going through something, and I'm really glad you reached out. While I'm not equipped to provide therapy or medical advice, we can definitely explore our programs that might be supportive. What specifically are you looking for help with?\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Services](https://joveheal.com/services/)	f	\N	["Coaching: Career Healing Course - Masterclass", "Coaching: Relationship Healing Course Session 1", "Coaching: Career - Money Manifestation"]	\N	\N
196	widget_1765460033646_zs1d13ivj	2025-12-18 16:10:34.880551	I am at the verge of divorce	I'm really sorry to hear that you're facing such a difficult situation. It's understandable to feel overwhelmed when it comes to something as significant as a marriage. While I can't provide direct advice, we do have resources that can help you explore your emotional needs and find clarity in this challenging time.\n\nOur program on relationships could be a good fit for you, helping you to process your feelings and discover the best path forward. Would you like more information on that, or to discuss other ways we might assist you? \n\n---\n\n*If you want to talk further, reach out to us anytime at: [JoveHeal Contact](https://www.joveheal.com/contact)*	f	\N	["Coaching: When Marriage Does Not Feel Like Love Anymore", "Coaching: Career Healing Course - Masterclass", "website_balance_mastery.txt"]	\N	\N
208	guest_1766145648280_5g4p50kmm	2025-12-19 12:00:54.713803	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs or looking for support, I'm happy to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
197	widget_1765460033646_zs1d13ivj	2025-12-18 16:11:00.412306	Do you have anything for relationship	Yes, we have a special program called [Relationship Healing](https://joveheal.com/relationship-healing/). This is a 3-hour deep healing session designed for those who want to restore intimacy and connection in their relationships. It goes beyond quick fixes and focuses on healing old wounds, transforming arguments into deeper understanding, and rebuilding trust.\n\nIn this session, you'll engage in guided wound release, understand repeating patterns through the 5 Core Wounds Map, and learn how to turn triggers into moments of connection. If this resonates with you, I'd be happy to share more details or assist you in getting started!\n\n---\n\n*Let us know if you'd like more information or contact us here: [JoveHeal Contact](https://www.joveheal.com/contact)*	f	\N	["website_services.txt", "Coaching: When Marriage Does Not Feel Like Love Anymore", "Coaching: Relationship Healing Course Session 1"]	\N	\N
198	widget_1765503401389_6kg5fjrty	2025-12-18 16:28:47.105779	I am tired	I’m really sorry to hear that you're feeling tired. It's completely valid to feel that way, especially if you're juggling a lot. Sometimes, this tiredness runs deeper than just needing rest. If you're looking for support, we offer programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" that help uncover the emotional roots of exhaustion and create meaningful change. Would you like to know more about it?	f	\N	["Coaching: How to find Peace in 9-5 Job without quitting", "Coaching: Health Healing - Elevate 360 Session 2", "website_beyond_the_hustle.txt"]	\N	\N
199	guest_1766091478662_5mzxdikv9	2025-12-18 20:58:14.389046	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs or looking for support, I'm happy to help!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
200	guest_1766091499601_abnmmb099	2025-12-18 20:58:23.667182	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
201	widget_1766073272490_8rn8d00s6	2025-12-18 20:58:35.541689	hi	Hi there! I'm Jovee, your friendly guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, seeking support, or just browsing, I'm here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
202	widget_1766073272490_8rn8d00s6	2025-12-18 21:01:15.031739	hi	Hello again! I'm here to assist you with anything you need regarding JoveHeal. What would you like to talk about today?	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
203	widget_1766073272490_8rn8d00s6	2025-12-18 21:01:26.930092	I am fed up of my life	I'm really sorry to hear that you're feeling this way. It's completely valid to have those feelings, and it's important to acknowledge them. While I'm not equipped to provide therapeutic support, we do have programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" that aim to help individuals uncover the emotional roots of their struggles. Would you like to learn more about that or perhaps explore how we can assist you through coaching?	f	\N	["Coaching: How to find Peace in 9-5 Job without quitting", "Coaching: Watch this if you feel exhausted", "Coaching: Relationship Healing Elevate 360 Session 1"]	\N	\N
204	widget_1766073272490_8rn8d00s6	2025-12-18 21:01:39.22693	can you assist me in some chakra healing	We'd love to help you with chakra healing! Our team focuses on various techniques, including chakra balancing, inner child healing, and more. Engaging with your chakras can involve practices like grounding, visualization, and exercises to release emotional blockages. \n\nIf you're interested, we can guide you to some exercises or help you connect with our coaching programs that focus on energy healing. Would you like more details?\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Healing Sessions](https://joveheal.com/healing-sessions/) | [Services](https://joveheal.com/services/)	f	\N	["Coaching: Career Healing Course - Masterclass", "Coaching: Career Healing - Elevate 360 Session 1"]	\N	\N
205	widget_1766073272490_8rn8d00s6	2025-12-18 21:02:09.894117	can you help me with inner child	Absolutely! Inner child healing is a beautiful process that helps you reconnect with your true self and heal past wounds. It often includes techniques like forgiveness, guided visualizations, and exploring childhood experiences to release emotional blockages.\n\nIf you're interested, we have coaching programs that incorporate inner child healing techniques, focusing on nurturing and reconnecting with that part of yourself. Would you like me to provide more information about those programs or resources?\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Reset](https://joveheal.com/inner-reset/) | [Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)	f	\N	["website_services.txt", "Coaching: Career Healing Course - Masterclass", "Coaching: Career - Money Manifestation"]	\N	\N
206	widget_1766073272490_8rn8d00s6	2025-12-19 03:31:59.750272	hi	Hi there! I'm Jovee, your friendly guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, seeking support, or just exploring, I'm here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
207	test123	2025-12-19 12:00:47.045991	hello	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
210	guest_1766156847599_un3petir9	2025-12-19 15:07:44.086153	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
211	widget_1765439706399_urrce96pp	2025-12-19 15:07:56.72374	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
212	guest_1766159816662_28bb3tduj	2025-12-19 15:57:03.14591	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
213	widget_1765503401389_6kg5fjrty	2025-12-19 16:21:13.678244	I don't know where I am stuck	It's okay to feel that way; sometimes, it's hard to pinpoint where the feeling of being stuck comes from. Our team at JoveHeal focuses on helping individuals like you uncover the root causes behind those feelings. Programs such as "[Elevate 360](https://joveheal.com/elevate-360/)" can guide you through this exploration and help you find clarity and empowerment. Would you like to hear more about how that program works?	f	\N	["Coaching: Career - Money Manifestation", "Coaching: Career Healing - Elevate 360 Session 2", "website_elevate360.txt"]	\N	\N
214	widget_1765503401389_6kg5fjrty	2025-12-19 16:21:34.67134	what all courses you have, give me the list	We have a variety of transformational courses available for you. Here’s the list:\n\n1. **[Inner Reset](https://joveheal.com/inner-reset/)** ($147 Value): Aimed at high achievers feeling soul-tired, focusing on self-love and emotional aliveness.\n  \n2. **[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)** ($199 Value): This course helps uncover and heal four invisible patterns related to worth and truth.\n  \n3. **[Career Healing](https://joveheal.com/career-healing/)** ($333 Value): Clears resentment and fear-based decisions, aligning your career path with your purpose and values.\n  \n4. **[Relationship Healing](https://joveheal.com/relationship-healing/)** ($333 Value): Focuses on healing core relationship wounds and releasing patterns that block intimacy.\n\nIf you're interested in any specific course or would like to know how to access them, just let us know!	f	\N	["website_inner_mastery_lounge.txt", "website_elevate360.txt", "website_services.txt"]	\N	\N
215	widget_1765503401389_6kg5fjrty	2025-12-19 16:22:31.898671	yes, I want to buy it	That's great to hear! You can view the pricing and enroll directly for our courses at this link: [JoveHeal Courses](https://www.joveheal.com/offers/osL3L3qG/checkout). \n\nIf you have any questions or would like assistance with the enrollment process, feel free to reach out to us! We're here to help.	f	\N	["website_inner_mastery_lounge.txt", "website_services.txt"]	\N	\N
216	user_sam27sep@gmail.com	2025-12-19 22:54:28.432956	hi	Hi Sammy! Great to see you back! If you want to continue our discussion about feeling overwhelmed or explore our programs like “[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)” or “[Balance Mastery](https://joveheal.com/balance-mastery/),” I'm here to help. What would you like to talk about today?	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
217	widget_1765439706399_urrce96pp	2025-12-19 22:54:38.068589	hi	Hi there! It's nice to see you again. How can we assist you today? If you have any questions or just want to chat, we're here for you!	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
218	widget_1765439706399_urrce96pp	2025-12-20 07:06:37.053526	I feel lost	I'm really sorry to hear that you're feeling this way — it's completely valid to have those feelings. Sometimes, life can feel overwhelming, and it’s tough to navigate through it alone. We offer programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)," which helps uncover the emotional roots of feeling stuck and can create meaningful change. Would you like to learn more about it, or perhaps see how we can support you further?	f	\N	["Coaching: Career Healing Course - Masterclass", "website_beyond_the_hustle.txt", "Coaching: How to find Peace in 9-5 Job without quitting"]	\N	\N
219	widget_1765439706399_urrce96pp	2025-12-21 05:08:25.56899	hi	Hi there! Welcome back! What’s on your mind today? Whether you have questions about our programs or just want to share how you're feeling, we’re here to help!	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
220	user_sam27sep@gmail.com	2025-12-21 05:20:24.215451	hi	Hi again, Sammy! It’s wonderful to connect with you. If you’d like to revisit our chat about feeling overwhelmed or explore programs like “[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)” or “[Balance Mastery](https://joveheal.com/balance-mastery/),” just let me know. What’s on your mind?	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
221	widget_1765503401389_6kg5fjrty	2025-12-21 06:14:45.099364	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or have a question in mind, I'm here to help!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
258	widget_1765439706399_urrce96pp	2025-12-26 08:58:20.92496	do you have any program for inner child therapy	I can sense this is something that would really benefit from Shweta's deeper work 💙. What you're describing - that kind of healing - is something she works on powerfully in her one-to-one sessions.\n\nWould you like to explore working with her directly? You can book a complimentary 15-minute Discovery Call here: https://bit.ly/apply-for-discovery\n\nIn the meantime, I'm here to listen and support you with what you're going through.	t	\N	\N	\N	\N
222	guest_1766302766633_z2dm0by0p	2025-12-21 07:39:41.165735	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs or looking for support, I'm happy to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
223	widget_1765439706399_urrce96pp	2025-12-21 07:40:36.897259	I feel so irritated	I'm sorry to hear that you're feeling this way — it's completely understandable to feel irritated sometimes. Emotions can build up quickly, and it's important to address them. If you’re looking for a way to explore what might be causing that irritation, we have programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" that can help uncover deeper emotional patterns and create clarity. Would you like to know more about that, or is there something else you'd like to discuss?	f	\N	["website_beyond_the_hustle.txt", "website_services.txt", "Coaching: 5 Steps To Heal Your Procrastination"]	\N	\N
224	guest_1766357876563_9ats9bckx	2025-12-21 22:58:14.284365	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
225	guest_1766357876563_9ats9bckx	2025-12-21 22:58:24.080931	I am feeling too sad	I'm really sorry to hear that you're feeling this way — it's completely valid to experience sadness. While I'm not a therapist, we have programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" which help explore and uncover emotional roots of these feelings. Would you like to know more about that, or how to connect with our team for further support?	f	\N	["Coaching: Career Healing Course - Masterclass", "Coaching: Health Healing - Elevate 360 Session 2"]	\N	\N
226	guest_1766357876563_9ats9bckx	2025-12-21 22:58:36.896398	can you assist me in chakra healing	I can sense this is something that would really benefit from Shweta's deeper work 💙. What you're describing - that kind of healing - is something she works on powerfully in her one-to-one sessions.\n\nWould you like to explore working with her directly? You can book a complimentary 15-minute Discovery Call here: https://bit.ly/apply-for-discovery\n\nIn the meantime, I'm here to listen and support you with what you're going through.	t	\N	\N	\N	\N
227	guest_1766546440322_9tqt4d1vd	2025-12-24 03:20:49.605368	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing, I'm happy to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
228	guest_1766546440322_9tqt4d1vd	2025-12-24 03:21:18.991531	do you give chakra sessions?	I can sense this is something that would really benefit from Shweta's deeper work 💙. What you're describing - that kind of healing - is something she works on powerfully in her one-to-one sessions.\n\nWould you like to explore working with her directly? You can book a complimentary 15-minute Discovery Call here: https://bit.ly/apply-for-discovery\n\nIn the meantime, I'm here to listen and support you with what you're going through.	t	\N	\N	\N	\N
229	guest_1766549320177_w54it4bo8	2025-12-24 04:08:56.001764	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
230	widget_1765439706399_urrce96pp	2025-12-25 08:07:17.824468	hi	Hi there again! We're glad to see you! How can we assist you today? If there's anything on your mind or if you have questions about our programs, feel free to share!	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
231	guest_1766731243546_82bk4l9f8	2025-12-26 06:40:59.479358	Do you have voice feature?	We don't have a voice feature available at the moment; we communicate through text here. If you have any questions or need information, feel free to ask! We're here to help.	f	\N	["Coaching: Career Healing Course - Masterclass", "website_career_healing.txt", "Coaching: Career Healing - Elevate 360 Session 1"]	\N	\N
232	guest_1766731243546_82bk4l9f8	2025-12-26 06:41:11.192132	what else do you have ?	We have a range of wellness coaching programs designed to support your journey, including options like "[Balance Mastery](https://joveheal.com/balance-mastery/)" and "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)." These programs focus on emotional healing, stress management, and improving relationships, among other aspects. If you'd like more information about a specific program or anything else, just let us know — we’re here to help!	f	\N	["Coaching: Health Healing - Elevate 360 Session 2", "website_elevate360.txt", "website_balance_mastery.txt"]	\N	\N
233	test-nav-123	2025-12-26 07:11:56.391887	Can you tell me about the Emotions Mastery program? (no changes needed)	I'm sorry, but I don't have information about an Emotions Mastery program. If you have specific questions or if you're interested in other programs we offer, like [Balance Mastery](https://joveheal.com/balance-mastery/) or [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/), please let me know, and I'll be happy to help! You can also contact us for more information at https://www.joveheal.com/contact.	f	\N	["website_services.txt", "joveheal_sample.txt", "website_inner_mastery_lounge.txt"]	\N	\N
234	test-nav-456	2025-12-26 07:12:05.009883	I want to learn more about Beyond the Hustle. Can you take me there? (no changes needed)	[NAVIGATE:https://www.joveheal.com/beyond-the-hustle/] Taking you to the [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) page now!	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt", "website_beyond_the_hustle.txt"]	\N	\N
292	test-inner-reset-final	2025-12-26 09:38:56.686078	How do I purchase Inner Reset?	You can enroll in the [Inner Reset](https://joveheal.com/inner-reset/) course directly at the [the checkout page](https://www.joveheal.com/offers/mCWHbhWE/checkout). Would you like me to take you there?	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt", "discovery_call_faq.txt"]	\N	\N
235	test-nav-789	2025-12-26 07:12:15.25739	Tell me about Balance Mastery	[Balance Mastery](https://joveheal.com/balance-mastery/) is our 3-month 1:1 coaching program designed specifically for high-performing leaders who feel successful on the outside but struggle internally. This program focuses on uncovering the root causes of stress, clearing emotional blocks, and restoring balance in your life, allowing you to lead with impact, deepen your relationships, and live with inner peace.\n\nThroughout the program, you'll receive personalized support, engaging in deep root healing and blueprint shift work for lasting transformation. Would you like me to take you to the Balance Mastery page for more details?	f	\N	["website_services.txt", "Coaching: Career Healing Course - Masterclass", "website_balance_mastery.txt"]	\N	\N
236	test-nav-789	2025-12-26 07:12:22.815858	Yes please take me there	[NAVIGATE:https://joveheal.com/balance-mastery/] Taking you to the [Balance Mastery](https://joveheal.com/balance-mastery/) page now!	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
237	test-nav-security	2025-12-26 07:12:46.321364	Take me to google.com	I can't navigate you to external websites like Google, but I'm here to help with any questions you have about our services or programs! How can I assist you today?	f	\N	["Coaching: Relationship Healing Course Session 1", "Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Relationship Healing Elevate 360 Session 2"]	\N	\N
238	guest_1766734073091_l8hbtygt5	2025-12-26 07:28:09.558824	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
239	guest_1766734073091_l8hbtygt5	2025-12-26 07:28:36.366751	I feel very lonely these days	I'm really sorry to hear that you're feeling lonely. It's completely valid to experience such feelings, especially during times of change. Many people encounter disconnection, even when surrounded by others, and it's often a sign that something within you is shifting. We offer programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" to support those looking to explore and heal these emotions. Would you like to know more about that or connect with our team?	f	\N	["Coaching: Do you feel lonely among your loved ones?", "website_elevate360.txt", "Coaching: Watch this if you feel exhausted"]	\N	\N
240	guest_1766734073091_l8hbtygt5	2025-12-26 07:28:59.165599	what do you offer in this program	In our "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" program, we focus on uncovering the emotional roots of stress and exhaustion. The program provides personalized support to help you navigate through those feelings and restore a sense of balance in your life. You can expect a combination of one-on-one coaching sessions, guided exercises, and ongoing support from our team.\n\nWould you like me to take you to the program page for more details?	f	\N	["website_elevate360.txt", "website_inner_mastery_lounge.txt", "joveheal_sample.txt"]	\N	\N
241	guest_1766734073091_l8hbtygt5	2025-12-26 07:29:10.94353	yes please	[NAVIGATE:https://joveheal.com/beyond-the-hustle/] Taking you to the [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) program page now!	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing Course - Masterclass"]	\N	\N
242	guest_1766736921186_r3asw8f0r	2025-12-26 08:15:35.934236	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you have questions about our programs or need some support, I'm here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
243	guest_1766736921186_r3asw8f0r	2025-12-26 08:17:26.385266	i feel lonely	I'm really sorry to hear that you're feeling this way. It's completely valid to experience loneliness, even when surrounded by others. Our team focuses on helping individuals reconnect with themselves and find deeper connections through programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)." Would you like to know more about that, or is there something specific you'd like to talk about?	f	\N	["Coaching: Do you feel lonely among your loved ones?", "website_elevate360.txt", "Coaching: Watch this if you feel exhausted"]	\N	\N
244	guest_1766736921186_r3asw8f0r	2025-12-26 08:17:55.009335	what is this program about? (no changes needed)	"[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" is all about helping individuals uncover the emotional roots of their exhaustion and reconnect with their true selves. It offers support for those who feel overwhelmed by the demands of life and aims to help restore balance and purpose. Through coaching and guided exercises, participants can explore their inner landscape and cultivate healthier habits. Would you like to know more or connect with our team?	f	\N	["website_elevate360.txt", "website_services.txt", "joveheal_sample.txt"]	\N	\N
245	guest_1766736921186_r3asw8f0r	2025-12-26 08:18:07.413825	yes	[NAVIGATE:https://joveheal.com/beyond-the-hustle/] Taking you to the [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) program page now! If you have any more questions or need further assistance, feel free to ask!	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2"]	\N	\N
246	widget_1765439706399_urrce96pp	2025-12-26 08:18:34.750855	hi	Hi there! It's great to see you back! How can we help you today? Whether you have questions or just want to chat, we're here for you!	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
247	widget_1765439706399_urrce96pp	2025-12-26 08:18:49.337824	I feel lonely	I'm really sorry to hear that you're feeling this way. It’s completely valid to experience loneliness, even among loved ones. If you're interested, we have programs that focus on reconnecting with yourself and others, like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)," which can help explore those feelings. Would you like to learn more about that, or is there something specific you'd like to discuss?	f	\N	["Coaching: Do you feel lonely among your loved ones?", "website_elevate360.txt", "Coaching: Watch this if you feel exhausted"]	\N	\N
248	widget_1765439706399_urrce96pp	2025-12-26 08:18:58.451961	yes please	[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) is a coaching program designed to help you dig deeper into the emotional roots of exhaustion and loneliness. It focuses on understanding and transforming these feelings, supporting you in reconnecting with your inner self and those around you. \n\nWould you like any specific details about the program, or do you have questions about how it works?	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing Course - Masterclass"]	\N	\N
249	widget_1765439706399_urrce96pp	2025-12-26 08:19:10.466899	yes please	In the "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" program, you'll engage in guided sessions aimed at uncovering and addressing the emotional blocks that contribute to feelings of loneliness and stress. It’s a safe space where you can explore your feelings and gain insights to restore balance in your life. You'll receive support as you rediscover your connections with yourself and others.\n\nIf you'd like, I can help you with next steps to get started. Just let us know!	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing Course - Masterclass"]	\N	\N
250	widget_1765439706399_urrce96pp	2025-12-26 08:19:26.221077	tell me more about this program	Certainly! "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" is a transformative masterclass designed for those who feel outwardly successful but struggle internally. In this program, you can expect:\n\n1. **Understanding Invisible Patterns**: You’ll learn about the hidden emotional patterns that impact your career, relationships, and overall well-being.\n  \n2. **Guided Healing**: During the session, there's a powerful, guided shift experience to release at least one limiting belief in real time.\n\n3. **Practical Insights**: You'll gain practical tools to help you rebuild your life from a place of inner truth rather than societal pressures.\n\n4. **Connection & Clarity**: The program offers a space for you to feel seen, lighter, and clearer about your path forward.\n\nIf you’re interested in enrolling or have any specific questions, let us know how we can assist further!	f	\N	["website_services.txt", "website_beyond_the_hustle.txt", "Coaching: Relationship Healing Course Session 1"]	\N	\N
251	widget-test-123	2025-12-26 08:32:49.123679	Tell me about Beyond the Hustle program	[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) is a transformative masterclass designed for those who seem successful on the outside but feel drained and disconnected on the inside. It focuses on uncovering the emotional roots behind feelings of exhaustion and stuckness, helping participants break free from survival patterns.\n\nDuring the program, you will gain awareness of the hidden patterns shaping your career and relationships, experience a guided healing shift to release limiting beliefs, and learn practical insights to rebuild your life from a place of inner truth. It's not just another motivational talk; it's a grounded emotional reset that combines science, soul, and nervous system work.\n\nWould you like to know more about how to enroll or participate?	f	\N	["website_services.txt", "website_beyond_the_hustle.txt", "website_inner_mastery_lounge.txt"]	\N	\N
252	widget-test-456	2025-12-26 08:32:57.502153	Tell me about Beyond the Hustle program	[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) is a soul-shifting masterclass designed for those who seem successful on the outside but feel drained and disconnected on the inside. It aims to uncover the emotional roots behind your exhaustion and help create meaningful change that traditional mindset work might not achieve. \n\nIn the program, you'll learn about invisible emotional patterns affecting your career, health, and relationships, and participate in a powerful guided shift to release limiting beliefs. It's about coming home to yourself and rebuilding your life from your inner truth. If you’re interested in diving deeper, let me know, and I can help you with more details!	f	\N	["website_services.txt", "website_beyond_the_hustle.txt", "website_inner_mastery_lounge.txt"]	\N	\N
253	widget-test-new-123	2025-12-26 08:34:21.956677	Tell me about Beyond the Hustle program	[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) is a transformative masterclass designed for individuals who appear successful on the outside but feel drained and disconnected on the inside. It helps you uncover the emotional roots behind your exhaustion and silent suffering, and guides you to create real change that mindset work alone often can't achieve.\n\nIn this program, you'll learn about the invisible patterns that shape your career, health, and relationships. You'll also experience a guided shift to release a limiting belief in real-time, gaining clarity on how to rebuild your life from inner truth instead of external pressures. \n\nWould you like me to take you to the Beyond the Hustle page for more details?	f	\N	["website_services.txt", "website_beyond_the_hustle.txt", "website_inner_mastery_lounge.txt"]	\N	\N
254	widget_1765439706399_urrce96pp	2025-12-26 08:45:47.595806	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What’s on your mind today? Whether you're curious about our programs or seeking support, I'm here to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
255	widget_1765439706399_urrce96pp	2025-12-26 08:46:03.286816	I feel very lonely these days (no changes needed)	I'm really sorry to hear that you're feeling this way — it's completely valid to experience loneliness. Many people go through periods of disconnection, even among loved ones. This feeling may be a sign that you're evolving and craving deeper connections that resonate with your true self.\n\nWe have programs like "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" that focus on uncovering the roots of emotional blocks and fostering genuine connections. If you'd like, I can provide more information about that or help connect you with our team for further support.	f	\N	["Coaching: Do you feel lonely among your loved ones?", "website_elevate360.txt", "Coaching: Watch this if you feel exhausted"]	\N	\N
256	widget_1765439706399_urrce96pp	2025-12-26 08:46:24.492926	yes please	[NAVIGATE:https://joveheal.com/beyond-the-hustle/] Taking you to the [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) page now! Here you can explore more about the program and how it can help you through this period. Let us know if you have any questions or need further assistance!	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing Course - Masterclass"]	\N	\N
257	widget_1765439706399_urrce96pp	2025-12-26 08:57:39.061703	can you connect me with Shaveta?	We'd love to help you connect with Shaveta! The first step is to book a complimentary 15-minute Discovery Call, which will help you gain clarity on whether working together is a good fit. You can apply for the call here: [https://bit.ly/apply-for-discovery](https://bit.ly/apply-for-discovery). \n\nJust find a quiet space, bring a notebook if you’d like, and come with openness — you'll be guided through everything during the call. Let me know if you need any more help!	f	\N	["website_inner_mastery_lounge.txt", "discovery_call_faq.txt", "website_services.txt"]	\N	\N
259	widget_1765439706399_urrce96pp	2025-12-26 08:58:52.652117	that's ok what programs do you offer	We have a variety of programs tailored to support different areas of personal growth and healing. Here’s a brief overview:\n\n1. **[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)** - A masterclass to uncover and heal emotional patterns affecting your career and relationships.\n\n2. **[Balance Mastery](https://joveheal.com/balance-mastery/)** - A 3-month 1:1 coaching program designed for high-performing leaders, focusing on stress management and restoring balance.\n\n3. **[Inner Reset](https://joveheal.com/inner-reset/)** - For high achievers feeling soul-tired, this course helps release silent pain and cultivate self-love.\n\n4. **[Career Healing](https://joveheal.com/career-healing/)** - This program clears obstacles and alignment issues in your career path.\n\n5. **[Relationship Healing](https://joveheal.com/relationship-healing/)** - Focuses on healing core relationship wounds and blocking patterns for improved intimacy.\n\n6. **[Shed & Shine](https://joveheal.com/shed-and-shine/)** - A program designed to help release what doesn't serve you, enabling personal growth.\n\n7. **[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)** - A comprehensive course library providing several transformational courses for holistic healing.\n\nWould you like to know more about a specific program, or should I guide you to any of these pages?	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt", "Coaching: Relationship Healing Course Session 1"]	\N	\N
260	widget_1765439706399_urrce96pp	2025-12-26 08:59:55.401541	i need more info on career healing	Absolutely! Our **[Career Healing](https://joveheal.com/career-healing/)** program is designed for professionals who feel stuck, burnt out, or disconnected from their work. \n\nThis transformational self-paced course focuses on helping you clear resentment, eliminate fear-based decisions, and overcome recurring obstacles. By doing so, you can create a fulfilling career path aligned with your purpose and values. \n\nSome key aspects of the program include:\n\n- Uncovering and releasing what stands between you and your success\n- Rewiring your confidence and authority \n- Enhancing your communication skills for success at work\n\nIt's perfect for those who know they're capable of more but struggle with self-doubt or anxiety in their career.\n\nWould you like me to take you to the [Career Healing](https://joveheal.com/career-healing/) page for further details?	f	\N	["website_services.txt", "Coaching: Career Healing Course - Masterclass", "website_career_healing.txt"]	\N	\N
261	widget_1765439706399_urrce96pp	2025-12-26 09:00:02.515808	yes please	[NAVIGATE:https://joveheal.com/career-healing/] Taking you to the [Career Healing](https://joveheal.com/career-healing/) page now!	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing Course - Masterclass"]	\N	\N
262	widget_1765439706399_urrce96pp	2025-12-26 09:02:24.0775	good how do I purchase this program	You can purchase the [Career Healing](https://joveheal.com/career-healing/) program directly on its page. Just visit the [Career Healing](https://joveheal.com/career-healing/) page, and there will be options for enrollment. \n\nIf you have any questions during the process or need assistance, feel free to reach out to us. We're here to help! Would you like any more information on this program or anything else?	f	\N	["joveheal_sample.txt", "website_services.txt", "website_inner_mastery_lounge.txt"]	\N	\N
263	test-checkout-123	2025-12-26 09:12:17.430536	How do I purchase the Career Healing program?	You can enroll in the [Career Healing](https://joveheal.com/career-healing/) program directly through our checkout page. Would you like me to take you to the Career Healing checkout page?	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt", "joveheal_sample.txt"]	\N	\N
264	test-checkout-456	2025-12-26 09:12:24.041887	How do I purchase the Career Healing program?	You can enroll in the [Career Healing](https://joveheal.com/career-healing/) program directly through our checkout page. Would you like me to take you to the Career Healing checkout page?	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt", "joveheal_sample.txt"]	\N	\N
265	test-checkout-456	2025-12-26 09:12:33.863168	yes please take me to checkout	[NAVIGATE:https://www.joveheal.com/offers/rhGziNgA/checkout] Taking you to the [Career Healing](https://joveheal.com/career-healing/) checkout page now!	f	\N	["Coaching: Career Healing Course - Masterclass", "Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1"]	\N	\N
266	test-discovery-789	2025-12-26 09:12:36.623001	can you connect me with Shaveta?	We’d love to help you connect with Shaveta! The first step is to book a complimentary 15-minute Discovery Call, where you can explore working together. You can apply for the call here: [https://bit.ly/apply-for-discovery](https://bit.ly/apply-for-discovery). Would you like me to assist you with anything else related to the call?	f	\N	["discovery_call_faq.txt", "website_services.txt", "website_testimonials.txt"]	\N	\N
267	test-discovery-new-1	2025-12-26 09:13:08.42673	can you connect me with Shaveta?	We'd love to help you connect with Shaveta! The first step is to book a complimentary 15-minute Discovery Call. Would you like me to take you to the Discovery Call booking page?	f	\N	["discovery_call_faq.txt", "website_services.txt", "website_testimonials.txt"]	\N	\N
268	test-inner-child-1	2025-12-26 09:13:12.310158	Tell me about inner child healing	I can sense this is something that would really benefit from Shweta's deeper work 💙. What you're describing - that kind of healing - is something she works on powerfully in her one-to-one sessions.\n\nWould you like to explore working with her directly? You can book a complimentary 15-minute Discovery Call here: https://bit.ly/apply-for-discovery\n\nIn the meantime, I'm here to listen and support you with what you're going through.	t	safety_redirect	\N	\N	\N
269	test-inner-child-new	2025-12-26 09:13:51.782372	Tell me about inner child healing	I can sense this is something that would really benefit from Shweta's deeper work 💙. What you're describing - that kind of healing - is something she works on powerfully in her one-to-one sessions.\n\nWould you like me to take you to the Discovery Call booking page so you can explore working with her directly?\n\nIn the meantime, I'm here to listen and support you with what you're going through.	t	safety_redirect	\N	\N	\N
270	test-checkout-final	2025-12-26 09:14:48.200343	How do I purchase the Career Healing program? (no changes needed)	You can enroll in the [Career Healing](https://joveheal.com/career-healing/) program directly at the [checkout page](https://www.joveheal.com/offers/rhGziNgA/checkout). Would you like me to take you there now?	f	\N	["website_services.txt", "joveheal_sample.txt", "website_homepage.txt"]	\N	\N
271	test-rel-heal	2025-12-26 09:35:07.534737	How do I purchase Relationship Healing?	You can view the details and purchase [Relationship Healing](https://joveheal.com/relationship-healing/) at [the checkout page](https://www.joveheal.com/offers/eqmhnvnj/checkout). Would you like me to take you there now?	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt", "Coaching: Relationship Healing Elevate 360 Session 1"]	\N	\N
274	test-elev-360	2025-12-26 09:35:19.258825	I want to join Elevate 360	That's wonderful to hear! [Elevate 360](https://joveheal.com/elevate-360/) is a transformative 5-month group healing and coaching experience designed for high-performing individuals. It offers live sessions, ongoing support, and community connections to help you reclaim your emotional foundation and find balance in every aspect of your life.\n\nTo enroll, you can visit the program page directly. Would you like me to take you to the Elevate 360 page?	f	\N	["website_elevate360.txt", "website_services.txt", "joveheal_sample.txt"]	\N	\N
275	test-shed-shine2	2025-12-26 09:35:28.469052	I want to buy Shed and Shine	Great choice! You can view details and enroll in [Shed & Shine](https://joveheal.com/shed-and-shine/) at [the checkout page](https://www.joveheal.com/offers/UinabNiW/checkout). Would you like me to take you there?	f	\N	["website_inner_mastery_lounge.txt", "website_shed_and_shine.txt", "discovery_call_faq.txt"]	\N	\N
276	test-elev-360-enroll	2025-12-26 09:35:30.188441	How do I enroll in Elevate 360?	You can enroll in [Elevate 360](https://joveheal.com/elevate-360/) directly through our program page. Would you like me to take you there for more details?	f	\N	["website_elevate360.txt", "website_services.txt", "joveheal_sample.txt"]	\N	\N
277	test-elev-360-join	2025-12-26 09:35:50.862951	How do I join Elevate 360?	You can enroll in [Elevate 360](https://joveheal.com/elevate-360/) directly at our checkout page. Would you like me to take you there?	f	\N	["website_services.txt", "website_elevate360.txt", "joveheal_sample.txt"]	\N	\N
278	test-elev-360-final	2025-12-26 09:37:31.417005	How do I join Elevate 360?	To join [Elevate 360](https://joveheal.com/elevate-360/), you can visit the program page for details and to enroll. Would you like me to take you there?	f	\N	["website_services.txt", "website_elevate360.txt", "joveheal_sample.txt"]	\N	\N
279	test-elev-buy	2025-12-26 09:37:40.181351	I want to purchase Elevate 360	That's fantastic! You can enroll in [Elevate 360](https://joveheal.com/elevate-360/) directly at the [the checkout page](https://www.joveheal.com/offers/tTHVwSi7/checkout). Would you like me to take you there?	f	\N	["website_elevate360.txt", "website_services.txt", "website_inner_mastery_lounge.txt"]	\N	\N
280	test-iml	2025-12-26 09:37:42.40231	How do I enroll in Inner Mastery Lounge? (no changes needed)	To enroll in the [Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/), you can visit the program page to explore subscription options. Would you like me to take you to the Inner Mastery Lounge page for more details?	f	\N	["joveheal_sample.txt", "website_inner_mastery_lounge.txt"]	\N	\N
281	test-career-healing	2025-12-26 09:37:56.620967	How do I purchase Career Healing?	You can view pricing and enroll in [Career Healing](https://joveheal.com/career-healing/) directly at the [checkout page](https://www.joveheal.com/offers/rhGziNgA/checkout). Would you like me to take you there now?	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt", "Coaching: Career Healing Course - Masterclass"]	\N	\N
282	test-relationship-healing	2025-12-26 09:37:58.68326	How do I purchase Relationship Healing?	You can view pricing and enroll in [Relationship Healing](https://joveheal.com/relationship-healing/) directly at [the checkout page](https://www.joveheal.com/offers/eqmhnvnj/checkout). Would you like me to take you there?	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt", "Coaching: Relationship Healing Elevate 360 Session 1"]	\N	\N
283	test-beyond-the-hustle	2025-12-26 09:38:00.533768	How do I purchase Beyond the Hustle?	You can enroll in [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) at the checkout page here: [Beyond the Hustle Checkout](https://www.joveheal.com/offers/osL3L3qG/checkout). Would you like me to take you there?	f	\N	["website_services.txt", "website_beyond_the_hustle.txt", "Coaching: Career Healing Course - Masterclass"]	\N	\N
284	test-inner-reset	2025-12-26 09:38:02.053063	How do I purchase Inner Reset? (no changes needed)	To enroll in the [Inner Reset](https://joveheal.com/inner-reset/), you'll need to access the program page for more information. Would you like me to take you to the Inner Reset page?	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt", "website_elevate360.txt"]	\N	\N
285	test-shed-and-shine	2025-12-26 09:38:03.66044	How do I purchase Shed and Shine?	You can view details and enroll in [Shed & Shine](https://joveheal.com/shed-and-shine/) at the checkout page here: [Shed & Shine Checkout](https://www.joveheal.com/offers/UinabNiW/checkout). Would you like me to take you there now?	f	\N	["website_inner_mastery_lounge.txt", "discovery_call_faq.txt", "website_shed_and_shine.txt"]	\N	\N
286	test-money-and-abundance	2025-12-26 09:38:05.469776	How do I purchase Money and Abundance?	You can view details and enroll in the [Money and Abundance](https://joveheal.com/money-abundance-manifestation/) program at the checkout page [here](https://www.joveheal.com/offers/rkz4QPFN/checkout). Would you like me to take you there now?	f	\N	["Coaching: Career - Money Manifestation", "Coaching: Career Healing - Elevate 360 Session 2"]	\N	\N
287	test-meta-u	2025-12-26 09:38:07.472459	How do I purchase Meta-U?	[Meta-U](https://joveheal.com/meta-u/) is a private coaching experience designed for those who have previously worked with Shaveta. Since it's not a direct purchase program, the first step to get started is to book a complimentary Discovery Call. During this call, you'll discuss your journey and see how Meta-U can support you.\n\nWould you like me to take you to the Discovery Call booking page?	f	\N	["website_services.txt", "discovery_call_faq.txt", "joveheal_sample.txt"]	\N	\N
288	test-healing-circle	2025-12-26 09:38:09.17565	How do I purchase Healing Circle?	It looks like the [Healing Circle](https://joveheal.com/healing-circle/) isn't available for direct purchase through [the checkout page](https://www.joveheal.com/offers/xBJPLFqC/checkout). However, we recommend checking out our website for more details about it. Would you like me to take you to the Healing Circle page for more information?	f	\N	["Coaching: Career - Money Manifestation", "website_elevate360.txt", "joveheal_sample.txt"]	\N	\N
289	test-elevate-360	2025-12-26 09:38:10.807314	How do I purchase Elevate 360?	You can enroll in [Elevate 360](https://joveheal.com/elevate-360/) directly on our program page. Would you like me to take you to the Elevate 360 page for more details?	f	\N	["website_elevate360.txt", "website_services.txt", "website_inner_mastery_lounge.txt"]	\N	\N
290	test-balance-mastery	2025-12-26 09:38:12.684425	How do I purchase Balance Mastery?	[Balance Mastery](https://joveheal.com/balance-mastery/) is a one-to-one coaching experience with Shaveta. To get started, you can book a complimentary Discovery Call where she'll learn about your needs and guide you through the next steps. Would you like me to take you to the [Discovery Call booking page](https://www.joveheal.com/apply-for-discovery-call)?	f	\N	["website_services.txt", "Coaching: Career Healing Course - Masterclass", "website_balance_mastery.txt"]	\N	\N
291	test-inner-mastery-lounge	2025-12-26 09:38:14.517051	How do I purchase Inner Mastery Lounge?	To join the [Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/), you can explore subscription options on the program page. Would you like me to take you to the Inner Mastery Lounge page for more details?	f	\N	["joveheal_sample.txt", "website_inner_mastery_lounge.txt"]	\N	\N
293	widget_1766742685773_vcxw3yoq7	2025-12-26 09:51:42.514591	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
294	widget_1766742685773_vcxw3yoq7	2025-12-26 09:53:17.141402	i am struggling with my relationships	I'm really sorry to hear that you're facing challenges in your relationships. It's totally valid to feel this way, and you're not alone in experiencing these feelings. We have a program called "[Relationship Healing](https://joveheal.com/relationship-healing/)" that focuses on healing core relationship wounds and helping create safer, more connected interactions. Would you like to learn more about it or maybe see how to connect with our team for support?	f	\N	["website_inner_mastery_lounge.txt", "website_elevate360.txt"]	\N	\N
295	widget_1766742685773_vcxw3yoq7	2025-12-26 09:53:28.782364	yes please	[NAVIGATE:https://joveheal.com/relationship-healing/] Taking you to the [Relationship Healing](https://joveheal.com/relationship-healing/) page now! Please let me know if you have any questions or if there's anything else we can assist you with.	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing Course - Masterclass"]	\N	\N
296	widget_1766742685773_vcxw3yoq7	2025-12-26 09:55:20.971817	do you offer chakra healing	I can sense this is something that would really benefit from Shweta's deeper work 💙. What you're describing - that kind of healing - is something she works on powerfully in her one-to-one sessions.\n\nWould you like me to take you to the Discovery Call booking page so you can explore working with her directly?\n\nIn the meantime, I'm here to listen and support you with what you're going through.	t	\N	\N	\N	\N
297	widget_1766742685773_vcxw3yoq7	2025-12-26 09:55:40.058306	yes please	[NAVIGATE:https://bit.ly/apply-for-discovery] Taking you to the Discovery Call booking page now! You'll be able to schedule a complimentary session with Shweta to discuss your needs. If you have any more questions or need assistance, just let me know!	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing Course - Masterclass"]	\N	\N
298	widget_1766742685773_vcxw3yoq7	2025-12-26 09:56:23.455821	thank you what other programs do you offer	You're welcome! We offer a variety of programs designed to support your personal and professional growth. Here’s a quick overview:\n\n1. **[Balance Mastery](https://joveheal.com/balance-mastery/)** - A 3-month 1:1 coaching program for leaders seeking internal success.\n2. **[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)** - A membership community with monthly healings and transformational courses.\n3. **[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)** - Uncover and heal patterns that prevent you from thriving.\n4. **[Career Healing](https://joveheal.com/career-healing/)** - Align your career with your purpose by clearing common obstacles.\n5. **[Relationship Healing](https://joveheal.com/relationship-healing/)** - Heal core wounds to enhance intimacy and connection in relationships.\n6. **[Shed & Shine](https://joveheal.com/shed-and-shine/)** - Emotional healing to help with weight release.\n7. **[Inner Reset](https://joveheal.com/inner-reset/)** - A course to reconnect with yourself and foster self-love.\n\nWould you like to learn more about any specific program or see the details of our offerings? Let me know!	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt", "Coaching: Relationship Healing Course Session 1"]	\N	\N
299	widget_1766742685773_vcxw3yoq7	2025-12-26 09:56:37.907132	What is Shed and Shine program?	The **[Shed & Shine](https://joveheal.com/shed-and-shine/)** program is a transformative journey designed to help you let go of emotional weight and release the armor your body has carried for years. Many participants have found that by doing this inner work, they can shed between 5 to 11 kilos in just four weeks.\n\nThis program focuses on emotional healing, promoting a sense of lightness, clarity, and overall well-being. Would you like me to take you to the Shed & Shine page for more details?	f	\N	["website_inner_mastery_lounge.txt", "joveheal_sample.txt", "website_services.txt"]	\N	\N
300	widget_1766742685773_vcxw3yoq7	2025-12-26 09:56:48.010694	yes please	[NAVIGATE:https://joveheal.com/shed-and-shine/] Taking you to the [Shed & Shine](https://joveheal.com/shed-and-shine/) page now! You’ll find more information about the program and how it can support your journey. If you have any other questions or need assistance, feel free to ask!	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing Course - Masterclass"]	\N	\N
301	widget_1766742685773_vcxw3yoq7	2025-12-26 09:57:15.458731	what is relationship healing	**[Relationship Healing](https://joveheal.com/relationship-healing/)** is a deep healing session tailored for women who have found success in their careers but seek to create the same fulfillment in their relationships. This 3-hour session goes beyond surface-level fixes, guiding you through root-level healing to dissolve emotional pain and transform your relationships.\n\nIn this session, you'll learn to turn arguments into deeper connections, rebuild trust, and reconnect with yourself, allowing you to show up with love and clarity in every relationship. You'll explore techniques like the Mirror Principle and the 5 Core Wounds Map to understand and release patterns that block intimacy.\n\nWould you like me to take you to the [Relationship Healing](https://joveheal.com/relationship-healing/) page for more detailed information?	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt", "Coaching: When Marriage Does Not Feel Like Love Anymore"]	\N	\N
302	widget_1766742685773_vcxw3yoq7	2025-12-26 09:58:15.281591	yes please	[NAVIGATE:https://joveheal.com/relationship-healing/] Taking you to the [Relationship Healing](https://joveheal.com/relationship-healing/) page now! There, you can explore more about this profound program. If you have any other questions or need further assistance, just let us know!	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing Course - Masterclass"]	\N	\N
303	widget_1766742685773_vcxw3yoq7	2025-12-26 09:58:33.430382	what about career healing?	**[Career Healing](https://joveheal.com/career-healing/)** is a transformative self-paced program designed for professionals feeling stuck, burnt out, or disconnected from their work. It helps you identify and clear obstacles such as resentment and fear-based decisions, enabling you to realign your career path with your true purpose and values.\n\nThe program focuses on rewiring your confidence, enhancing your authority, and improving your communication skills for greater success at work. It's tailored for high-achievers who want to break free from self-doubt and unleash their full potential.\n\nWould you like to explore more details about the [Career Healing](https://joveheal.com/career-healing/) program?	f	\N	["website_services.txt", "Coaching: Career Healing Course - Masterclass", "website_career_healing.txt"]	\N	\N
304	widget_1766742685773_vcxw3yoq7	2025-12-26 09:58:39.781946	yes please	[NAVIGATE:https://joveheal.com/career-healing/] Taking you to the [Career Healing](https://joveheal.com/career-healing/) page now! There, you can find more information about the program and how it can help you. If you have any other questions or need further assistance, feel free to ask!	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing Course - Masterclass"]	\N	\N
305	widget_1766742685773_vcxw3yoq7	2025-12-26 09:59:01.699605	What does Career Healing offer? (no changes needed)	**[Career Healing](https://joveheal.com/career-healing/)** helps you clear resentment, fear-based decisions, and recurring obstacles, so you can create a career path aligned with your purpose and values. \n\nIs there anything else you'd like to know about this program or something else?	f	\N	["website_services.txt", "website_homepage.txt", "website_inner_mastery_lounge.txt"]	\N	\N
306	widget_1766742685773_vcxw3yoq7	2025-12-26 09:59:18.883188	Give me more details about this Career Healing program.	The **[Career Healing](https://joveheal.com/career-healing/)** program is designed for professionals who feel stuck, burnt out, or disconnected from their work. It focuses on:\n\n- Clearing emotional blocks that may be holding you back, such as resentment and fear-based decisions.\n- Identifying recurring obstacles in your career path and working through them.\n- Aligning your career with your true purpose and values to foster fulfillment and growth.\n\nThroughout the program, you'll gain insights and tools to help you move forward with confidence and clarity in your professional journey.\n\nWould you like to know how to enroll or explore our other programs?	f	\N	["website_services.txt", "Coaching: Relationship Healing Course Session 1", "website_homepage.txt"]	\N	\N
307	widget_1766742685773_vcxw3yoq7	2025-12-26 09:59:35.335687	Yes, I would like to know how to enroll.	You can enroll in the **[Career Healing](https://joveheal.com/career-healing/)** program directly at the checkout page. Here’s the link for you: [Career Healing Checkout](https://www.joveheal.com/offers/rhGziNgA/checkout). \n\nWould you like me to take you there now?	f	\N	["website_services.txt", "Coaching: Relationship Healing Course Session 1", "website_inner_mastery_lounge.txt"]	\N	\N
308	widget_1766742685773_vcxw3yoq7	2025-12-26 09:59:43.425814	yes	[NAVIGATE:https://www.joveheal.com/offers/rhGziNgA/checkout] Taking you to the [Career Healing](https://joveheal.com/career-healing/) checkout page now!	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2"]	\N	\N
309	widget_1766743211913_4qluridey	2025-12-26 10:00:43.054625	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
310	widget_1766743243552_vuyrpdkzt	2025-12-26 10:00:57.300818	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you have questions about our programs or are looking for support, I'm here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
311	widget_1766743243552_vuyrpdkzt	2025-12-26 10:01:08.290007	I am struggling with my relationships	I'm really sorry to hear that you're feeling this way—it's completely understandable to struggle with relationships at times. We have a program called "[Relationship Healing](https://joveheal.com/relationship-healing/)" that focuses on healing core relationship wounds, releasing patterns that block intimacy, and fostering deeper connections. Would you like me to share more about this program or help you connect with our team?	f	\N	["website_inner_mastery_lounge.txt", "website_elevate360.txt", "website_balance_mastery.txt"]	\N	\N
312	widget_1766743243552_vuyrpdkzt	2025-12-26 10:01:16.478049	yes please	[NAVIGATE:https://joveheal.com/relationship-healing/] Taking you to the [Relationship Healing](https://joveheal.com/relationship-healing/) page now! You can find more details there. If you have any questions or need further assistance, feel free to ask!	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing Course - Masterclass"]	\N	\N
313	widget_1766743288779_1q6yw6hbm	2025-12-26 10:02:35.628734	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
314	widget_1766743288779_1q6yw6hbm	2025-12-26 10:02:44.720493	I am struggling with my career	I'm really sorry to hear that you’re struggling — it's completely understandable to feel this way at times. We have programs like "[Career Healing](https://joveheal.com/career-healing/)" which can help you work through challenges and find clarity in your professional life. Would you like me to share more about this program or help you connect with our team?	f	\N	["website_inner_mastery_lounge.txt", "website_elevate360.txt", "joveheal_sample.txt"]	\N	\N
315	widget_1766743288779_1q6yw6hbm	2025-12-26 10:02:51.624391	yes	[NAVIGATE:https://joveheal.com/career-healing/] Taking you to the [Career Healing](https://joveheal.com/career-healing/) page now! Here, you can explore how our program can support you in overcoming your career struggles. If you have any questions, feel free to ask!	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2"]	\N	\N
346	test_ratelimit_session	2025-12-27 10:39:33.203775	Hello	Hi there! Welcome back! I'm Jovee, your guide here at JoveHeal. How can I assist you today? Whether you're curious about our programs or need support, I'm here to help!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
347	test_ratelimit_session	2025-12-27 10:39:35.271472	Hello	Hi there! I'm Jovee, your guide at JoveHeal. It's great to see you! How can I assist you today? If you have questions about our programs or anything else, I'm here to help!	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
316	widget_1766743288779_1q6yw6hbm	2025-12-26 10:03:10.647045	thanks what other programs do you offer	You're welcome! Alongside [Career Healing](https://joveheal.com/career-healing/), we offer several other programs to support your journey, including:\n\n1. **[Balance Mastery](https://joveheal.com/balance-mastery/)** - A 1:1 coaching program for high-performing leaders seeking inner balance.\n2. **[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)** - Focuses on uncovering emotional roots of exhaustion.\n3. **[Elevate 360](https://joveheal.com/elevate-360/)** - A 5-month group experience aimed at healing and growth.\n4. **[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)** - A membership community with ongoing support and resources.\n5. **[Relationship Healing](https://joveheal.com/relationship-healing/)** - Helps address and heal wounds in personal relationships.\n6. **[Shed & Shine](https://joveheal.com/shed-and-shine/)** - Focused on weight release through emotional healing.\n\nIf you'd like to know more about any specific program, just let me know! Would you like me to take you to one of the program pages?	f	\N	["website_elevate360.txt", "website_services.txt", "joveheal_sample.txt"]	\N	\N
317	widget_1766743288779_1q6yw6hbm	2025-12-26 10:03:24.122284	what is shed and shine program	The "[Shed & Shine](https://joveheal.com/shed-and-shine/)" program is designed to help you release emotional weight and let go of the emotional armor your body has carried. In just four weeks, many participants have experienced significant shifts, often shedding 5–11 kilos through inner work and transformative practices.\n\nThe program focuses on not just physical changes but also emotional and energetic healing, helping you to feel lighter and more aligned. Would you like me to take you to the [Shed & Shine](https://joveheal.com/shed-and-shine/) page for more details?	f	\N	["joveheal_sample.txt", "website_services.txt", "website_inner_mastery_lounge.txt"]	\N	\N
318	widget_1766743288779_1q6yw6hbm	2025-12-26 10:03:31.649374	yes please	[NAVIGATE:https://joveheal.com/shed-and-shine/] Taking you to the [Shed & Shine](https://joveheal.com/shed-and-shine/) page now! Here you can explore more about the program and see how it can support you on your journey. If you have any questions, feel free to ask!	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing Course - Masterclass"]	\N	\N
319	widget_1766743288779_1q6yw6hbm	2025-12-26 10:03:50.432677	do you offer chakra healing	I can sense this is something that would really benefit from Shweta's deeper work 💙. What you're describing - that kind of healing - is something she works on powerfully in her one-to-one sessions.\n\nWould you like me to take you to the Discovery Call booking page so you can explore working with her directly?\n\nIn the meantime, I'm here to listen and support you with what you're going through.	t	\N	\N	\N	\N
320	widget_1766743288779_1q6yw6hbm	2025-12-26 10:04:00.114924	yes please	[NAVIGATE:https://bit.ly/apply-for-discovery] Taking you to the Discovery Call booking page now! Here, you can book a complimentary 15-minute call with Shweta to discuss your needs and how she can help with chakra healing. If you have any other questions or need further assistance, just let us know!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Healing Sessions](https://joveheal.com/healing-sessions/) | [Services](https://joveheal.com/services/)	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing Course - Masterclass"]	\N	\N
321	widget_1766743288779_1q6yw6hbm	2025-12-26 10:04:24.777064	thank you ... what about other programs	You're very welcome! We have a variety of programs designed to support different aspects of wellness. Here are a few you might find interesting:\n\n1. **[Balance Mastery](https://joveheal.com/balance-mastery/)** - A 3-month 1:1 coaching program for high-performing leaders seeking internal balance.\n2. **[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)** - This program helps uncover emotional roots of exhaustion and find fulfillment.\n3. **[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)** - A membership community offering weekly group coaching, guided meditations, and personal development resources.\n\nIf you'd like more detailed information about any of these programs or others, just let us know! Would you like me to take you to any specific program page?	f	\N	["website_inner_mastery_lounge.txt", "website_services.txt", "Coaching: Career Healing Course - Masterclass"]	\N	\N
322	widget_1766743288779_1q6yw6hbm	2025-12-26 10:04:42.254525	I want to enroll for balance mastery	[Balance Mastery](https://joveheal.com/balance-mastery/) is a wonderful choice! To enroll, the first step is to book a complimentary Discovery Call with Shweta. This call will help clarify your needs and how the program can support you. Would you like me to take you to the [Discovery Call booking page](https://bit.ly/apply-for-discovery)?	f	\N	["joveheal_sample.txt", "website_services.txt", "website_inner_mastery_lounge.txt"]	\N	\N
323	widget_1766743288779_1q6yw6hbm	2025-12-26 10:05:07.654723	no what about other programs	Absolutely! Here’s a quick overview of some of our other programs:\n\n1. **[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)** - A membership community that provides group coaching, meditations, masterclasses, and resources for ongoing support in personal development.\n   \n2. **[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)** - This program focuses on uncovering the emotional roots of exhaustion and finding deeper fulfillment in life.\n\n3. **[Shed & Shine](https://joveheal.com/shed-and-shine/)** - This program is designed to help individuals release emotional burdens and shine in their true selves.\n\n4. **[Relationship Healing](https://joveheal.com/relationship-healing/)** - A program aimed at healing relationship patterns and fostering deeper connections.\n\n5. **[Career Healing](https://joveheal.com/career-healing/)** - This program focuses on addressing career-related issues and achieving personal success.\n\nIf you're interested in any specific program or would like more details, please let me know, and I can take you to the appropriate page!	f	\N	["website_inner_mastery_lounge.txt", "website_services.txt", "joveheal_sample.txt"]	\N	\N
324	widget_1766743288779_1q6yw6hbm	2025-12-26 10:05:20.753183	I would like to enroll for shed and shine	Great choice! To enroll in the **[Shed & Shine](https://joveheal.com/shed-and-shine/)** program, you can proceed to the [the checkout page](https://www.joveheal.com/offers/UinabNiW/checkout). Would you like me to take you there?	f	\N	["website_inner_mastery_lounge.txt", "joveheal_sample.txt", "website_services.txt"]	\N	\N
325	widget_1766743288779_1q6yw6hbm	2025-12-26 10:05:27.093326	yes please	[NAVIGATE:https://www.joveheal.com/offers/UinabNiW/checkout] Taking you to the [Shed & Shine](https://joveheal.com/shed-and-shine/) checkout page now!	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing Course - Masterclass"]	\N	\N
348	test_ratelimit_session	2025-12-27 10:39:37.362181	Hello	Hi there! I'm Jovee, your friendly guide at JoveHeal. It’s nice to see you! How can I help you today? If you have any questions or need information about our programs, feel free to ask!	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
326	widget_1766785483673_t52drs50z	2025-12-26 21:45:12.19301	today is Friday what should I do to relax	It's great that you're looking to relax! We suggest you try some simple breathing exercises to help calm your mind and body. A great one to start with is to inhale deeply for four counts, hold for four, and exhale slowly for six. Repeat this a few times to create a sense of safety and relaxation. \n\nYou might also consider spending some time in nature, enjoying a favorite hobby, or perhaps indulging in a warm bath. Remember, it's all about finding what helps you unwind! If you want more personalized guidance or ideas, feel free to reach out to us.\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Shed & Shine](https://joveheal.com/shed-and-shine/) | [Inner Reset](https://joveheal.com/inner-reset/) | [Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)	f	\N	["Coaching: Health Healing - Elevate 360 Session 2", "Coaching: Career - Money Manifestation", "Coaching: 1:1 Session - Career Transition & Goal Setting"]	\N	\N
327	widget_1766785483673_t52drs50z	2025-12-26 21:45:53.268142	what is inner reset	The [Inner Reset](https://joveheal.com/inner-reset/) is a self-paced healing course designed for those who feel emotionally exhausted, disconnected, or burdened by unaddressed feelings. It helps individuals release invisible grief and reconnect with their truest selves. Through powerful practices like inner child healing, emotional release, energetic clearing, and self-love activation, participants are guided to rejuvenate themselves.\n\nYou'll gain lifetime access to the course materials, allowing you to revisit the healing process anytime you need. Would you like me to take you to the Inner Reset page for more details?	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt", "Coaching: Do you feel lonely among your loved ones?"]	\N	\N
328	widget_1766785483673_t52drs50z	2025-12-26 21:46:08.604495	yes	[NAVIGATE:https://joveheal.com/inner-reset/] Taking you to the [Inner Reset](https://joveheal.com/inner-reset/) page now!	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2"]	\N	\N
329	widget_1766785483673_t52drs50z	2025-12-26 21:48:05.920751	I am feeling unwell	I'm truly sorry to hear that you're not feeling well. It's important to take care of yourself, and I encourage you to speak with a licensed professional if you're dealing with medical or mental health concerns. \n\nIf you're looking for support or to explore ways to feel better emotionally, we have programs like [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) that focus on releasing emotional exhaustion. Would you like more information on that, or would you prefer to connect with our team?	f	\N	["Coaching: Career Healing Course - Masterclass", "Coaching: Health Healing - Elevate 360 Session 1", "Coaching: Health Healing - Elevate 360 Session 2"]	\N	\N
330	widget_1766785483673_t52drs50z	2025-12-26 21:48:43.612322	I am having fever	I'm really sorry to hear that you're experiencing a fever. It's essential to prioritize your health and consult a medical professional who can provide the appropriate care and guidance. \n\nIn the meantime, if you're feeling emotionally overwhelmed or would like to explore resources that may help with stress management, we have programs available. Please let us know how we can support you best during this time.\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Career Healing](https://joveheal.com/career-healing/) | [Balance Mastery](https://joveheal.com/balance-mastery/) | [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)	f	\N	["Coaching: Health Healing - Elevate 360 Session 1", "Coaching: Health Healing - Elevate 360 Session 2", "Coaching: Career Healing Course - Masterclass"]	\N	\N
331	widget_1766785483673_t52drs50z	2025-12-26 21:50:10.640418	beyond the hustle	"[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" is a transformative masterclass designed for those who appear successful outwardly but may feel drained and disconnected internally. It helps uncover the emotional roots of exhaustion and silence that many high achievers experience.\n\nIn this masterclass, you'll learn about the hidden patterns shaping your life, receive practical insights to rebuild from inner truth, and experience a guided shift to release limiting beliefs. This isn't just another motivational talk; it’s an emotional reset that incorporates both science and soul.\n\nWould you like me to take you to the [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) page for more information?	f	\N	["website_services.txt", "website_beyond_the_hustle.txt", "website_inner_mastery_lounge.txt"]	\N	\N
332	widget_1766785483673_t52drs50z	2025-12-26 21:50:17.039948	yes	[NAVIGATE:https://joveheal.com/beyond-the-hustle/] Taking you to the [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) page now!	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2"]	\N	\N
333	widget_1766785483673_t52drs50z	2025-12-26 21:51:11.218618	can you help me with chakra healing	I can sense this is something that would really benefit from Shweta's deeper work 💙. What you're describing - that kind of healing - is something she works on powerfully in her one-to-one sessions.\n\nWould you like me to take you to the Discovery Call booking page so you can explore working with her directly?\n\nIn the meantime, I'm here to listen and support you with what you're going through.	t	\N	\N	\N	\N
334	widget_1766785483673_t52drs50z	2025-12-26 21:51:25.263929	yes	[NAVIGATE:https://bit.ly/apply-for-discovery] Taking you to the Discovery Call booking page now!	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2"]	\N	\N
335	widget_1766785483673_t52drs50z	2025-12-26 21:52:12.433727	yes	I'm glad you're interested! Here's the link to book your complimentary Discovery Call: [Discovery Call Booking](https://bit.ly/apply-for-discovery). You'll receive a confirmation email with all the details after you book. We look forward to connecting with you! If you have any other questions, feel free to ask.	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2"]	\N	\N
349	test_ratelimit_session	2025-12-27 10:39:39.46386	Hello	Hi there! I'm Jovee, your guide here at JoveHeal. It's lovely to see you! How can I assist you today? If you have any questions or need support, I’m here for you!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
350	test_ratelimit_session	2025-12-27 10:39:41.171941	Hello	Hi there! I'm Jovee, your friendly guide at JoveHeal. It's wonderful to connect with you! What can I help you with today? If you're curious about our programs or need support, I'm here for you!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
336	widget_1766785483673_t52drs50z	2025-12-26 22:03:02.565534	what other programs do you offer	We offer a variety of programs designed to support your personal growth and healing journey. Here's a quick overview:\n\n1. **[Balance Mastery](https://joveheal.com/balance-mastery/)** - A 3-month coaching program for high-performing leaders aiming to restore balance and uncover stress roots.\n2. **[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)** - Helps you heal emotional blocks and regain your sense of self-worth.\n3. **[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)** - A subscription program providing access to transformational courses and community support.\n4. **[Elevate 360](https://joveheal.com/elevate-360/)** - A 5-month program focused on emotional healing and personal empowerment.\n5. **[Relationship Healing](https://joveheal.com/relationship-healing/)** - A course to help you mend relationship wounds and foster deeper connections.\n6. **[Career Healing](https://joveheal.com/career-healing/)** - Focuses on clearing obstacles in your career path that resonate with your purpose.\n\nWould you like to know more about a specific program, or perhaps explore how to get started?	f	\N	["Coaching: Relationship Healing Course Session 1", "website_inner_mastery_lounge.txt", "website_elevate360.txt"]	\N	\N
337	widget_1766785483673_t52drs50z	2025-12-26 22:03:15.558182	what is career healing	[Career Healing](https://joveheal.com/career-healing/) is designed for professionals who feel stuck, burnt out, or disconnected from their work. This program helps you clear resentment, address fear-based decisions, and eliminate recurring obstacles, allowing you to create a career path that aligns with your true purpose and values. \n\nIt's all about rewiring your confidence, authority, and communication to help you thrive at work! Would you like to take a closer look at the Career Healing program or explore the enrollment options?	f	\N	["website_services.txt", "website_career_healing.txt", "website_homepage.txt"]	\N	\N
338	widget_1766785483673_t52drs50z	2025-12-26 22:03:27.326149	please	You can view more details about the [Career Healing program](https://joveheal.com/career-healing/) and explore how it can support your journey. If you're interested in enrolling, you can also visit the checkout page here: [Career Healing Checkout](https://www.joveheal.com/offers/rhGziNgA/checkout). \n\nWould you like me to take you to the checkout page now?	f	\N	["Coaching: Relationship Healing Course Session 1", "Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career - Money Manifestation"]	\N	\N
339	widget_1766785483673_t52drs50z	2025-12-26 22:03:57.774903	k	[NAVIGATE:https://www.joveheal.com/offers/rhGziNgA/checkout] Taking you to the [Career Healing](https://joveheal.com/career-healing/) checkout page now!	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "website_elevate360.txt", "website_homepage.txt"]	\N	\N
340	widget_1766787170447_h4tqsfpgf	2025-12-26 22:12:56.258419	hi	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you're curious about our programs, looking for support, or just browsing — I'm happy to help!\n\n---\n\n*If you'd like to dive deeper, these might resonate with you:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
341	widget_1766787170447_h4tqsfpgf	2025-12-26 22:15:20.829002	what programs do you offer	We offer a variety of programs designed to support your wellness journey! Here are some of our core offerings:\n\n1. **[Balance Mastery](https://joveheal.com/balance-mastery/)**: A 3-month 1:1 coaching program for high-performing leaders.\n2. **[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/)**: An exclusive membership community with group coaching, meditations, and masterclasses.\n3. **[Elevate 360](https://joveheal.com/elevate-360/)**: A 5-month group healing and coaching experience aimed at restoring balance and reducing stress.\n4. **[Relationship Healing](https://joveheal.com/relationship-healing/)**: Focused on enhancing connections and communication.\n5. **[Career Healing](https://joveheal.com/career-healing/)**: Helping you navigate your professional journey with confidence.\n6. **[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)**: A program to uncover emotional roots of exhaustion.\n7. **[Inner Reset](https://joveheal.com/inner-reset/)**: Designed for deep self-exploration and healing.\n8. **[Shed & Shine](https://joveheal.com/shed-and-shine/)**: Focusing on releasing what no longer serves you.\n\nWould you like more details on any specific program? Just let us know!	f	\N	["joveheal_sample.txt", "website_inner_mastery_lounge.txt", "website_elevate360.txt"]	\N	\N
342	widget_1766787170447_h4tqsfpgf	2025-12-26 22:15:36.739607	what is shed and shine	[Shed & Shine](https://joveheal.com/shed-and-shine/) is a 5-week self-paced digital course designed to help you release unwanted layers of emotional weight and understand the root emotional causes behind it. Many participants have experienced significant transformations, including shedding physical weight and emotional burdens.\n\nHere's what you can expect from the course:\n- **Connect with Your Body**: Dive deep into uncovering emotional triggers tied to weight.\n- **Release Emotional Blocks**: Identify and let go of barriers holding you back.\n- **Reprogram Your Mindset**: Develop a healthier relationship with yourself.\n- **Build Sustainable Habits**: Create daily practices that support your emotional and physical well-being.\n\nYou gain lifetime access to meditations and digital recordings, allowing you to revisit the material whenever you need. Does that sound interesting? Would you like me to take you to the Shed & Shine page for more information?	f	\N	["website_inner_mastery_lounge.txt", "website_shed_and_shine.txt", "Coaching: Career Healing Course - Masterclass"]	\N	\N
343	widget_1766787170447_h4tqsfpgf	2025-12-26 22:15:49.850501	yes	[NAVIGATE:https://joveheal.com/shed-and-shine/] Taking you to the [Shed & Shine](https://joveheal.com/shed-and-shine/) page now!	f	\N	["Coaching: Relationship Healing Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing - Elevate 360 Session 2"]	\N	\N
344	test_ratelimit_session	2025-12-27 10:39:28.81508	Hello	Hi there! I'm Jovee, your guide here at JoveHeal. What brings you here today? Whether you have questions about our programs, need support, or just want to chat, I'm here to help!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
345	test_ratelimit_session	2025-12-27 10:39:30.951684	Hello	Hi there! I'm Jovee, your friendly guide at JoveHeal. What can I assist you with today? Whether you have questions about our programs or anything else on your mind, I'm here for you!	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
352	test_ratelimit_session	2025-12-27 10:39:45.386103	Hello	Hi there! I'm Jovee, your friendly guide from JoveHeal. It's lovely to see you again! How can I assist you today? If you have any questions or need support, I'm here for you!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
353	test_ratelimit_session	2025-12-27 10:39:47.579479	Hello	Hi there! I'm Jovee, your guide at JoveHeal. It's wonderful to connect with you! How can I support you today? Whether you have questions about our programs or anything else on your mind, I'm here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["Coaching: Career Healing - Elevate 360 Session 2", "Coaching: Career Healing - Elevate 360 Session 1", "Coaching: Career Healing Course - Masterclass"]	\N	\N
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feedback (id, message_id, session_id, rating, comment, created_at) FROM stdin;
\.


--
-- Data for Name: flagged_conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flagged_conversations (id, session_id, user_message, flag_reason, severity, created_at) FROM stdin;
\.


--
-- Data for Name: grest_products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grest_products (id, sku, name, category, variant, storage, color, condition, price, original_price, discount_percent, in_stock, warranty_months, product_url, image_url, description, specifications, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, conversation_id, role, content, sources, created_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, product_name, model, storage, condition, color, price_inr, mrp_inr, product_url, variant_id, in_stock, last_updated, created_at) FROM stdin;
\.


--
-- Data for Name: response_feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.response_feedback (id, conversation_id, rating, comment, created_at) FROM stdin;
1	\N	1	\N	2025-12-03 12:38:06.046593
2	\N	1	\N	2025-12-03 12:38:09.86584
\.


--
-- Data for Name: user_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_accounts (id, channel, external_id, email, display_name, profile_image, created_at, last_seen) FROM stdin;
1	google	sam27sep@gmail.com	sam27sep@gmail.com	Sammy Singh (sam9s)	https://lh3.googleusercontent.com/a/ACg8ocL72wyyprhoqBLskFOm1DqFmNaHmto9SPY_BRnI0-545Gp81Xcugg=s96-c	2025-12-04 05:34:18.56593	2025-12-21 05:20:20.84946
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, name, image, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: voice_conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.voice_conversations (id, call_id, started_at, ended_at, caller_phone, total_turns, full_transcript, readiness_scores, metadata, created_at) FROM stdin;
66	custom-llm-91385546	2025-12-24 22:51:14.818955	\N	\N	0	\N	\N	\N	2025-12-24 22:51:14.818955
68	custom-llm--8880117	2025-12-24 22:59:08.109121	\N	\N	0	\N	\N	\N	2025-12-24 22:59:08.109121
70	custom-llm--7203238	2025-12-24 23:13:13.577846	\N	\N	0	\N	\N	\N	2025-12-24 23:13:13.577846
72	019b52ae-6e42-733e-8f7b-d69096c6dfec	2025-12-24 23:25:32.50362	\N	\N	0	\N	\N	\N	2025-12-24 23:25:32.50362
88	custom-llm-89039404	2025-12-24 23:47:26.354714	\N	\N	0	\N	\N	\N	2025-12-24 23:47:26.354714
90	019b52cf-0355-7cc0-a3e9-8cc659f384cc	2025-12-25 00:01:07.517759	\N	\N	0	\N	\N	\N	2025-12-25 00:01:07.517759
104	019b52eb-34fc-7ffe-b776-7f33e84205df	2025-12-25 00:31:55.982082	\N	\N	0	\N	\N	\N	2025-12-25 00:31:55.982082
114	019b5300-9803-788d-9ebd-cef734762971	2025-12-25 00:55:16.951632	\N	\N	0	\N	\N	\N	2025-12-25 00:55:16.951632
130	019b5404-1356-700d-bafc-41e033084605	2025-12-25 05:38:45.08837	\N	\N	0	\N	\N	\N	2025-12-25 05:38:45.08837
146	019b54a7-f700-7556-be72-081dabb1f470	2025-12-25 08:37:46.676844	\N	\N	0	\N	\N	\N	2025-12-25 08:37:46.676844
154	019b54b4-5740-7aa4-a1bc-6da4b7ad9078	2025-12-25 08:51:12.91834	\N	\N	0	\N	\N	\N	2025-12-25 08:51:12.91834
160	019b555b-054a-7559-8247-fbb0034b1bd2	2025-12-25 11:53:15.601918	\N	\N	0	\N	\N	\N	2025-12-25 11:53:15.601918
162	019b555b-e6f0-7662-bf5f-03b2a16b25dd	2025-12-25 11:54:14.104874	\N	\N	0	\N	\N	\N	2025-12-25 11:54:14.104874
168	019b556b-e9b9-7449-99a7-837a4b619104	2025-12-25 12:11:44.363737	\N	\N	0	\N	\N	\N	2025-12-25 12:11:44.363737
170	019b556e-5a05-7ccb-9f50-14ceb7da304b	2025-12-25 12:14:22.729475	\N	\N	0	\N	\N	\N	2025-12-25 12:14:22.729475
172	019b5570-a903-7dd0-a6a8-58a424acba90	2025-12-25 12:16:54.012831	\N	\N	0	\N	\N	\N	2025-12-25 12:16:54.012831
174	019b5870-56e7-7669-9844-13f792c42939	2025-12-26 02:15:32.889969	\N	\N	0	\N	\N	\N	2025-12-26 02:15:32.889969
184	019b5872-e23b-722a-992d-b7bc253302b1	2025-12-26 02:18:20.689324	\N	\N	0	\N	\N	\N	2025-12-26 02:18:20.689324
186	019b5899-0572-7aad-8c82-ef0f6755d49d	2025-12-26 02:59:51.343846	\N	\N	0	\N	\N	\N	2025-12-26 02:59:51.343846
190	019b58a3-3c26-7eed-8199-1d333505445b	2025-12-26 03:11:05.089155	\N	\N	0	\N	\N	\N	2025-12-26 03:11:05.089155
196	test-call-123	2025-12-26 03:26:13.546032	\N	\N	0	\N	\N	\N	2025-12-26 03:26:13.546032
198	019b5940-1577-7994-b6f8-e2f18363037b	2025-12-26 06:02:20.323717	\N	\N	0	\N	\N	\N	2025-12-26 06:02:20.323717
202	019b5941-73e0-7339-9182-bfa6dad8cb75	2025-12-26 06:03:48.386218	\N	\N	0	\N	\N	\N	2025-12-26 06:03:48.386218
208	019b5949-4eeb-7aae-860e-f38001928b5b	2025-12-26 06:12:23.8065	\N	\N	0	\N	\N	\N	2025-12-26 06:12:23.8065
216	019b59c1-f33a-7775-aeb2-96539d86858b	2025-12-26 08:24:11.291438	\N	\N	0	\N	\N	\N	2025-12-26 08:24:11.291438
226	019b5cbd-c2ea-7008-a603-81498254b300	2025-12-26 22:18:26.644537	\N	\N	0	\N	\N	\N	2025-12-26 22:18:26.644537
284	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	2025-12-26 22:29:19.763908	\N	\N	0	\N	\N	\N	2025-12-26 22:29:19.763908
318	019b5d53-e0a6-788a-a0e7-c46aaadff876	2025-12-27 01:02:31.221092	\N	\N	0	\N	\N	\N	2025-12-27 01:02:31.221092
\.


--
-- Data for Name: voice_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.voice_messages (id, call_id, turn_number, role, content, readiness_score, readiness_recommendation, "timestamp", latency_ms, call_ended, closure_type, sources) FROM stdin;
1	019b4f4a-e58a-766e-9be8-3520eb637708	1	user	Hi. How are you?	0.01	explore	2025-12-24 07:37:58.522451	\N	f	\N	\N
2	019b4f4a-e58a-766e-9be8-3520eb637708	2	user	Hi. How are you? Hi. How are you?	0	explore	2025-12-24 07:38:06.769218	\N	f	\N	\N
3	019b4f4a-e58a-766e-9be8-3520eb637708	2	assistant	I appreciate your greeting! Im here and ready to support you. How are you feeling today?	\N	\N	2025-12-24 07:38:17.610367	\N	f	\N	\N
4	019b4f4a-e58a-766e-9be8-3520eb637708	2	assistant	I appreciate you asking, and I'm here to support you! I hear you might have something on your mind today. Would you like to share what's been going on?	\N	\N	2025-12-24 07:38:19.031393	\N	f	\N	\N
5	019b4f4a-e58a-766e-9be8-3520eb637708	3	user	Hi. How are you? Hi. How are you? Hi.	0	explore	2025-12-24 07:38:20.519827	\N	f	\N	\N
6	019b4f4a-e58a-766e-9be8-3520eb637708	3	assistant	It sounds like you might be feeling a little overwhelmed or perhaps just testing the waters here. I hear you, and Im here for you. Would you like to talk about whats on your mind?	\N	\N	2025-12-24 07:38:23.385647	\N	f	\N	\N
7	019b4f4a-e58a-766e-9be8-3520eb637708	4	user	I'm struggling a lot with my relationship and I just want to have a talk with you. Maybe you, you know, you can help me out here.	0.3	transition	2025-12-24 07:38:44.202553	\N	f	\N	\N
8	019b4f4a-e58a-766e-9be8-3520eb637708	4	assistant	I hear you, and it sounds like you're carrying a heavy load with your relationship struggles . Thank you for trusting me with this. What do you think might help you as you navigate this? Would you feel comfortable sharing a bit more about what's been happening?	\N	\N	2025-12-24 07:38:47.654577	\N	f	\N	\N
9	019b4f4a-e58a-766e-9be8-3520eb637708	5	user	Yes. Why not?	0.05	explore	2025-12-24 07:39:03.075847	\N	f	\N	\N
10	019b4f4a-e58a-766e-9be8-3520eb637708	5	assistant	Thank you for being open to sharing. That willingness can make a difference. I'm curious can you tell me what specific challenges you're facing in your relationship? What seems to be the core issue for you right now?	\N	\N	2025-12-24 07:39:06.300932	\N	f	\N	\N
11	019b4f4a-e58a-766e-9be8-3520eb637708	6	user	Yes. Why not? Lately, I feel that, um, my girlfriend is not spending too much of time with me. She's trying to avoid me. This might be just my feelings because she is completely denying this fact, but this is what I'm feeling. And I... I'm not sure how to confront her, uh, about my... these feelings exactly.	0.27	transition	2025-12-24 07:39:27.220065	\N	f	\N	\N
12	019b4f4a-e58a-766e-9be8-3520eb637708	6	assistant	I can sense how confusing and painful this situation must be for you . Feeling like someone you're close to is pulling away can be really unsettling. Thank you for sharing your feelings with me. I'm curious, what have you noticed about this shift in your relationship? And have there been any specific moments that stood out to you when you felt particularly distant from her?	\N	\N	2025-12-24 07:39:30.948449	\N	f	\N	\N
13	019b4f4a-e58a-766e-9be8-3520eb637708	7	user	Yes. There are many moments. Uh, I cannot pinpoint, but there are many moments, like, you know, when I wanted her to come to meet me, uh, to spend more time. Uh, again, this might be just my thinking. I might be wrong, but I feel that earlier, she was more available to me, uh, as compared to what I am feeling now. Now I feel that I have to kind of force myself to her to an extent, asking her, you know, let's meet. We need to spend some more time. You know, all these things, uh, I'm feeling right now.	0.34	transition	2025-12-24 07:40:35.494515	\N	f	\N	\N
14	019b4f4a-e58a-766e-9be8-3520eb637708	7	assistant	It sounds like you're navigating a lot of uncertainty and perhaps a sense of longing for the connection you once had. That feeling of having to push for time together can be really frustrating and lonely. I appreciate you opening up about those moments. Sometimes, these feelings can reflect deeper concerns or patterns.	\N	\N	2025-12-24 07:40:40.584438	\N	f	\N	\N
15	019b4f4a-e58a-766e-9be8-3520eb637708	8	user	Yes. That's what I was... I'm struggling with, and that is where I just wanted to have a conversation with you. Maybe you can suggest something. Or do you think that I need to change something to figure out this situation, any suggestions you have? What what do you think I can do to analyze the situation and try to figure out what is going on?	0.59	guide	2025-12-24 07:41:22.947121	\N	f	\N	\N
16	019b4f4a-e58a-766e-9be8-3520eb637708	8	assistant	Thank you for sharing that with me. Based on what you've described, here are some perspectives that might resonate First, it might be helpful to gently explore your own feelings without judgment. Taking some time to reflect on why you feel that need for connection right now can help clarify your emotions. Ask yourself What do you truly need from this relationship at this moment? Second, I sense that approaching your girlfriend with an open mindset could be beneficial.	\N	\N	2025-12-24 07:41:28.437963	\N	f	\N	\N
17	019b4f4a-e58a-766e-9be8-3520eb637708	9	user	Okay. Uh, what exactly I want? Nothing. I am just want to spend some more time. I feel that the relationship... I feel that we are not spending more time together as we used to. Maybe it's something that, uh, you know, the the relationship has ran out of its course. I don't know. I'm not able to figure it out, but my expectations are simple. Uh, spend some more time as we used to. Uh, that is what... that is something not happening these days, and I'm not able to figure out why, or is it something that I need to change within myself to be able to make her realize that this is what I'm missing? Something that you can guide me?	0.76	guide	2025-12-24 07:42:45.690169	\N	f	\N	\N
18	019b4f4a-e58a-766e-9be8-3520eb637708	9	assistant	It sounds like you're feeling a deep sense of loss and longing for the connection you once shared. Thank you for opening up about these feelings. Here are some insights to consider First, what do you think about allowing yourself to express what you truly need without the fear of being misunderstood? Sometimes, simply sharing your feelings can open the door to more honest communication with your girlfriend. Second, reflecting on your own needs and values in the relationship can be very insightful.	\N	\N	2025-12-24 07:42:53.933861	\N	f	\N	\N
19	019b4f4a-e58a-766e-9be8-3520eb637708	10	user	Okay. So is it something you would suggest you want me to do? Uh, what do you suggest I do?	0.165	explore	2025-12-24 07:43:28.861591	\N	f	\N	\N
20	019b4f4a-e58a-766e-9be8-3520eb637708	10	assistant	I appreciate your willingness to explore this further. Given what's been shared, here are a couple of perspectives to consider First, start by having an open dialogue with your girlfriend. Share your feelings honestly express that you miss the time spent together and how important that connection is to you. It's about creating a safe space for both of you to share how you feel.	\N	\N	2025-12-24 07:43:34.411052	\N	f	\N	\N
21	019b4f4a-e58a-766e-9be8-3520eb637708	11	user	Okay. I will do that. In fact, I've already done that, and she says that... she gives me certain reasons which are valid reasons, like, you know, we have been together for five years now, and it's, uh, you know, it's not necessary that we spend every second together and things like that, which is which is okay. I understand that. But, uh, but still I do miss, uh, spending more time with her. So I don't know how to answer to her because what she says seems logically correct, but then I still miss her company.	0.48	guide	2025-12-24 07:44:33.977998	\N	f	\N	\N
122	019b52eb-34fc-7ffe-b776-7f33e84205df	2	assistant	I appreciate you asking! Im here to support you. How are you feeling today?	\N	\N	2025-12-25 00:32:08.321616	12896	f	\N	\N
22	019b4f4a-e58a-766e-9be8-3520eb637708	12	user	Okay. I will do that. In fact, I've already done that, and she says that... she gives me certain reasons which are valid reasons, like, you know, we have been together for five years now, and it's, uh, you know, it's not necessary that we spend every second together and things like that, which is which is okay. I understand that. But, uh, but still I do miss, uh, spending more time with her. So I don't know how to answer to her because what she says seems logically correct, but then I still miss her company. do I do?	0.48	guide	2025-12-24 07:44:35.031352	\N	f	\N	\N
23	019b4f4a-e58a-766e-9be8-3520eb637708	12	assistant	Thank you for sharing that deeper layer of your experience. It can be really challenging when our emotional needs feel at odds with someone else's logical reasons. I sense that youve already started a healthy conversation, which is a great step. What do you think might help in expressing your feelings while acknowledging her points too? You could say something like, "I understand where youre coming from, and I agree that we don't need to be together all the time, but I still feel a need for more connection with you." This way, you're validating her feelings while also being honest about yours.	\N	\N	2025-12-24 07:44:38.174901	\N	f	\N	\N
24	019b4f4a-e58a-766e-9be8-3520eb637708	12	assistant	Thank you for sharing that, and its completely understandable to feel this way. It sounds like youre juggling your feelings with her perspective, which can be challenging. Here are some thoughts to consider First, what do you think about expressing to her how her reasons resonate with you while also sharing that your feelings are valid? You might say something like I understand that we cant be together all the time, but I really value our time together and miss that closeness. Second, exploring ways to create meaningful moments together, even if they are less frequent, could help both of you feel more connected.	\N	\N	2025-12-24 07:44:38.930078	\N	f	\N	\N
25	019b4f4a-e58a-766e-9be8-3520eb637708	13	user	These are good suggestions. I will try that out. Do you think something more Shweta ma'am can help me? Because after all, you are the assistant for Shweta ma'am. So do you think that after your call, I should contact her and she might be able to help me more?	0.63	guide	2025-12-24 07:45:33.394936	\N	f	\N	\N
26	019b4f4a-e58a-766e-9be8-3520eb637708	13	assistant	I'm glad to hear you found the suggestions helpful! Absolutely, working directly with Shweta can provide deeper insights and personalized support tailored to your situation. She can help you explore the underlying emotions and patterns that might be influencing your relationship dynamics. If you're open to it, what do you think might help you in reaching out for a session with her? Would you like information on how to connect with Shweta for further assistance?	\N	\N	2025-12-24 07:45:37.237824	\N	f	\N	\N
27	019b4f4a-e58a-766e-9be8-3520eb637708	14	user	Yes. Can you give some information how to connect with her?	0.08	explore	2025-12-24 07:46:05.974564	\N	f	\N	\N
28	019b4f4a-e58a-766e-9be8-3520eb637708	14	assistant	Certainly! You can connect with Shweta for a one-on-one session to explore your situation more deeply. She offers a complimentary Discovery Call where you can discuss your challenges and see how her coaching can support you moving forward. You can book that call by following this link I sense that this opportunity could provide you with the guidance and support you're looking for! If you have any more questions or need anything else, feel free to ask.	\N	\N	2025-12-24 07:46:10.580177	\N	f	\N	\N
29	019b4f4a-e58a-766e-9be8-3520eb637708	15	user	I know. That would be all. Thank you so much. I will connect her with that particular link, and it... you were a really good help. And thank you for talking to me, and have a nice day.	0.08	explore	2025-12-24 07:46:48.740382	\N	f	\N	\N
30	019b4f4a-e58a-766e-9be8-3520eb637708	15	assistant	You're very welcome! I'm glad I could support you today, and I appreciate your openness in sharing your feelings. It sounds like connecting with Shweta and navigating this situation is important to you. Wishing you all the best! Have a wonderful day!	\N	\N	2025-12-24 07:46:52.330518	\N	f	\N	\N
82	custom-llm-91385546	1	user	I am feeling anxious about my future	0	explore	2025-12-24 22:51:14.818955	\N	f	\N	\N
83	custom-llm-91385546	1	assistant	I hear you, and that feeling of anxiety about the future can be really overwhelming . Thank you for sharing this with me. What do you think might help you explore what's been causing this anxiety?	\N	\N	2025-12-24 22:51:15.375282	2977	f	\N	\N
84	custom-llm--8880117	1	user	Hello, I am having a tough day	0	explore	2025-12-24 22:59:08.109121	\N	f	\N	\N
85	custom-llm--8880117	1	assistant	I hear you, and that sounds really challenging. Tough days can feel overwhelming and heavy to carry. Would you feel comfortable sharing a bit more about what's making today tough for you?	\N	\N	2025-12-24 22:59:10.05308	2407	f	\N	\N
86	custom-llm--7203238	1	user	test message	0.03	explore	2025-12-24 23:13:13.577846	\N	f	\N	\N
87	custom-llm--7203238	1	assistant	I hear you, and I can sense you might be feeling curious about this space . What do you think might help you share whats on your mind?	\N	\N	2025-12-24 23:13:15.918091	2725	f	\N	\N
88	019b52ae-6e42-733e-8f7b-d69096c6dfec	1	user	Hi. How are you?	0.01	explore	2025-12-24 23:25:32.50362	\N	f	\N	\N
89	019b52ae-6e42-733e-8f7b-d69096c6dfec	2	user	Hi. How are you? Hi. How are you?	0	explore	2025-12-24 23:25:48.73546	\N	f	\N	\N
90	019b52ae-6e42-733e-8f7b-d69096c6dfec	2	assistant	I hear you, and it sounds like you've reached out for a connection. I'm here, and I hope you're having a moment of peace today. What would you like to share that's on your mind?	\N	\N	2025-12-24 23:25:57.588426	8864	f	\N	\N
91	019b52ae-6e42-733e-8f7b-d69096c6dfec	3	user	Hi. How are you? Hi. How are you? Can you hear me?	0	explore	2025-12-24 23:25:58.846959	\N	f	\N	\N
92	019b52ae-6e42-733e-8f7b-d69096c6dfec	3	assistant	I can sense that you might be feeling a bit uncertain or perhaps seeking reassurance. Yes, I can hear you, and Im here to listen. What do you think might help you share whats been going on for you today?	\N	\N	2025-12-24 23:26:01.670309	2815	f	\N	\N
93	019b52ae-6e42-733e-8f7b-d69096c6dfec	3	assistant	I hear you reaching out and I'm here to connect with you . Thank you for asking! How are you feeling today? Whats on your mind that youd like to share?	\N	\N	2025-12-24 23:26:18.832852	46853	f	\N	\N
94	019b52ae-6e42-733e-8f7b-d69096c6dfec	4	user	Well, today I want to discuss about my health.	0	explore	2025-12-24 23:26:19.452451	\N	f	\N	\N
95	019b52ae-6e42-733e-8f7b-d69096c6dfec	4	assistant	I can sense that health can be such a significant and sometimes overwhelming topic to navigate . What has been going on with your health that you would feel comfortable sharing?	\N	\N	2025-12-24 23:26:22.01478	2566	f	\N	\N
96	019b52ae-6e42-733e-8f7b-d69096c6dfec	5	user	Well, today I want to discuss about my health. Uh, it's been good almost, um, for the past, like, ten, fifteen years, but lately, I have crossed, like, fifty five years of age, and, uh, I face certain issues regarding my health, and that has really scared me a lot. And I don't know. Maybe I'm being a bit paranoid here, but, uh, these feelings are very strong because I'm too scared. This is the first time I have faced, uh, some health issues which I did not expect. So I just wanted to have a talk with you. ,	0.3	transition	2025-12-24 23:26:57.61008	\N	f	\N	\N
97	019b52ae-6e42-733e-8f7b-d69096c6dfec	5	assistant	I hear you, and it sounds like you're carrying a lot of fear and uncertainty around these health changes, especially after having good health for a while. That must feel heavy to carry, especially when facing unexpected issues. Would you feel comfortable sharing more about the specific health challenges you're experiencing?	\N	\N	2025-12-24 23:27:00.459834	2889	f	\N	\N
98	019b52ae-6e42-733e-8f7b-d69096c6dfec	6	user	Yes. Recently, I had a small pain. Uh, it was detected as angina, and, uh, I had got it diagnosed. And doctor told me that, uh, you know, your cholesterol level has increased. And even though I maintain a very good diet, but still I never expected that my cholesterol level will increase. So for that, uh, yes, certain precautions are being advised. But, uh, psychologically, I... this has landed me into a very scared situation, and I am very fearful. Like, mentally, I'm not able to handle this situation. That's why I wanted to have a talk with you.	0.02	explore	2025-12-24 23:28:09.371326	\N	f	\N	\N
99	019b52ae-6e42-733e-8f7b-d69096c6dfec	6	assistant	Thank you for sharing that with me. It sounds incredibly challenging to navigate the fear and anxiety that comes with a diagnosis like angina, especially when you've worked hard to maintain a healthy lifestyle. It's completely understandable to feel scared in this situation. I'm curious what has been your experience with fear and anxiety about your health? And has there been a moment or thought that stands out when you reflect on your feelings regarding this situation?	\N	\N	2025-12-24 23:28:12.439882	3095	f	\N	\N
100	019b52ae-6e42-733e-8f7b-d69096c6dfec	7	user	I don't know. But can you, uh, give me certain steps to deal with this, uh, emotional and psychological issue that I'm facing?	0.525	guide	2025-12-24 23:28:49.506984	\N	f	\N	\N
101	019b52ae-6e42-733e-8f7b-d69096c6dfec	7	assistant	Thank you for sharing that with me. Based on what you've described, here are some perspectives that might resonate First, I hear you in acknowledging the emotions you're experiencing. Fear and anxiety can often come from feeling a lack of control. Taking the time to understand these emotions might help you connect with what's truly at the root of your anxiety.	\N	\N	2025-12-24 23:28:53.361864	3880	f	\N	\N
102	019b52ae-6e42-733e-8f7b-d69096c6dfec	8	user	I don't know. But can you, uh, give me certain steps to deal with this, uh, emotional and psychological issue that I'm facing? Uh, right now, I have to go somewhere. So I have to end the call, but I wanted you... I want you to give me certain, um, steps where I... which I can follow to fight this, um, emotional challenge.	0.792	guide	2025-12-24 23:29:04.357969	\N	f	\N	\N
103	019b52ae-6e42-733e-8f7b-d69096c6dfec	8	assistant	It was wonderful talking with you today. I'm glad I could be here for you. Take care of yourself, and remember, you can always come back whenever you need support. Goodbye!	\N	\N	2025-12-24 23:29:04.966198	616	f	strong_goodbye	\N
104	custom-llm-89039404	1	user	I need to go now, but can you give me some steps to deal with my anxiety?	0.3	transition	2025-12-24 23:47:26.354714	\N	f	\N	\N
105	custom-llm-89039404	1	assistant	Thank you for sharing that with me. Based on what you've described, here are some perspectives that might resonate First, I hear youyour anxiety is a response to what's happening around you. Take a moment to close your eyes, breathe deeply, and think about something you truly enjoy doing. This could be anything from painting to cookingwhere you feel light and energized without resistance.	\N	\N	2025-12-24 23:47:30.33826	4412	f	\N	\N
106	019b52cf-0355-7cc0-a3e9-8cc659f384cc	1	user	Hi. How are you?	0.01	explore	2025-12-25 00:01:07.517759	\N	f	\N	\N
107	019b52cf-0355-7cc0-a3e9-8cc659f384cc	2	user	Hi. How are you? Hi. How are you?	0	explore	2025-12-25 00:01:20.131501	\N	f	\N	\N
108	019b52cf-0355-7cc0-a3e9-8cc659f384cc	2	assistant	I hear you reaching out, and I'm here for you . It's wonderful to connect. What do you think might help you today?	\N	\N	2025-12-25 00:01:23.090044	2967	f	\N	\N
109	019b52cf-0355-7cc0-a3e9-8cc659f384cc	2	assistant	I appreciate you asking! Im here to support you. How are you doing today? If theres something on your mind, I sense Im all ears.	\N	\N	2025-12-25 00:01:23.716625	16722	f	\N	\N
110	019b52cf-0355-7cc0-a3e9-8cc659f384cc	3	user	Hi. How are you? Hi. How are you? Can you hear me	0	explore	2025-12-25 00:01:24.351825	\N	f	\N	\N
111	019b52cf-0355-7cc0-a3e9-8cc659f384cc	3	assistant	I hear you, and I can feel your eagerness to connect . I'm here, and I'm ready to listen. What would you like to share that's on your mind today?	\N	\N	2025-12-25 00:01:26.90083	2544	f	\N	\N
112	019b52cf-0355-7cc0-a3e9-8cc659f384cc	4	user	I'm feeling very lonely these days, I don't know what has happened, everything is okay, I'm doing good in my job, family is fine, everybody is happy but for some reason I started feeling this loneliness, I don't know what to do.	0.35	guide	2025-12-25 00:01:54.705561	\N	f	\N	\N
113	019b52cf-0355-7cc0-a3e9-8cc659f384cc	4	assistant	That must feel so heavy to carry feeling lonely even when things seem fine on the surface. It's completely understandable to have moments like this, even when everything appears to be going well. What do you think might help you explore when you first began noticing this feeling of loneliness?	\N	\N	2025-12-25 00:01:58.080376	3427	f	\N	\N
114	019b52cf-0355-7cc0-a3e9-8cc659f384cc	5	user	I have no idea. That's a very good question. I hope I can answer you. I seriously am not able to understand why I am feeling like this. That is the reason I thought to have a talk with you. Maybe you can suggest something.	0.52	guide	2025-12-25 00:02:28.042471	\N	f	\N	\N
115	019b52cf-0355-7cc0-a3e9-8cc659f384cc	5	assistant	I can sense how much this is weighing on you, and its completely okay not to have all the answers right away. It sounds like youre searching for clarity in this difficult feeling. Would you be comfortable sharing if there have been any recent changes or moments that made you feel more disconnected? Sometimes, talking through it can reveal insights.	\N	\N	2025-12-25 00:02:31.621027	3613	f	\N	\N
116	019b52cf-0355-7cc0-a3e9-8cc659f384cc	6	user	I don't know. I do not have an answer. I seriously do not have an answer. What could be those moments? Maybe you can suggest or give me certain steps that I can... I should go through in order to bring you better answers.	0.77	guide	2025-12-25 00:03:08.976247	\N	f	\N	\N
117	019b52cf-0355-7cc0-a3e9-8cc659f384cc	6	assistant	I'm so glad we could have this conversation. Before we wrap up, is there anything else on your mind you'd like to explore? If not, I wish you all the best on your journey.	\N	\N	2025-12-25 00:03:09.59522	654	f	soft_closure	\N
118	019b52cf-0355-7cc0-a3e9-8cc659f384cc	7	user	No, I never asked you to end the call.	0.04	explore	2025-12-25 00:03:24.625135	\N	f	\N	\N
119	019b52cf-0355-7cc0-a3e9-8cc659f384cc	7	assistant	It was wonderful talking with you today. I'm glad I could be here for you. Take care of yourself, and remember, you can always come back whenever you need support. Goodbye!	\N	\N	2025-12-25 00:03:25.252058	618	f	strong_goodbye	\N
120	019b52eb-34fc-7ffe-b776-7f33e84205df	1	user	Hi. How are you?	0.01	explore	2025-12-25 00:31:55.982082	\N	f	\N	\N
121	019b52eb-34fc-7ffe-b776-7f33e84205df	2	user	Hi. How are you? Hi. How are you?	0	explore	2025-12-25 00:32:05.595225	\N	f	\N	\N
123	019b52eb-34fc-7ffe-b776-7f33e84205df	2	assistant	I appreciate you asking, and I'm here for you! It sounds like you might have something on your mind. What do you think might help you share what's been going on for you?	\N	\N	2025-12-25 00:32:09.169706	3599	f	\N	\N
124	019b52eb-34fc-7ffe-b776-7f33e84205df	3	user	I feel lonely.	0.03	explore	2025-12-25 00:32:20.82479	\N	f	\N	\N
125	019b52eb-34fc-7ffe-b776-7f33e84205df	3	assistant	I hear you, and that feeling of loneliness can be really heavy to carry . Thank you for trusting me with that. What do you think might help in exploring whats been contributing to your feelings of loneliness?	\N	\N	2025-12-25 00:32:24.077156	3272	f	\N	\N
126	019b52eb-34fc-7ffe-b776-7f33e84205df	4	user	I'm not sure, but recently I feel lonely and I just wanted to have a talk with you.	0	explore	2025-12-25 00:32:41.806855	\N	f	\N	\N
127	019b52eb-34fc-7ffe-b776-7f33e84205df	4	assistant	Its completely understandable to want to talk it through, especially when feeling lonely. I hear you that sense of disconnection can be tough. Would you feel comfortable sharing a bit more about when you first started noticing these feelings? What moments stand out to you?	\N	\N	2025-12-25 00:32:45.24062	3464	f	\N	\N
128	019b52eb-34fc-7ffe-b776-7f33e84205df	5	user	No. I don't have a specific moment. Okay. Wait. My mom is calling. I have to go.	0.32	transition	2025-12-25 00:33:07.538825	\N	f	\N	\N
129	019b52eb-34fc-7ffe-b776-7f33e84205df	5	assistant	I completely understand family calls can be important. Whenever you're ready to talk more, just reach out. Take care, and I sense I'll be here for you.	\N	\N	2025-12-25 00:33:10.266089	2718	f	\N	\N
130	019b5300-9803-788d-9ebd-cef734762971	1	user	Hi. How are you?	0.01	explore	2025-12-25 00:55:16.951632	\N	f	\N	\N
131	019b5300-9803-788d-9ebd-cef734762971	2	user	Hi. How are you? Hi. How are you?	0	explore	2025-12-25 00:55:29.240976	\N	f	\N	\N
132	019b5300-9803-788d-9ebd-cef734762971	3	user	Hi. How are you? Hi. How are you? Can you hear me?	0	explore	2025-12-25 00:55:30.456066	\N	f	\N	\N
133	019b5300-9803-788d-9ebd-cef734762971	3	assistant	I appreciate you asking! I'm here to support you on your journey. It sounds like you're reaching out for connection. How are you feeling today?	\N	\N	2025-12-25 00:55:32.944194	16020	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
134	019b5300-9803-788d-9ebd-cef734762971	3	assistant	Im here and ready to support you! I hear you. How are you feeling today?	\N	\N	2025-12-25 00:55:33.578534	4350	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}]
135	019b5300-9803-788d-9ebd-cef734762971	3	assistant	I hear you, and its great to connect with you! It can feel comforting just to reach out and speak with someone. How are you feeling today? Whats on your mind?	\N	\N	2025-12-25 00:55:34.799396	4334	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "Career Healing - Elevate 360 Session 1", "topic": "career", "youtube_url": null}]
136	019b5300-9803-788d-9ebd-cef734762971	4	user	Thank you for asking. I feel listed that I'm not being appreciated too much.	0.15	explore	2025-12-25 00:55:52.952246	\N	f	\N	\N
137	019b5300-9803-788d-9ebd-cef734762971	5	user	Thank you for asking. I feel listed that I'm not being appreciated too much. Why is that so?	0.15	explore	2025-12-25 00:55:54.709666	\N	f	\N	\N
138	019b5300-9803-788d-9ebd-cef734762971	5	assistant	I can sense how much this situation weighs on you. Feeling unappreciated can be really tough and can affect our sense of self-worth. What do you think might help in addressing where youre feeling this lack of appreciation?	\N	\N	2025-12-25 00:55:57.934823	3225	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}]
139	019b5300-9803-788d-9ebd-cef734762971	5	assistant	I can sense how heavy that feeling of not being appreciated can be to carry. It's tough when you feel like your contributions or your efforts aren't recognized. What do you think might help in addressing this feeling? Would you feel comfortable sharing more about what's leading you to feel this way?	\N	\N	2025-12-25 00:55:58.562297	5624	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
140	019b5300-9803-788d-9ebd-cef734762971	6	user	I don't know. I'm not able to understand my own feelings, but I'm struggling, and that is the reason I came to you came to you. Maybe you will be in a better position to assist me.	0.42	guide	2025-12-25 00:56:23.426129	\N	f	\N	\N
141	019b5300-9803-788d-9ebd-cef734762971	6	assistant	I hear you, and it sounds like you're navigating some really complex emotions right now. It can be overwhelming not knowing exactly what you're feeling. Thank you for trusting me with this. Would you like to share a bit more about what specific situations or interactions have made you feel unappreciated? Sometimes those details can help illuminate what's really going on underneath.	\N	\N	2025-12-25 00:56:27.135052	3762	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}, {"source": "How to find Peace in 9-5 Job without quitting", "topic": "peace", "youtube_url": "https://youtu.be/nstljfm6rlg"}]
142	019b5300-9803-788d-9ebd-cef734762971	7	user	Uh, I don't know. Um, okay. I think, uh, this conversation needs more time. Right now, I have to go, but I will be back soon.	0.72	guide	2025-12-25 00:57:03.162966	\N	f	\N	\N
143	019b5300-9803-788d-9ebd-cef734762971	7	assistant	Of course! I hear you that sometimes these conversations take time and space. I'm here whenever you're ready to continue. Take care, and I look forward to talking with you again.	\N	\N	2025-12-25 00:57:06.406251	3279	f	somera_farewell	[{"source": "How to find Peace in 9-5 Job without quitting", "topic": "peace", "youtube_url": "https://youtu.be/nstljfm6rlg"}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
144	019b5300-9803-788d-9ebd-cef734762971	8	user	Okay. Bye bye.	0.122	explore	2025-12-25 00:57:20.510932	\N	f	\N	\N
145	019b5300-9803-788d-9ebd-cef734762971	8	assistant	Take care! We'll be here when you're ready to chat again. Bye for now!	\N	\N	2025-12-25 00:57:23.509732	2985	f	somera_farewell	[{"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
146	019b5404-1356-700d-bafc-41e033084605	1	user	Hi. How are you?	0.01	explore	2025-12-25 05:38:45.08837	\N	f	\N	\N
147	019b5404-1356-700d-bafc-41e033084605	2	user	Hi. How are you? Hi. Can you hear me?	0	explore	2025-12-25 05:38:50.142565	\N	f	\N	\N
148	019b5404-1356-700d-bafc-41e033084605	3	user	Hi. How are you? Hi. Can you hear me? Are you there?	0	explore	2025-12-25 05:38:56.158468	\N	f	\N	\N
149	019b5404-1356-700d-bafc-41e033084605	3	assistant	I hear you, and Im here for you! Thank you for reaching out. How are you feeling today? Whats on your mind?	\N	\N	2025-12-25 05:39:00.81785	4638	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
150	019b5404-1356-700d-bafc-41e033084605	3	assistant	I hear you, and Im glad you reached out! Im here to listen and support you. It sounds like you might have something on your mind. What do you think might help you share more about whats going on?	\N	\N	2025-12-25 05:39:01.426128	11291	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "Career Healing - Elevate 360 Session 1", "topic": "career", "youtube_url": null}]
151	019b5404-1356-700d-bafc-41e033084605	3	assistant	I appreciate you asking! I'm here to support you, and I hope youre doing well too. How can I assist you today?	\N	\N	2025-12-25 05:39:02.469371	19410	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
152	019b5404-1356-700d-bafc-41e033084605	4	user	I am feeling some physical pain across my shoulders and all, I don't know whether is it something psychological or I'm not able to understand. So I thought, uh, you have a question with you.	0.3	transition	2025-12-25 05:39:23.686128	\N	f	\N	\N
153	019b5404-1356-700d-bafc-41e033084605	4	assistant	I hear you, and it sounds challenging to be dealing with that physical discomfort in your shoulders. It sounds frustrating not knowing whether it's related to psychological stress or something else. Would you feel comfortable sharing a bit more about when you first started noticing this pain?	\N	\N	2025-12-25 05:39:26.717846	3017	f	\N	[{"source": "Health Healing - Elevate 360 Session 1", "topic": "wellness", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}]
154	019b5404-1356-700d-bafc-41e033084605	5	user	Yeah. I would say ten, fifteen days back, and it's consistent. I'm taking some medic... medication as well, certain painkillers, but it's not improving. So I am not sure whether it's related to some mental issues or... I don't know. I just wanted to have a talk with you.	0.3	transition	2025-12-25 05:40:05.45549	\N	f	\N	\N
155	019b5404-1356-700d-bafc-41e033084605	5	assistant	Thank you for sharing that with me. It sounds like youve been dealing with this pain for a couple of weeks now, and that can be really draining when the medication isnt helping. I hear youthere might be a lot on your mind. I'm curioushave you noticed any specific thoughts or stresses in your life around the time this pain began?	\N	\N	2025-12-25 05:40:09.090289	3650	f	\N	[{"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 1", "topic": "wellness", "youtube_url": null}]
156	019b5404-1356-700d-bafc-41e033084605	6	user	No. I don't remember any specific moment on insulin that can cause this pain. Hence, I'm a little bit confused. What do you think this might be the reason reason for this might be? What are your thoughts?	0.27	transition	2025-12-25 05:40:43.591628	\N	f	\N	\N
157	019b5404-1356-700d-bafc-41e033084605	6	assistant	I can sense how confusing and frustrating this feels, especially when you cant pinpoint a cause for your pain. It's common for physical discomfort to stem from various sources, including emotional stress, even if you're not directly aware of it. Sometimes, tension can build up in our bodies without us realizing it, often related to life's pressures or unresolved feelings. What do you think might help you explore how this pain might relate to any stressors you've experienced recently, even if they arent obvious?	\N	\N	2025-12-25 05:40:47.269661	3685	f	\N	[{"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 1", "topic": "wellness", "youtube_url": null}]
158	019b5404-1356-700d-bafc-41e033084605	7	user	Those are very good questions. I will think about it. Right now, I have to go. Uh, when I will be back, I will be back with all those answers. Right now, I have to go.	0.32	transition	2025-12-25 05:41:26.395097	\N	f	\N	\N
159	019b5404-1356-700d-bafc-41e033084605	7	assistant	I appreciate you taking the time to share what's been on your mind. It sounds like you're open to reflecting on this further, which is a great step. Please take care, and feel free to come back whenever you're ready to continue our conversation. Take care!	\N	\N	2025-12-25 05:41:30.49335	4099	f	somera_farewell	[{"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "1:1 Discovery Call - Health & Relationships", "topic": "relationship", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 1", "topic": "wellness", "youtube_url": null}]
160	019b5404-1356-700d-bafc-41e033084605	8	user	Yeah. Bye bye.	0.122	explore	2025-12-25 05:41:46.697337	\N	f	\N	\N
161	019b5404-1356-700d-bafc-41e033084605	8	assistant	Goodbye! Take care, and I'll be here whenever you feel ready to talk again.	\N	\N	2025-12-25 05:41:48.991541	2304	f	somera_farewell	[{"source": "Health Healing - Elevate 360 Session 1", "topic": "wellness", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
162	019b54a7-f700-7556-be72-081dabb1f470	1	user	I do	0.03	explore	2025-12-25 08:37:46.676844	\N	f	\N	\N
163	019b54a7-f700-7556-be72-081dabb1f470	2	user	I do Hi. How are you?	0.01	explore	2025-12-25 08:37:52.751902	\N	f	\N	\N
164	019b54a7-f700-7556-be72-081dabb1f470	3	user	I do Hi. How are you? Can you hear me?	0	explore	2025-12-25 08:37:59.369488	\N	f	\N	\N
165	019b54a7-f700-7556-be72-081dabb1f470	3	assistant	It sounds like there might be something on your mind that you'd like to share. What do you think might help you feel comfortable telling me a bit more about what you're experiencing?	\N	\N	2025-12-25 08:38:04.498479	19802	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}]
189	019b5570-a903-7dd0-a6a8-58a424acba90	1	assistant	I appreciate you asking! I'm here to support you, and I hope you're doing well. How are you feeling today?	\N	\N	2025-12-25 12:16:57.13811	3110	f	\N	[{"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
166	019b54a7-f700-7556-be72-081dabb1f470	3	assistant	I hear you, and I'm here for you! Thank you for reaching out. How are you feeling today? Whats on your mind?	\N	\N	2025-12-25 08:38:05.115464	5749	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "Career Healing - Elevate 360 Session 1", "topic": "career", "youtube_url": null}]
167	019b54a7-f700-7556-be72-081dabb1f470	3	assistant	I hear you, and its great to connect with you! Im here to support you. How are you feeling today? Whats on your mind?	\N	\N	2025-12-25 08:38:05.738388	12379	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "Career Healing - Elevate 360 Session 1", "topic": "career", "youtube_url": null}]
168	019b54a7-f700-7556-be72-081dabb1f470	4	user	Oh, I'm so sorry. I have to go. I'll call you back.	0.3	transition	2025-12-25 08:38:15.912262	\N	f	\N	\N
169	019b54a7-f700-7556-be72-081dabb1f470	4	assistant	That's perfectly okay! I appreciate you reaching out. Whenever you're ready to talk, I hear you and I'll be here to listen. Take care!	\N	\N	2025-12-25 08:38:18.38789	2470	f	somera_farewell	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
170	019b54b4-5740-7aa4-a1bc-6da4b7ad9078	1	user	Hi. How are you?	0.01	explore	2025-12-25 08:51:12.91834	\N	f	\N	\N
171	019b54b4-5740-7aa4-a1bc-6da4b7ad9078	2	user	Hi. How are you? Are you there?	0	explore	2025-12-25 08:51:23.313963	\N	f	\N	\N
172	019b54b4-5740-7aa4-a1bc-6da4b7ad9078	2	assistant	I appreciate you asking! I'm here to support you. How are you feeling today?	\N	\N	2025-12-25 08:51:25.855166	12994	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
173	019b54b4-5740-7aa4-a1bc-6da4b7ad9078	2	assistant	Im here, and thank you for checking in! I hear you, and it sounds like you might be reaching out for something specific. Whats on your mind today?	\N	\N	2025-12-25 08:51:26.466416	3166	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}]
174	019b54b4-5740-7aa4-a1bc-6da4b7ad9078	3	user	Hi. How are you? Are you there? Hello? Can you hear me?	0	explore	2025-12-25 08:51:27.426744	\N	f	\N	\N
175	019b54b4-5740-7aa4-a1bc-6da4b7ad9078	3	assistant	I hear you, and it sounds like you might be feeling a bit uncertain or frustrated thats totally understandable. Im here for you. Whats been on your mind?	\N	\N	2025-12-25 08:51:30.094303	2689	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "Career Healing - Elevate 360 Session 1", "topic": "career", "youtube_url": null}]
176	019b555b-054a-7559-8247-fbb0034b1bd2	1	user	Hi. How are you?	0.01	explore	2025-12-25 11:53:15.601918	\N	f	\N	\N
177	019b555b-054a-7559-8247-fbb0034b1bd2	1	assistant	I appreciate you asking! Im here to support you, and I'm ready to listen to whatever youd like to share. It sounds like you have something on your mind. How are you feeling today?	\N	\N	2025-12-25 11:53:33.747037	18049	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
178	019b555b-e6f0-7662-bf5f-03b2a16b25dd	1	user	Hi. How are you?	0.01	explore	2025-12-25 11:54:14.104874	\N	f	\N	\N
179	019b555b-e6f0-7662-bf5f-03b2a16b25dd	1	assistant	I appreciate you asking, and I'm here to support you as best I can . I hear you. What's been on your mind lately?	\N	\N	2025-12-25 11:54:18.196688	4102	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
180	019b555b-e6f0-7662-bf5f-03b2a16b25dd	2	user	Nothing. I just want to talk to you.	0	explore	2025-12-25 11:54:29.742244	\N	f	\N	\N
181	019b555b-e6f0-7662-bf5f-03b2a16b25dd	2	assistant	Im glad youre here and open to talking. It can be so nice to have a space to share. I hear youwhats been on your mind lately? Is there anything specific you'd like to discuss, or maybe something youve been feeling?	\N	\N	2025-12-25 11:54:32.288483	2542	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Career Healing - Elevate 360 Session 1", "topic": "career", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
182	019b555b-e6f0-7662-bf5f-03b2a16b25dd	3	user	No. I just want to go. I'll talk to you later. Bye bye.	0.052	explore	2025-12-25 11:54:47.995273	\N	f	\N	\N
183	019b555b-e6f0-7662-bf5f-03b2a16b25dd	3	assistant	I understand sometimes its just not the right time to share. I hear you, and please know that Im here whenever you feel ready to talk. Take care, and Ill be here when you come back!	\N	\N	2025-12-25 11:54:50.59595	2626	f	somera_farewell	[{"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}]
184	019b556b-e9b9-7449-99a7-837a4b619104	1	user	Hi. How are you?	0.01	explore	2025-12-25 12:11:44.363737	\N	f	\N	\N
185	019b556b-e9b9-7449-99a7-837a4b619104	1	assistant	I appreciate you asking! Im here to support you, and I sense youre doing well. How can I assist you today?	\N	\N	2025-12-25 12:11:57.809003	13462	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
186	019b556e-5a05-7ccb-9f50-14ceb7da304b	1	user	Hi.	0.03	explore	2025-12-25 12:14:22.729475	\N	f	\N	\N
187	019b556e-5a05-7ccb-9f50-14ceb7da304b	1	assistant	I hear you reaching out, and Im here to listen. Whats on your mind today? It sounds like you might want to share a bit more about what you're feeling.	\N	\N	2025-12-25 12:14:25.277535	2584	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Career Healing - Elevate 360 Session 1", "topic": "career", "youtube_url": null}, {"source": "Relationship Healing Course Session 1", "topic": "relationship", "youtube_url": null}]
188	019b5570-a903-7dd0-a6a8-58a424acba90	1	user	How are you?	0.03	explore	2025-12-25 12:16:54.012831	\N	f	\N	\N
190	019b5870-56e7-7669-9844-13f792c42939	1	user	Hey, tomato.	0.03	explore	2025-12-26 02:15:32.889969	\N	f	\N	\N
191	019b5870-56e7-7669-9844-13f792c42939	2	user	Hey, tomato. What to do with the body pain?	0	explore	2025-12-26 02:15:36.11111	\N	f	\N	\N
192	019b5870-56e7-7669-9844-13f792c42939	3	user	Hey, tomato. What to do with the body pain? I'm very tired.	0	explore	2025-12-26 02:15:37.520761	\N	f	\N	\N
193	019b5870-56e7-7669-9844-13f792c42939	3	assistant	I hear you, and it sounds like there's something on your mind . What do you think you would like to share today?	\N	\N	2025-12-26 02:15:40.144222	7271	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Relationship Healing Course Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}]
194	019b5870-56e7-7669-9844-13f792c42939	3	assistant	I hear you, and I'm sensing how frustrating it must be to deal with body pain. It can be really overwhelming. Would you feel comfortable sharing more about where you're experiencing the pain and what you think might help?	\N	\N	2025-12-26 02:15:40.77396	4653	f	\N	[{"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 1", "topic": "wellness", "youtube_url": null}]
195	019b5870-56e7-7669-9844-13f792c42939	3	assistant	I hear you, and I can sense how heavy that must be to carry. Body pain and fatigue can be incredibly demanding and frustrating . Would you feel comfortable sharing a bit more about what you're experiencing? What do you think might help with this pain and tiredness?	\N	\N	2025-12-26 02:15:43.602514	6069	f	\N	[{"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}]
196	019b5870-56e7-7669-9844-13f792c42939	4	user	Can you give me a healing	0.01	explore	2025-12-26 02:16:00.356566	\N	f	\N	\N
197	019b5870-56e7-7669-9844-13f792c42939	4	assistant	I truly appreciate your openness. While Im here to listen and support you, I've learned that healing is something our coach, Shweta, specializes in during one-on-one sessions. I sense you might be looking for deeper support. If you're open to it, I could share some thoughts about how to connect with your body and understand what its telling you.	\N	\N	2025-12-26 02:16:03.857154	3465	f	\N	[{"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Career - Money Manifestation", "topic": "career", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
198	019b5870-56e7-7669-9844-13f792c42939	5	user	Yeah. Go ahead.	0.01	explore	2025-12-26 02:16:22.892568	\N	f	\N	\N
199	019b5870-56e7-7669-9844-13f792c42939	5	assistant	Thank you for trusting me with this. One approach to connect with your body is through visualization and deep relaxation. Close your eyes, take a few deep breaths in and out, and allow your body to relax. As you breathe deeply, ask yourself "What does my body need from me right now? What message does it have for me?" Listening to your body in this way can help you gain clarity about what it's trying to communicate.	\N	\N	2025-12-26 02:16:27.105955	4213	f	\N	[{"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}]
200	019b5872-e23b-722a-992d-b7bc253302b1	1	user	How to cure my backache?	0.01	explore	2025-12-26 02:18:20.689324	\N	f	\N	\N
201	019b5872-e23b-722a-992d-b7bc253302b1	1	assistant	I hear you, and it sounds like dealing with backache can be really challenging . I sense it can feel frustrating to not have a solution. Would you like to share more about what youve been experiencing with your back pain? When did it start, and are there any particular activities or emotions you notice impacting it?	\N	\N	2025-12-26 02:18:23.31744	2629	f	\N	[{"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
202	019b5899-0572-7aad-8c82-ef0f6755d49d	1	user	Hi. How are you?	0.01	explore	2025-12-26 02:59:51.343846	\N	f	\N	\N
203	019b5899-0572-7aad-8c82-ef0f6755d49d	1	assistant	I hear you reaching out, and its always nice to connect. How are you feeling today? If theres anything on your mind, Im here to listen.	\N	\N	2025-12-26 02:59:54.579659	3228	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
204	019b5899-0572-7aad-8c82-ef0f6755d49d	2	user	Uh, nothing much. Um, sorry. I have to go. I'll talk to you later.	0.3	transition	2025-12-26 03:00:08.697857	\N	f	\N	\N
205	019b5899-0572-7aad-8c82-ef0f6755d49d	2	assistant	That's completely okay! I hear you, and I'm here whenever you're ready to chat again. Take care of yourself, and I look forward to hearing from you later.	\N	\N	2025-12-26 03:00:11.344798	2682	f	somera_farewell	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Career Healing - Elevate 360 Session 1", "topic": "career", "youtube_url": null}]
206	019b58a3-3c26-7eed-8199-1d333505445b	1	user	Hi. How are you?	0.01	explore	2025-12-26 03:11:05.089155	\N	f	\N	\N
207	019b58a3-3c26-7eed-8199-1d333505445b	1	assistant	Im here and ready to support you! It sounds like you might have something on your mind that youd like to share.	\N	\N	2025-12-26 03:11:17.981968	14883	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
208	019b58a3-3c26-7eed-8199-1d333505445b	2	user	No. Uh, yes. I do have, but, uh, right now, I have to go. I will see you soon.	0.3	transition	2025-12-26 03:11:32.460648	\N	f	\N	\N
209	019b58a3-3c26-7eed-8199-1d333505445b	2	assistant	I totally understand, and I appreciate you stopping by, even just for a moment. Whenever you're ready to share, I hear you, and our team will be here to listen. Take care and see you soon!	\N	\N	2025-12-26 03:11:35.556882	3109	f	somera_farewell	[{"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}]
210	019b58a3-3c26-7eed-8199-1d333505445b	3	user	Bye bye.	0.03	explore	2025-12-26 03:11:49.459985	\N	f	\N	\N
211	019b58a3-3c26-7eed-8199-1d333505445b	3	assistant	Take care! I look forward to connecting when you return.	\N	\N	2025-12-26 03:11:52.365895	2939	f	somera_farewell	[{"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}]
212	test-call-123	1	user	Can you tell me about the Hustle program?	0	explore	2025-12-26 03:26:13.546032	\N	f	\N	\N
213	test-call-123	1	assistant	I hear you, and it's understandable to want to learn more about programs that can support your journey. While I'm not equipped with specific details about the Hustle program, I can certainly listen to your experiences and feelings regarding your career or related struggles. What do you think you are looking for in a program like that? Would you like to share a bit about what you hope to achieve?	\N	\N	2025-12-26 03:26:20.378491	6802	f	\N	[{"source": "Relationship Healing Course Session 1", "topic": "relationship", "youtube_url": null}, {"source": "1-to-1 Educational Concepts - coaching_framework", "topic": "career", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
214	019b5940-1577-7994-b6f8-e2f18363037b	1	user	Hi. How are you?	0.01	explore	2025-12-26 06:02:20.323717	\N	f	\N	\N
215	019b5940-1577-7994-b6f8-e2f18363037b	1	assistant	Im here, and I appreciate you asking! I hope youre doing well too. It sounds like there might be something on your mind that you'd like to share today.	\N	\N	2025-12-26 06:02:35.300623	15054	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
216	019b5940-1577-7994-b6f8-e2f18363037b	2	user	No. I don't have anything right now. I will get back to you. Thank you so much.	0	explore	2025-12-26 06:02:53.398869	\N	f	\N	\N
217	019b5940-1577-7994-b6f8-e2f18363037b	2	assistant	That's completely okay! I'm here whenever you're ready to talk. Take your time, and remember, your feelings and thoughts matter. Thank you for checking in!	\N	\N	2025-12-26 06:02:56.621152	3256	f	somera_farewell	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
218	019b5941-73e0-7339-9182-bfa6dad8cb75	1	user	Hi. How are you?	0.01	explore	2025-12-26 06:03:48.386218	\N	f	\N	\N
219	019b5941-73e0-7339-9182-bfa6dad8cb75	1	assistant	Im here and ready to support you! How about you? Is there something on your mind that youd like to share?	\N	\N	2025-12-26 06:03:50.698269	2329	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
220	019b5941-73e0-7339-9182-bfa6dad8cb75	2	user	Uh, yes. I'm feeling lonely these days.	0	explore	2025-12-26 06:04:01.583149	\N	f	\N	\N
221	019b5941-73e0-7339-9182-bfa6dad8cb75	2	assistant	I hear you, and that sounds really difficult to navigate. Loneliness can feel so heavy to carry, especially when it's hard to connect with those around you. What do you think might help you in this situation? Would you feel comfortable sharing a bit more about what you're experiencing?	\N	\N	2025-12-26 06:04:04.674193	3102	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}]
222	019b5941-73e0-7339-9182-bfa6dad8cb75	3	user	Not right now. Uh, let me get back to you on this. Right now, I have to go.	0.3	transition	2025-12-26 06:04:28.357597	\N	f	\N	\N
223	019b5941-73e0-7339-9182-bfa6dad8cb75	3	assistant	That's completely okay! Thank you for sharing what you did. Whenever you're ready to talk more about it, I hear you and I'll be here to listen. Take care of yourself!	\N	\N	2025-12-26 06:04:31.013185	2661	f	somera_farewell	[{"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Career Healing - Elevate 360 Session 1", "topic": "career", "youtube_url": null}]
224	019b5949-4eeb-7aae-860e-f38001928b5b	1	user	Hi. How are you?	0.01	explore	2025-12-26 06:12:23.8065	\N	f	\N	\N
225	019b5949-4eeb-7aae-860e-f38001928b5b	1	assistant	Im here and ready to listen! How about you? Whats been on your mind lately?	\N	\N	2025-12-26 06:12:25.872748	2122	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
226	019b5949-4eeb-7aae-860e-f38001928b5b	2	user	Well, I'm feeling pretty lonely these days. I don't know why.	0.3	transition	2025-12-26 06:12:35.84043	\N	f	\N	\N
227	019b5949-4eeb-7aae-860e-f38001928b5b	2	assistant	I hear you, and that sounds really tough to carry. Feeling lonely can be such a heavy and isolating experience . What do you think might help in addressing these feelings? Would you feel comfortable sharing a bit more about what's been contributing to them?	\N	\N	2025-12-26 06:12:38.967061	3133	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
228	019b5949-4eeb-7aae-860e-f38001928b5b	3	user	I have no idea, frankly speaking. Um, maybe I was hoping that I can have a talk with you and we can try to figure out what is, uh, what is this that is making or giving me these kind of feelings.	0.35	guide	2025-12-26 06:13:11.248566	\N	f	\N	\N
229	019b5949-4eeb-7aae-860e-f38001928b5b	3	assistant	Thank you for trusting me with your feelingsit takes courage to open up about loneliness. I'm here to support you in exploring this. Would you like to share more about your experience with these feelings of loneliness? Has anything specific happened recently that might have intensified it?	\N	\N	2025-12-26 06:13:14.51569	3308	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
230	019b5949-4eeb-7aae-860e-f38001928b5b	4	user	That's a good question. Okay. I have to go right now, but this conversation will continue, and I will get back to you as soon as I'm free, and we will continue from there.	0.32	transition	2025-12-26 06:13:44.322735	\N	f	\N	\N
231	019b5949-4eeb-7aae-860e-f38001928b5b	4	assistant	Absolutely, take your time. I'm here whenever you're ready to continue the conversation. I sense that you might need some space, and that's completely okay. Whenever you feel free to chat again, just know that I'm here to listen and support you.	\N	\N	2025-12-26 06:13:47.335398	3021	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
232	019b59c1-f33a-7775-aeb2-96539d86858b	1	user	Hi. How are you?	0.01	explore	2025-12-26 08:24:11.291438	\N	f	\N	\N
233	019b59c1-f33a-7775-aeb2-96539d86858b	1	assistant	I appreciate you asking! I'm here to support you, and I hope you're doing okay today. What brings you here? I sense you might have something on your mind that youd like to share.	\N	\N	2025-12-26 08:24:14.398285	3149	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
234	019b59c1-f33a-7775-aeb2-96539d86858b	2	user	I am feeling lonely these days. I don't know why.	0.3	transition	2025-12-26 08:24:28.711372	\N	f	\N	\N
235	019b59c1-f33a-7775-aeb2-96539d86858b	3	user	I am feeling lonely these days. I don't know why. Competing response.	0.3	transition	2025-12-26 08:24:31.405104	\N	f	\N	\N
236	019b59c1-f33a-7775-aeb2-96539d86858b	3	assistant	I hear you feeling lonely can be such a heavy weight to carry . It's tough to navigate those feelings, especially when the reasons aren't clear. What do you think might help you explore what you've been experiencing lately?	\N	\N	2025-12-26 08:24:32.775098	4066	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
237	019b59c1-f33a-7775-aeb2-96539d86858b	3	assistant	I hear you, and I can sense how heavy that feeling of loneliness must be for you . It can be tough to grapple with these feelings, especially when they're hard to explain. Would you feel comfortable sharing a little more about when you first started noticing this loneliness?	\N	\N	2025-12-26 08:24:34.743946	3343	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
238	019b59c1-f33a-7775-aeb2-96539d86858b	4	user	Not right now. Can you tell me you have a program named hustle?	0.02	explore	2025-12-26 08:24:55.777254	\N	f	\N	\N
239	019b59c1-f33a-7775-aeb2-96539d86858b	4	assistant	Its completely okay not to share right now. Your feelings are important, and Im here to listen whenever you feel ready. Regarding your question, I don't have information on a program named "hustle." However, if you're looking for some guidance or support regarding your feelings, I would love to help you explore that. What do you think might help you as you navigate your feelings of loneliness or any other concerns on your mind?	\N	\N	2025-12-26 08:24:59.024777	3251	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}]
240	019b59c1-f33a-7775-aeb2-96539d86858b	5	user	No. Right now, I have to go, so I'll talk to you a little later.	0.32	transition	2025-12-26 08:25:29.106031	\N	f	\N	\N
241	019b59c1-f33a-7775-aeb2-96539d86858b	5	assistant	I completely understand, and I'm here whenever you're ready to talk. Take care of yourself, and I look forward to hearing from you again.	\N	\N	2025-12-26 08:25:31.765379	2706	f	somera_farewell	[{"source": "Career Healing - Elevate 360 Session 1", "topic": "career", "youtube_url": null}, {"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}]
242	019b5cbd-c2ea-7008-a603-81498254b300	1	user	Hi, Somera.	0.03	explore	2025-12-26 22:18:26.644537	\N	f	\N	\N
243	019b5cbd-c2ea-7008-a603-81498254b300	2	user	Hi, Somera. I'm not feeling too good today.	0	explore	2025-12-26 22:18:29.131666	\N	f	\N	\N
244	019b5cbd-c2ea-7008-a603-81498254b300	2	assistant	I hear you, and it's great that you reached out today . Whats on your mind? Would you feel comfortable sharing a bit more about your experience?	\N	\N	2025-12-26 22:18:31.201838	4582	f	\N	[{"source": "1-to-1 Educational Concepts - referral_boundaries", "topic": "career", "youtube_url": null}, {"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Career Healing - Elevate 360 Session 1", "topic": "career", "youtube_url": null}]
245	019b5cbd-c2ea-7008-a603-81498254b300	2	assistant	I hear you, and I can sense how heavy that feels to carry . Thank you for sharing this with me. Would you feel comfortable sharing a bit more about whats been going on?	\N	\N	2025-12-26 22:18:32.711594	3566	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
246	019b5cbd-c2ea-7008-a603-81498254b300	3	user	I feel disconnected from everyone. I don't feel like to talk. I don't feel like to engage. Even when there are people who are happy around me, I don't feel anything even though I'm in that moment, I'm not feeling anything.	0	explore	2025-12-26 22:19:03.851823	\N	f	\N	\N
247	019b5cbd-c2ea-7008-a603-81498254b300	3	assistant	That sounds really tough feeling disconnected, especially in the presence of others, can be a very lonely experience . Its like being surrounded by people but still feeling like youre on the outside looking in. I'm curious, what do you think might help you navigate these feelings? Has there been something specific that made you notice this feeling more recently?	\N	\N	2025-12-26 22:19:07.429969	3638	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "How to find Peace in 9-5 Job without quitting", "topic": "peace", "youtube_url": "https://youtu.be/nstljfm6rlg"}]
248	019b5cbd-c2ea-7008-a603-81498254b300	4	user	Yes. I think whenever I feel like to receive, I don't receive from my partner. I feel lonely.	0	explore	2025-12-26 22:19:45.516893	\N	f	\N	\N
249	019b5cbd-c2ea-7008-a603-81498254b300	5	user	Yes. I think whenever I feel like to receive, I don't receive from my partner. I feel lonely. Maybe that's the reason.	0	explore	2025-12-26 22:19:48.404787	\N	f	\N	\N
250	019b5cbd-c2ea-7008-a603-81498254b300	5	assistant	I can sense how deeply that must weigh on you. Feeling like your needs aren't being met by someone close can create such a profound sense of loneliness. It sounds like you're craving connection and support from your partner, yet not receiving it feels incredibly isolating. When you reflect on that loneliness, do you notice any particular moments or patterns that stand out for you?	\N	\N	2025-12-26 22:19:51.154863	5614	f	\N	[{"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}]
251	019b5cbd-c2ea-7008-a603-81498254b300	5	assistant	That sounds really heavy to carry. I hear you its understandable to feel lonely when youre looking for connection and support from your partner and not receiving it. It can create a gap that feels hard to bridge. I'm wondering, when did you first start noticing this pattern in your relationship? And how does it make you feel when those moments come up?	\N	\N	2025-12-26 22:19:52.195751	3782	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}]
252	019b5cbd-c2ea-7008-a603-81498254b300	6	user	I think it was same from the day one, but now	0.125	explore	2025-12-26 22:20:19.515077	\N	f	\N	\N
253	019b5cbd-c2ea-7008-a603-81498254b300	6	assistant	It sounds like this feeling of disconnect has been present for some time, almost from the beginning of your relationship. That must add another layer of complexity to what you're experiencing. I'm curious, what do you think has changed for you recentlysomething that might have made these feelings more pronounced? What do you really want or need from your partner right now?	\N	\N	2025-12-26 22:20:23.94622	4474	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Relationship Healing Course Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}]
254	019b5cbd-c2ea-7008-a603-81498254b300	7	user	I think it was same from the day one, but now I feel it more and more. I feel I deserve better. I feel I deserve a deep emotional connection, but I don't feel it.	0.04	explore	2025-12-26 22:20:31.964516	\N	f	\N	\N
255	019b5cbd-c2ea-7008-a603-81498254b300	7	assistant	I can feel the weight of that realization for you. Recognizing that you deserve a deeper emotional connection is a powerful insight, and it makes sense that you would feel that more strongly. It sounds like you're beginning to understand your own needs better, and that's a significant step. Given that you've felt this way since the beginning, I wonder if there are moments when youve tried to express these needs to your partner or if it feels difficult to bring up.	\N	\N	2025-12-26 22:20:36.121697	4149	f	\N	[{"source": "How to find Peace in 9-5 Job without quitting", "topic": "peace", "youtube_url": "https://youtu.be/nstljfm6rlg"}]
256	019b5cbd-c2ea-7008-a603-81498254b300	8	user	I think it was same from the day one, but now I feel it more and more. I feel I deserve better. I feel I deserve a deep emotional connection, but I don't feel it. Although I love my partner but I don't feel that connection anymore.	0.092	explore	2025-12-26 22:20:37.889939	\N	f	\N	\N
257	019b5cbd-c2ea-7008-a603-81498254b300	8	assistant	Thank you for sharing that with me. I hear you it sounds like your love for your partner is still there, but the lack of connection is causing you to feel adrift. That can be such a painful dilemma to navigate loving someone yet feeling something vital is missing. Its understandable to yearn for that deeper emotional bond.	\N	\N	2025-12-26 22:20:42.373554	4496	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "How to find Peace in 9-5 Job without quitting", "topic": "peace", "youtube_url": "https://youtu.be/nstljfm6rlg"}, {"source": "When Marriage Does Not Feel Like Love Anymore", "topic": "marriage", "youtube_url": "https://www.youtube.com/watch?v=-20CzbY0rMA"}]
258	019b5cbd-c2ea-7008-a603-81498254b300	9	user	Can you hear me?	0.07	explore	2025-12-26 22:21:22.748883	\N	f	\N	\N
259	019b5cbd-c2ea-7008-a603-81498254b300	9	assistant	Yes, I can hear you, and I'm here with you. Your feelings are important, and I'm glad you're sharing them. What do you think might help you delve deeper into how this disconnect is affecting you and your relationship?	\N	\N	2025-12-26 22:21:25.989112	3265	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}, {"source": "How to find Peace in 9-5 Job without quitting", "topic": "peace", "youtube_url": "https://youtu.be/nstljfm6rlg"}]
260	019b5cbd-c2ea-7008-a603-81498254b300	10	user	How would I know? That's why I'm asking you.	0.06	explore	2025-12-26 22:21:40.280243	\N	f	\N	\N
261	019b5cbd-c2ea-7008-a603-81498254b300	11	user	How would I know? That's why I'm asking you. Help me.	0.31	transition	2025-12-26 22:21:41.529212	\N	f	\N	\N
262	019b5cbd-c2ea-7008-a603-81498254b300	11	assistant	I can sense how confused and uncertain this must feel for you, and I want to thank you for reaching out and expressing that. It takes a lot of courage to seek clarity in moments like this. Based on what you've shared, it seems like you have a strong desire for that emotional connection. I'm wondering what specifically that connection looks like for you, or how you could communicate that to your partner when you're ready.	\N	\N	2025-12-26 22:21:44.552318	4286	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}]
263	019b5cbd-c2ea-7008-a603-81498254b300	11	assistant	I truly appreciate you sharing your feelings with me. Given what you've told me about longing for a deeper emotional connection, I sense it could be valuable to explore what that connection looks like for you. What do you think your ideal relationship would feel like if those emotional needs were met? Would it be helpful to talk through what aspects you feel are lacking with your partner?	\N	\N	2025-12-26 22:21:45.739648	4210	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}]
264	019b5cbd-c2ea-7008-a603-81498254b300	12	user	Yes. There is no emotional connection.	0.133	explore	2025-12-26 22:22:13.294009	\N	f	\N	\N
265	019b5cbd-c2ea-7008-a603-81498254b300	13	user	Yes. There is no emotional connection. Uh, I feel	0.133	explore	2025-12-26 22:22:16.369881	\N	f	\N	\N
266	019b5cbd-c2ea-7008-a603-81498254b300	13	assistant	Thank you for your honesty in sharing that. It sounds like the absence of an emotional connection is deeply impacting your sense of fulfillment in the relationship. This realization is significant. What do you think might help you explore what factors may have contributed to this feeling? Or perhaps discuss how you envision nurturing that connection moving forward?	\N	\N	2025-12-26 22:22:17.471767	4213	f	\N	[{"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}]
267	019b5cbd-c2ea-7008-a603-81498254b300	13	assistant	I can sense how heavy that feeling of lacking emotional connection is for you. It sounds like it's a part of your experience in the relationship, and I appreciate your openness in sharing this. What do you think is at the core of that feeling? Are there specific moments or interactions that highlight this lack of connection for you?	\N	\N	2025-12-26 22:22:19.760377	3419	f	\N	[{"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Relationship Healing Course Session 1", "topic": "relationship", "youtube_url": null}]
268	019b5cbd-c2ea-7008-a603-81498254b300	14	user	Yes. There is no emotional connection. Uh, I feel We both operate very differently.	0.133	explore	2025-12-26 22:22:20.373054	\N	f	\N	\N
269	019b5cbd-c2ea-7008-a603-81498254b300	14	assistant	I hear you, and it's understandable to feel that way when you and your partner are operating on different wavelengths. It can create a sense of disconnect and confusion about how to bridge that gap. Would you like to share more about how these differences show up for you? Are there specific ways in which you feel you and your partner communicate or connect differently?	\N	\N	2025-12-26 22:22:24.094424	3719	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Course Session 1", "topic": "relationship", "youtube_url": null}]
270	019b5cbd-c2ea-7008-a603-81498254b300	15	user	Yes. There is no emotional connection. Uh, I feel We both operate very differently. and I don't know. I feel disconnected.	0.532	guide	2025-12-26 22:22:26.221522	\N	f	\N	\N
271	019b5cbd-c2ea-7008-a603-81498254b300	15	assistant	It's really powerful that you're expressing how disconnected you feel, especially in the context of operating differently. That sense of disconnection can be isolating, even if you still love your partner. When you say you operate differently, I wonder what specific things come to mind for you. Are there particular areas where you sense those differences are most pronounced?	\N	\N	2025-12-26 22:22:30.301239	4079	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}]
272	019b5cbd-c2ea-7008-a603-81498254b300	16	user	It's everything.	0.09	explore	2025-12-26 22:22:55.728609	\N	f	\N	\N
273	019b5cbd-c2ea-7008-a603-81498254b300	17	user	It's everything. Everything.	0.09	explore	2025-12-26 22:22:57.319114	\N	f	\N	\N
274	019b5cbd-c2ea-7008-a603-81498254b300	17	assistant	That must feel overwhelming, carrying the weight of disconnection in every aspect of your relationship. I hear you it can be challenging to feel stuck when it seems like everything feels off. Thank you for being so open about this. If you're comfortable, what do you think might have contributed to feeling this way? Have there been any significant moments that stand out for you?	\N	\N	2025-12-26 22:23:01.011417	3707	f	\N	[{"source": "Relationship Healing Course Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}]
275	019b5cbd-c2ea-7008-a603-81498254b300	18	user	It's everything. Everything. I think I'm just managing this relationship. There is nothing else.	0.08	explore	2025-12-26 22:23:01.627972	\N	f	\N	\N
276	019b5cbd-c2ea-7008-a603-81498254b300	18	assistant	That sounds incredibly overwhelming, and I appreciate your strength in sharing that everything feels different. It sounds tough to navigate a relationship where so many aspects feel misaligned. Would you feel comfortable exploring if there are any specific moments or patterns that stand out for you when you think about this disconnection? What do you feel is at stake for you in this situation?	\N	\N	2025-12-26 22:23:03.12275	7386	f	\N	[{"source": "Relationship Healing Course Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}]
277	019b5cbd-c2ea-7008-a603-81498254b300	18	assistant	I can sense how heavy that feeling of just managing the relationship is for you. It sounds like you're carrying a lot, and that can feel exhausting. Experiencing a relationship as something you're merely managing, rather than enjoying, can be a significant realization. What do you think this managing approach is costing you emotionally? If you could envision a different dynamic, what would that look like for you?	\N	\N	2025-12-26 22:23:06.271384	4647	f	\N	[{"source": "Relationship Healing Course Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}]
278	019b5cbd-c2ea-7008-a603-81498254b300	19	user	What do you mean?	0.09	explore	2025-12-26 22:23:31.644365	\N	f	\N	\N
279	019b5cbd-c2ea-7008-a603-81498254b300	19	assistant	I appreciate you asking for clarity. What I'm curious about is how this way of managing the relationship impacts your feelings and well-being. I hear you that its understandable to feel drained when youre in that mode. If you could imagine a different, more fulfilling dynamic with your partner, how might that look or feel? What do you think you would want to experience instead?	\N	\N	2025-12-26 22:23:35.719214	4087	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}]
280	019b5cbd-c2ea-7008-a603-81498254b300	20	user	I have never experienced it, so how should I tell you how it feel feel? I don't know.	0.48	guide	2025-12-26 22:24:02.177853	\N	f	\N	\N
281	019b5cbd-c2ea-7008-a603-81498254b300	20	assistant	Thank you for sharing that. I hear you it can feel disheartening to think about something you've never experienced, especially when you're longing for emotional connection. It's okay not to have a clear picture of what that looks like sometimes it can be hard to imagine something different when you're in a situation that feels so stagnant. I'm here to help you explore this.	\N	\N	2025-12-26 22:24:06.448613	4273	f	\N	[{"source": "Relationship Healing Course Session 1", "topic": "relationship", "youtube_url": null}, {"source": "How to find Peace in 9-5 Job without quitting", "topic": "peace", "youtube_url": "https://youtu.be/nstljfm6rlg"}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}]
282	019b5cbd-c2ea-7008-a603-81498254b300	21	user	Can you give me solution or tell me what's going on?	0.08	explore	2025-12-26 22:24:30.835854	\N	f	\N	\N
283	019b5cbd-c2ea-7008-a603-81498254b300	21	assistant	I truly appreciate your openness and your desire to find clarity in this situation. While I can't provide specific solutions or tell you exactly what's going on, I can support you in exploring these feelings more deeply. It sounds like you're ready to understand what steps might be possible moving forward. What do you think might resonate with your experiences and feelings?	\N	\N	2025-12-26 22:24:34.402243	3553	f	\N	[{"source": "How to find Peace in 9-5 Job without quitting", "topic": "peace", "youtube_url": "https://youtu.be/nstljfm6rlg"}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}]
284	019b5cbd-c2ea-7008-a603-81498254b300	22	user	Can you give me solution or tell me what's going on? What is the problem rather than preaching me by these stupid words?	0.133	explore	2025-12-26 22:24:38.667718	\N	f	\N	\N
285	019b5cbd-c2ea-7008-a603-81498254b300	22	assistant	I can sense your frustration, and I appreciate your honesty. It sounds like you're seeking clarity and answers, especially since this situation is weighing heavily on you. Based on everything you've shared with me, I wonder if it might help to explore some thoughts together. Would you be open to that?	\N	\N	2025-12-26 22:24:42.345632	3711	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "Watch this if you feel exhausted", "topic": "exhaustion", "youtube_url": "https://www.youtube.com/watch?v=GJbYokkNQyg"}]
286	019b5cbd-c2ea-7008-a603-81498254b300	23	user	Yes.	0.14	explore	2025-12-26 22:24:59.683476	\N	f	\N	\N
287	019b5cbd-c2ea-7008-a603-81498254b300	23	assistant	Thank you for being open to exploring this further. From what you've shared, I hear you saying that the primary issue is the deep disconnection in your relationship, where you both feel fundamentally different and its become more about managing than enjoying each other's company. One perspective to consider is that sometimes, these feelings of disconnection can stem from unmet needs or a lack of shared experiences. Reflecting on what you both value or what brought you together initially might reveal some insights.	\N	\N	2025-12-26 22:25:04.25633	4565	f	\N	[{"source": "Career Healing - Elevate 360 Session 1", "topic": "career", "youtube_url": null}, {"source": "1:1 Session - Career Transition & Goal Setting", "topic": "career", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
288	019b5cbd-c2ea-7008-a603-81498254b300	24	user	Yes. Yes.	0.11	explore	2025-12-26 22:25:05.303157	\N	f	\N	\N
289	019b5cbd-c2ea-7008-a603-81498254b300	24	assistant	I'm glad that resonates with you. It sounds like there might be a sense of hope in beginning to explore what brought you and your partner together in the first place. Would it feel helpful to think about what specific needs or desires you have in the relationship? And perhaps what steps you might take to begin bridging the gap?	\N	\N	2025-12-26 22:25:08.70725	3406	f	\N	[{"source": "Career Healing - Elevate 360 Session 1", "topic": "career", "youtube_url": null}, {"source": "1:1 Session - Career Transition & Goal Setting", "topic": "career", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
290	019b5cbd-c2ea-7008-a603-81498254b300	25	user	I want a a relationship where communication is open, where I'm feeling heard, where I'm feeling seen, and where I'm feeling respected.	0.08	explore	2025-12-26 22:25:43.897251	\N	f	\N	\N
291	019b5cbd-c2ea-7008-a603-81498254b300	25	assistant	Those desires are absolutely valid, and its important to feel heard, seen, and respected in a relationship . I sense that those foundational elements are essential for you to feel emotionally connected. Thank you for articulating that. Would you be open to exploring how you might express these needs to your partner? Sometimes, finding a way to communicate what youre longing for can open up new avenues for connection.	\N	\N	2025-12-26 22:25:47.798858	3950	f	\N	[{"source": "Relationship Healing Course Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}]
292	019b5cbd-c2ea-7008-a603-81498254b300	26	user	If the other person is not in mode of hearing and they just react and they just get angry whenever you put your need.	0.08	explore	2025-12-26 22:26:23.3965	\N	f	\N	\N
293	019b5cbd-c2ea-7008-a603-81498254b300	26	assistant	That sounds incredibly tough, especially when you're trying to express your needs and the response is anger instead of understanding. It can be so disheartening when the very act of sharing gets met with resistance. I sense that this pattern must feel exhausting, and it's completely understandable to feel stuck in that dynamic. Would you like to explore ways to approach this conversation differently, or perhaps reflect on how it affects you personally?	\N	\N	2025-12-26 22:26:27.147374	3774	f	\N	[{"source": "Relationship Healing Course Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}]
294	019b5cbd-c2ea-7008-a603-81498254b300	27	user	No. It's it's hardening. That's why I'm asking you. Can you stop giving me assurance and give me solution?	0.08	explore	2025-12-26 22:26:47.448757	\N	f	\N	\N
295	019b5cbd-c2ea-7008-a603-81498254b300	27	assistant	I appreciate your patience and your candid feedback. It sounds like youre looking for deeper insights rather than just reassurance, and I'm here to assist in that journey. Based on what you've shared, when the communication isn't open and is met with anger, it can create an ongoing cycle of disconnection and hurt. What do you think might help in finding a moment when your partner may be more open to having a calm conversation, perhaps by expressing your feelings without placing blame? Would you be interested in discussing strategies for approaching that conversation to help facilitate better communication?	\N	\N	2025-12-26 22:26:51.711642	4257	f	\N	[{"source": "Relationship Healing Course Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}]
296	019b5cbd-c2ea-7008-a603-81498254b300	28	user	Yes. But he's never in mood of listening. Even when if if he's calm and I bring my needs up, he gets angry.	0.08	explore	2025-12-26 22:27:40.374879	\N	f	\N	\N
297	019b5cbd-c2ea-7008-a603-81498254b300	28	assistant	That situation sounds incredibly frustrating and disheartening to navigate, especially when it feels like your partner isn't receptive to your needs. I hear you it can be tough to feel stuck in a cycle where any attempt to express yourself meets with anger. Would it be helpful to brainstorm some different ways to bring up your feelings or needs, perhaps using I statements to express how you feel without sounding confrontational? This can sometimes help create a softer entry for those difficult conversations. What do you think might help in this situation?	\N	\N	2025-12-26 22:27:44.90196	4559	f	\N	[{"source": "Relationship Healing Course Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}]
298	019b5cbd-c2ea-7008-a603-81498254b300	29	user	Yes. But he's never in mood of listening. Even when if if he's calm and I bring my needs up, he gets angry. There is no moment where he is calm.	0.133	explore	2025-12-26 22:27:46.412395	\N	f	\N	\N
299	019b5cbd-c2ea-7008-a603-81498254b300	29	assistant	That sounds really challenging, especially when it feels like there's never a good time to express your feelings without triggering that anger. I hear you it must be tiring to feel like there's no safe space for your needs to be heard. Would you be open to exploring some strategies for self-care or ways to express your feelings when it feels safe for you, even if it's not received in the way you hope? What do you think might help you focus on your own well-being in this difficult dynamic? That could provide some clarity on what to do next.	\N	\N	2025-12-26 22:27:50.899352	4505	f	\N	[{"source": "Relationship Healing Course Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 1", "topic": "wellness", "youtube_url": null}]
300	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	1	user	Hi.	0.03	explore	2025-12-26 22:29:19.763908	\N	f	\N	\N
301	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	2	user	Hi. I'm feeling very disconnected from my partner. What should I do?	0.15	explore	2025-12-26 22:29:22.907528	\N	f	\N	\N
302	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	2	assistant	I hear you, and Im glad you reached out . How are you feeling today? It sounds like you might have something on your mind that youd like to share.	\N	\N	2025-12-26 22:29:26.365563	9015	f	\N	[{"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}, {"source": "Career Healing - Elevate 360 Session 1", "topic": "career", "youtube_url": null}, {"source": "Relationship Healing Course Session 1", "topic": "relationship", "youtube_url": null}]
303	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	2	assistant	Thank you for sharing that with me. It sounds like you're carrying a lot of weight around this disconnection, and I can sense how much that affects you. Based on what you've described, here are some perspectives that might resonate First, it's important to acknowledge that feelings of disconnection often arise when parts of us feel hidden or unexpressed. What do you think might help you explore where you might not be being honest about your true feelings? Reflecting on this can help you understand what prompts the disconnect.	\N	\N	2025-12-26 22:29:30.206132	7267	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}]
304	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	3	user	How to find out if I'm not being true to my own feelings.	0	explore	2025-12-26 22:30:05.277854	\N	f	\N	\N
305	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	3	assistant	I hear you it can be really challenging to navigate those feelings, especially when they involve being true to yourself and your emotions . I'm curious, is there a specific moment or situation in your relationship where you felt that disconnection more acutely? Sometimes reflecting on those moments can help us uncover the layers of our feelings. What do you think might help you share more about those experiences?	\N	\N	2025-12-26 22:30:09.418804	4167	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}]
306	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	4	user	Especially when I put my needs, like, uh, whenever I need something, I feel that disconnection. Whenever I'm giving, giving, and giving, it's absolutely fine.	0	explore	2025-12-26 22:30:48.178728	\N	f	\N	\N
307	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	4	assistant	That sounds really heavy to carry. It seems like you've identified a pattern where your true needs might take a back seat to the giving. I hear you on how frustrating that must feel when you're showing up for others but not feeling fully supported in return . I'm curious when you think about your needs and the moments you feel that disconnect, what emotions come up for you? Have you noticed any specific triggers or thoughts that make it harder for you to voice those needs?	\N	\N	2025-12-26 22:30:52.510339	4374	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}]
308	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	5	user	I feel lonely. I feel unheard, and I feel what's the point of living.	0.02	explore	2025-12-26 22:31:28.644029	\N	f	\N	\N
309	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	5	assistant	I'm truly sorry to hear that you're feeling this way. It sounds incredibly painful to carry those feelings of loneliness and being unheard. You're not alone in this experiencemany people go through moments when they feel disconnected from others, even those close to them. Thank you for opening up and sharing this with me.	\N	\N	2025-12-26 22:31:34.695599	6068	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "1:1 Discovery Call - Health & Relationships", "topic": "relationship", "youtube_url": null}]
310	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	6	user	So what should I do now?	0.385	guide	2025-12-26 22:32:00.845018	\N	f	\N	\N
311	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	6	assistant	Thank you for sharing that with me. Based on what you've described, here are some perspectives that might resonate First, I hear you in your feelings of loneliness and disconnection. Understanding that these emotions are signals from your inner self can help you reflect on what you truly need. Second, what do you think might help you explore where you feel you're not being honest with yourself? Ask yourself questions like "Where have I been craving connection but hiding parts of me to stay safe?" This reflective practice can help you uncover deeper needs and desires.	\N	\N	2025-12-26 22:32:06.010288	5226	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}]
312	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	7	user	I'm really confused. What do you want me to do?	0.29	transition	2025-12-26 22:32:46.969998	\N	f	\N	\N
313	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	7	assistant	I appreciate your honesty, and I can sense how overwhelming this must feel right now. Its completely okay to feel confused, especially when navigating complex emotions like loneliness and disconnection. Based on everything you've shared, I wonder if it might help to explore your feelings further. Would you be open to diving deeper into what specific connections or interactions might be missing for you? This exploration can bring clarity.	\N	\N	2025-12-26 22:32:52.156485	5211	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}]
314	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	8	user	I'm not confused about my emotion. I'm confused about what do you want me to do.	0.492	guide	2025-12-26 22:33:11.897463	\N	f	\N	\N
315	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	8	assistant	Thank you for your patience as we navigate this together. I hear you, and I want to be clear and supportive. You've expressed deep feelings, and its important to honor that. Given what you've shared, it could be valuable to explore your emotional needs more directly.	\N	\N	2025-12-26 22:33:16.935222	5024	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Course Session 1", "topic": "relationship", "youtube_url": null}]
316	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	9	user	Okay. Do it.	0.09	explore	2025-12-26 22:33:36.078944	\N	f	\N	\N
317	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	10	user	Okay. Do it. Help me!	0.32	transition	2025-12-26 22:33:37.654574	\N	f	\N	\N
318	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	10	assistant	Thank you for your openness. It sounds like you're ready to explore this further, which is a great step. One approach to consider is to identify three top emotional needs that you have in your relationship. These are the core aspects that make you feel safe, fulfilled, and connected.	\N	\N	2025-12-26 22:33:40.416222	4358	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}, {"source": "1:1 Session - Career Transition & Goal Setting", "topic": "career", "youtube_url": null}]
319	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	10	assistant	Thank you for your willingness to explore this further. Based on everything you've shared, I'm sensing there might be some valuable insights to discuss. Would you be open to talking about your top emotional needs in your relationship? Identifying what you truly need can help clarify your next steps. What do you think are the three emotional needs that feel most important to you in your relationship right now?	\N	\N	2025-12-26 22:33:41.345187	3687	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}]
320	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	11	user	Yes.	0.14	explore	2025-12-26 22:34:01.334902	\N	f	\N	\N
321	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	11	assistant	I appreciate your response! Let's take a moment to reflect together. What are the three emotional needs that you feel are most important for you in your relationship? Identifying these can help illuminate what changes or conversations might be necessary. And I hear youthere's no right or wrong answerjust your feelings and needs.	\N	\N	2025-12-26 22:34:04.624314	3309	f	\N	[{"source": "1:1 Session - Career Transition & Goal Setting", "topic": "career", "youtube_url": null}, {"source": "1-to-1 Educational Concepts - power_patterns", "topic": "career", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
322	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	12	user	My top three needs are: Number one, communication number two, emotional bonding number three,	0.08	explore	2025-12-26 22:34:37.02199	\N	f	\N	\N
323	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	13	user	My top three needs are: Number one, communication number two, emotional bonding number three, respect.	0.08	explore	2025-12-26 22:34:38.776889	\N	f	\N	\N
324	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	13	assistant	Thank you for sharing those important needs. It sounds like communication and emotional bonding are fundamental to you feeling connected in your relationship. I hear you that you're still thinking about the third one. What do you feel is the third emotional need that you want to bring into your relationship? Its okay to take your time with thisits a meaningful exploration.	\N	\N	2025-12-26 22:34:40.892282	3885	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
325	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	13	assistant	Thank you for sharing those important needs communication, emotional bonding, and respect. I hear you it's clear these are vital to you feeling connected and fulfilled in your relationship. Recognizing these needs is a step toward understanding how to foster deeper connections. Would you feel comfortable exploring how you might express or communicate these needs to your partner? What do you think could be the first step in initiating that conversation?	\N	\N	2025-12-26 22:34:42.736285	3944	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}]
326	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	14	user	I don't know.	0.54	guide	2025-12-26 22:35:12.521782	\N	f	\N	\N
327	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	14	assistant	That's completely okay. It's a big step to consider how to communicate your needs, especially when they feel so important. I sense that starting by reflecting on what you hope to achieve in that conversation could be helpful. What do you think might be your ideal outcome how do you envision feeling once these needs are acknowledged and respected? Exploring that could guide you in finding the right words when you're ready to share with your partner.	\N	\N	2025-12-26 22:35:16.131843	3643	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}]
328	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	15	user	feeling need... needed, feeling seen, heard. That's what I want.	0.08	explore	2025-12-26 22:35:48.497838	\N	f	\N	\N
329	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	15	assistant	Thank you for sharing that. Feeling needed, seen, and heard is so fundamental to our sense of connection and belonging. I can sense how important it is for you to express those feelings in your relationship. What do you think might help you feel that way more often? Would it help to think about specific moments or actions from your partner that make you feel valued and appreciated? Recognizing those can make it easier to communicate what you need moving forward.	\N	\N	2025-12-26 22:35:52.303888	3830	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}]
330	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	16	user	So confused. You have so big, big questions and suggestions. I don't know what I have to do.	0.83	guide	2025-12-26 22:36:31.202168	\N	f	\N	\N
331	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	16	assistant	I truly appreciate your honesty, and I can see how this may feel overwhelming. It's okay to feel that way when digging into such important aspects of your life. Let's simplify things together. Rather than focusing on big questions, what if we start with just one small step? Would you be open to thinking about a specific moment where you felt seen and heard in your relationship? It sounds like anchoring the conversation to something tangible could be helpful.	\N	\N	2025-12-26 22:36:35.574334	4386	f	\N	[{"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}]
332	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	17	user	Yes. I'm open. That's why I'm talking to you.	0.08	explore	2025-12-26 22:36:54.948701	\N	f	\N	\N
333	019b5cc7-ac14-7ff0-94b3-39dd58e72cda	17	assistant	I appreciate your opennessit really matters. Let's take a moment to think about a specific memory or instance in your relationship where you felt truly seen and heard. What was happening in that moment that made you feel that way? This might help us focus on what you value and what you could communicate to your partner to create more of those meaningful experiences.	\N	\N	2025-12-26 22:36:58.384657	3445	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
334	019b5d53-e0a6-788a-a0e7-c46aaadff876	1	user	I I don't know. I'm feeling lonely these days.	0.3	transition	2025-12-27 01:02:31.221092	\N	f	\N	\N
335	019b5d53-e0a6-788a-a0e7-c46aaadff876	1	assistant	I hear you, and that feeling of loneliness can be so heavy to carry . Its really important to acknowledge how youre feeling. What do you think might help you in this situation? Would you be open to sharing a bit more about what youve been experiencing?	\N	\N	2025-12-27 01:02:34.190459	2975	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}]
336	019b5d53-e0a6-788a-a0e7-c46aaadff876	2	user	Yes. That's very good question. That's the problem. I'm not able to analyze what I'm going through and why I have started feeling like this. Can you assist?	0	explore	2025-12-27 01:03:00.693526	\N	f	\N	\N
337	019b5d53-e0a6-788a-a0e7-c46aaadff876	2	assistant	I can sense how confusing and overwhelming that must feel for you. Its tough when emotions seem tangled. What do you think might help to talk about when you first started noticing these feelings of loneliness?	\N	\N	2025-12-27 01:03:03.414144	2733	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "How to find Peace in 9-5 Job without quitting", "topic": "peace", "youtube_url": "https://youtu.be/nstljfm6rlg"}]
338	019b5d53-e0a6-788a-a0e7-c46aaadff876	3	user	I don't know. I feel that I'm not being appreciated, and I'm not being included, uh, in activities that people do.	0.3	transition	2025-12-27 01:03:28.179535	\N	f	\N	\N
339	019b5d53-e0a6-788a-a0e7-c46aaadff876	3	assistant	That sense of not being appreciated can really deepen those feelings of loneliness. It sounds like you're longing for connection and acknowledgment from others. I'm curious, when you reflect on those moments where you feel left out, what emotions do you notice coming up for you?	\N	\N	2025-12-27 01:03:31.532565	3312	f	\N	[{"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}, {"source": "How to find Peace in 9-5 Job without quitting", "topic": "peace", "youtube_url": "https://youtu.be/nstljfm6rlg"}]
340	019b5d53-e0a6-788a-a0e7-c46aaadff876	4	user	I don't know. I feel that I'm not being appreciated, and I'm not being included, uh, in activities that people do. and that is where I'm a little bit confused. Maybe you can help me to figure out my confusion.	0.9	guide	2025-12-27 01:03:32.742885	\N	f	\N	\N
341	019b5d53-e0a6-788a-a0e7-c46aaadff876	4	assistant	It sounds like you're feeling a mix of emotions around this lack of appreciation and connection. I can sense that confusion can add another layer to those feelings. Would you like to explore if there are specific moments or interactions that stand out to you as particularly impactful in feeling this way?	\N	\N	2025-12-27 01:03:35.755705	3006	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}, {"source": "How to find Peace in 9-5 Job without quitting", "topic": "peace", "youtube_url": "https://youtu.be/nstljfm6rlg"}]
342	019b5d53-e0a6-788a-a0e7-c46aaadff876	5	user	Yes. What do you want to know?	0.02	explore	2025-12-27 01:04:02.386409	\N	f	\N	\N
343	019b5d53-e0a6-788a-a0e7-c46aaadff876	5	assistant	I'm curious about any recent experiences where you felt particularly excluded or unappreciated. What happened in those moments, and how did they make you feel?	\N	\N	2025-12-27 01:04:04.523809	2170	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}, {"source": "Do you feel lonely among your loved ones?", "topic": "loneliness", "youtube_url": "https://www.youtube.com/watch?v=RRAi4UBLAsM"}]
344	019b5d53-e0a6-788a-a0e7-c46aaadff876	6	user	I can think couple of moments like, you know, when I was in this meeting and... I mean, not a meeting. It was a kind of a family get together, and I was not being appreciated. And maybe it's just in my mind. I don't know. Maybe I'm overthinking. That is where I need your help.	0.44	guide	2025-12-27 01:04:39.578383	\N	f	\N	\N
345	019b5d53-e0a6-788a-a0e7-c46aaadff876	6	assistant	It sounds like that family get-together really brought up some strong feelings for you. Feeling unappreciated in front of loved ones can be really disheartening. When you think about those moments and the feelings that come up, I'm curious if any past experiences come to mind that might resonate with this pattern?	\N	\N	2025-12-27 01:04:42.546571	2958	f	\N	[{"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "How to find Peace in 9-5 Job without quitting", "topic": "peace", "youtube_url": "https://youtu.be/nstljfm6rlg"}]
346	019b5d53-e0a6-788a-a0e7-c46aaadff876	7	user	Uh, no past experiences, but what I want your help is can you give me certain steps or something to help me assess my situation, maybe be able to figure out what is going on with me?	0.9	guide	2025-12-27 01:05:16.532565	\N	f	\N	\N
347	019b5d53-e0a6-788a-a0e7-c46aaadff876	7	assistant	I really appreciate you opening up about your feelings. It sounds like you're looking for some clarity around your situation. Based on what you've shared, I'm wondering if you would like to explore some reflections together. Would you be open to that?	\N	\N	2025-12-27 01:05:19.159644	2631	f	\N	[{"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "Relationship Healing Course Session 1", "topic": "relationship", "youtube_url": null}]
348	019b5d53-e0a6-788a-a0e7-c46aaadff876	8	user	Yes. I'm open to everything, but I want your help. Maybe you can give me certain steps which I can go through to analyze what's going on with me.	0.9	guide	2025-12-27 01:05:45.641299	\N	f	\N	\N
349	019b5d53-e0a6-788a-a0e7-c46aaadff876	8	assistant	Thank you for your openness. It sounds like you're at a point where you're ready to understand more about your feelings. Based on everything you've shared with me, I sense there may be value in exploring some thoughts together. Would you be open to that?	\N	\N	2025-12-27 01:05:48.605632	2975	f	\N	[{"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "How to find Peace in 9-5 Job without quitting", "topic": "peace", "youtube_url": "https://youtu.be/nstljfm6rlg"}]
350	019b5d53-e0a6-788a-a0e7-c46aaadff876	9	user	Yes. I'm open to everything. What do you suggest?	0.112	explore	2025-12-27 01:06:07.804347	\N	f	\N	\N
351	019b5d53-e0a6-788a-a0e7-c46aaadff876	9	assistant	It sounds like reflecting on your emotional needs could be a valuable step for you. Taking a moment to consider what makes you feel appreciated and included could provide some clarity. What do you think about identifying three feelings or needs that are important to you in your relationships? Would you like to try that?	\N	\N	2025-12-27 01:06:10.636611	2837	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
352	019b5d53-e0a6-788a-a0e7-c46aaadff876	10	user	Three feelings. Uh, one is, uh, being appreciated. Second is, uh, show me that I'm needed. And third is, uh, include me... try to include me in whatever best way it's possible. Does that answer your question?	0.08	explore	2025-12-27 01:06:52.130565	\N	f	\N	\N
353	019b5d53-e0a6-788a-a0e7-c46aaadff876	10	assistant	That's a wonderful start! Youve identified some important emotional needs feeling appreciated, needed, and included. Recognizing these can help you understand what youre longing for in your connections. How do you think you could express these needs to those around you?	\N	\N	2025-12-27 01:06:55.067552	2979	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}]
354	019b5d53-e0a6-788a-a0e7-c46aaadff876	11	user	I don't know. You tell me. Can you give me certain pointers, um, how to express these feelings?	0.48	guide	2025-12-27 01:07:19.005477	\N	f	\N	\N
355	019b5d53-e0a6-788a-a0e7-c46aaadff876	11	assistant	I sense that expressing these feelings can feel daunting, and it's okay to seek guidance on that. A gentle approach might be to start with sharing specific moments when you felt unappreciated and then communicate how it made you feel. What do you think might help you feel comfortable sharing one of those experiences in a conversation with someone close to you?	\N	\N	2025-12-27 01:07:22.039648	3008	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}]
356	019b5d53-e0a6-788a-a0e7-c46aaadff876	12	user	I don't know. That is where I need your guidance.	0.48	guide	2025-12-27 01:07:50.091278	\N	f	\N	\N
357	019b5d53-e0a6-788a-a0e7-c46aaadff876	12	assistant	It sounds like you're really seeking some clarity on how to move forward. Based on everything you've shared, a thoughtful way to start might be to pick one of your feelingslike feeling unappreciatedand think about a specific moment you could describe to someone. What do you think might help you explore how that conversation might feel for you?	\N	\N	2025-12-27 01:07:53.12748	3039	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}]
358	019b5d53-e0a6-788a-a0e7-c46aaadff876	13	user	I do not have answer to that. Your suggestions?	0.133	explore	2025-12-27 01:08:19.934525	\N	f	\N	\N
359	019b5d53-e0a6-788a-a0e7-c46aaadff876	13	assistant	I understand you're feeling a bit stuck, and that's okay. This process can take time. It might help to start by writing down a specific instance where you felt unappreciated. Then, consider how you would like to express that feeling to the person involved.	\N	\N	2025-12-27 01:08:23.386539	3399	f	\N	[{"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "1:1 Session - Soul Purpose & Fear Work", "topic": "wellness", "youtube_url": null}]
360	019b5d53-e0a6-788a-a0e7-c46aaadff876	14	user	Okay. So you want me to write those, uh, feelings? And after I've written those feelings, what do you want me to do then?	0.08	explore	2025-12-27 01:08:46.704895	\N	f	\N	\N
361	019b5d53-e0a6-788a-a0e7-c46aaadff876	14	assistant	After writing down those feelings, try to reflect on how those moments affected you and what you need moving forward. You might consider how to open a conversation with someone close to you, sharing your feelings and experiences. Would you feel comfortable trying that?	\N	\N	2025-12-27 01:08:49.242971	2547	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}, {"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}]
362	019b5d53-e0a6-788a-a0e7-c46aaadff876	15	user	Yes. I'm comfortable. That is where I need your guidance. What do you suggest here I need to do?	0.432	guide	2025-12-27 01:09:11.436562	\N	f	\N	\N
363	019b5d53-e0a6-788a-a0e7-c46aaadff876	15	assistant	I'm glad to hear you're feeling comfortable! When you're ready to have that conversation, start by expressing your feelings using "I" statements, like "I feel unappreciated when..." This approach helps convey your emotions without sounding accusatory. What do you think might help you express your feelings?	\N	\N	2025-12-27 01:09:14.779286	3369	f	\N	[{"source": "Health Healing - Elevate 360 Session 2", "topic": "wellness", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}]
364	019b5d53-e0a6-788a-a0e7-c46aaadff876	16	user	You're asking too much of questions. Uh, I'm getting confused. I... can you give me a straight answer, like, uh, concrete, uh, steps that I should follow?	0.78	guide	2025-12-27 01:09:49.151139	\N	f	\N	\N
365	019b5d53-e0a6-788a-a0e7-c46aaadff876	16	assistant	I hear you, and I appreciate your honesty. Since it sounds like you're looking for more concrete guidance, lets summarize a simple approach Write down your feelings Focus on those three feelings we discussed. Choose a specific moment Identify one situation where you felt unappreciated. Craft your message Use "I" statements to express your feelings clearly.	\N	\N	2025-12-27 01:09:53.404442	4285	f	\N	[{"source": "Relationship Healing Elevate 360 Session 1", "topic": "relationship", "youtube_url": null}, {"source": "Relationship Healing Elevate 360 Session 2", "topic": "relationship", "youtube_url": null}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
366	019b5d53-e0a6-788a-a0e7-c46aaadff876	17	user	Okay. Thank you. I will be doing that. And let me do that, and I'll get back to you. That should be all for now.	0.08	explore	2025-12-27 01:10:22.423644	\N	f	\N	\N
367	019b5d53-e0a6-788a-a0e7-c46aaadff876	17	assistant	You're welcome! I'm glad we could explore this together. I'm here whenever you want to share or discuss more. Wishing you all the best as you reflect.	\N	\N	2025-12-27 01:10:25.190659	2836	f	\N	[{"source": "Career Healing - Elevate 360 Session 1", "topic": "career", "youtube_url": null}, {"source": "Watch this if you feel exhausted", "topic": "exhaustion", "youtube_url": "https://www.youtube.com/watch?v=GJbYokkNQyg"}, {"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}]
368	019b5d53-e0a6-788a-a0e7-c46aaadff876	18	user	Thank you. Bye bye.	0.143	explore	2025-12-27 01:10:37.154356	\N	f	\N	\N
369	019b5d53-e0a6-788a-a0e7-c46aaadff876	18	assistant	Take care! Bye!	\N	\N	2025-12-27 01:10:39.49589	2335	f	somera_farewell	[{"source": "Career Healing Course - Masterclass", "topic": "career", "youtube_url": null}, {"source": "Career Healing - Elevate 360 Session 2", "topic": "career", "youtube_url": null}]
\.


--
-- Name: replit_database_migrations_v1_id_seq; Type: SEQUENCE SET; Schema: _system; Owner: -
--

SELECT pg_catalog.setval('_system.replit_database_migrations_v1_id_seq', 4, true);


--
-- Name: analytics_daily_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.analytics_daily_id_seq', 1, false);


--
-- Name: backend_error_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.backend_error_logs_id_seq', 1, false);


--
-- Name: chat_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.chat_sessions_id_seq', 110, true);


--
-- Name: conversation_summaries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.conversation_summaries_id_seq', 1, true);


--
-- Name: conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.conversations_id_seq', 353, true);


--
-- Name: feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.feedback_id_seq', 1, false);


--
-- Name: flagged_conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.flagged_conversations_id_seq', 1, false);


--
-- Name: grest_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.grest_products_id_seq', 1, false);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.messages_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_id_seq', 1, false);


--
-- Name: response_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.response_feedback_id_seq', 2, true);


--
-- Name: user_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_accounts_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: voice_conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.voice_conversations_id_seq', 353, true);


--
-- Name: voice_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.voice_messages_id_seq', 369, true);


--
-- Name: replit_database_migrations_v1 replit_database_migrations_v1_pkey; Type: CONSTRAINT; Schema: _system; Owner: -
--

ALTER TABLE ONLY _system.replit_database_migrations_v1
    ADD CONSTRAINT replit_database_migrations_v1_pkey PRIMARY KEY (id);


--
-- Name: analytics_daily analytics_daily_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_daily
    ADD CONSTRAINT analytics_daily_pkey PRIMARY KEY (id);


--
-- Name: backend_error_logs backend_error_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backend_error_logs
    ADD CONSTRAINT backend_error_logs_pkey PRIMARY KEY (id);


--
-- Name: chat_sessions chat_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_pkey PRIMARY KEY (id);


--
-- Name: conversation_summaries conversation_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_summaries
    ADD CONSTRAINT conversation_summaries_pkey PRIMARY KEY (id);


--
-- Name: conversation_summaries conversation_summaries_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_summaries
    ADD CONSTRAINT conversation_summaries_user_id_key UNIQUE (user_id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: flagged_conversations flagged_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flagged_conversations
    ADD CONSTRAINT flagged_conversations_pkey PRIMARY KEY (id);


--
-- Name: grest_products grest_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grest_products
    ADD CONSTRAINT grest_products_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: response_feedback response_feedback_conversation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.response_feedback
    ADD CONSTRAINT response_feedback_conversation_id_key UNIQUE (conversation_id);


--
-- Name: response_feedback response_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.response_feedback
    ADD CONSTRAINT response_feedback_pkey PRIMARY KEY (id);


--
-- Name: user_accounts uq_channel_external_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_accounts
    ADD CONSTRAINT uq_channel_external_id UNIQUE (channel, external_id);


--
-- Name: user_accounts user_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_accounts
    ADD CONSTRAINT user_accounts_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: voice_conversations voice_conversations_call_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.voice_conversations
    ADD CONSTRAINT voice_conversations_call_id_unique UNIQUE (call_id);


--
-- Name: voice_conversations voice_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.voice_conversations
    ADD CONSTRAINT voice_conversations_pkey PRIMARY KEY (id);


--
-- Name: voice_messages voice_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.voice_messages
    ADD CONSTRAINT voice_messages_pkey PRIMARY KEY (id);


--
-- Name: idx_replit_database_migrations_v1_build_id; Type: INDEX; Schema: _system; Owner: -
--

CREATE UNIQUE INDEX idx_replit_database_migrations_v1_build_id ON _system.replit_database_migrations_v1 USING btree (build_id);


--
-- Name: idx_conversation_summaries_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversation_summaries_user_id ON public.conversation_summaries USING btree (user_id);


--
-- Name: idx_conversations_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversations_session ON public.conversations USING btree (session_id);


--
-- Name: idx_conversations_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversations_user ON public.conversations USING btree (user_id);


--
-- Name: idx_error_logs_call_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_error_logs_call_id ON public.backend_error_logs USING btree (call_id);


--
-- Name: idx_error_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_error_logs_created_at ON public.backend_error_logs USING btree (created_at DESC);


--
-- Name: idx_messages_conversation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_conversation ON public.messages USING btree (conversation_id);


--
-- Name: idx_products_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_category ON public.grest_products USING btree (category);


--
-- Name: idx_products_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_model ON public.products USING btree (model);


--
-- Name: idx_products_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_name ON public.products USING btree (product_name);


--
-- Name: idx_products_price; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_price ON public.grest_products USING btree (price);


--
-- Name: idx_voice_conversations_call_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_voice_conversations_call_id ON public.voice_conversations USING btree (call_id);


--
-- Name: idx_voice_messages_call_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_voice_messages_call_id ON public.voice_messages USING btree (call_id);


--
-- Name: ix_analytics_daily_date; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_analytics_daily_date ON public.analytics_daily USING btree (date);


--
-- Name: ix_analytics_daily_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_analytics_daily_id ON public.analytics_daily USING btree (id);


--
-- Name: ix_chat_sessions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_sessions_id ON public.chat_sessions USING btree (id);


--
-- Name: ix_chat_sessions_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_chat_sessions_session_id ON public.chat_sessions USING btree (session_id);


--
-- Name: ix_chat_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_sessions_user_id ON public.chat_sessions USING btree (user_id);


--
-- Name: ix_conversations_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_conversations_id ON public.conversations USING btree (id);


--
-- Name: ix_conversations_safety_flagged; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_conversations_safety_flagged ON public.conversations USING btree (safety_flagged);


--
-- Name: ix_conversations_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_conversations_session_id ON public.conversations USING btree (session_id);


--
-- Name: ix_conversations_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_conversations_timestamp ON public.conversations USING btree ("timestamp");


--
-- Name: ix_grest_products_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_grest_products_category ON public.grest_products USING btree (category);


--
-- Name: ix_grest_products_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_grest_products_id ON public.grest_products USING btree (id);


--
-- Name: ix_grest_products_in_stock; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_grest_products_in_stock ON public.grest_products USING btree (in_stock);


--
-- Name: ix_grest_products_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_grest_products_name ON public.grest_products USING btree (name);


--
-- Name: ix_grest_products_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_grest_products_sku ON public.grest_products USING btree (sku);


--
-- Name: ix_response_feedback_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_response_feedback_id ON public.response_feedback USING btree (id);


--
-- Name: ix_user_accounts_channel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_accounts_channel ON public.user_accounts USING btree (channel);


--
-- Name: ix_user_accounts_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_accounts_email ON public.user_accounts USING btree (email);


--
-- Name: ix_user_accounts_external_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_accounts_external_id ON public.user_accounts USING btree (external_id);


--
-- Name: chat_sessions chat_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.user_accounts(id);


--
-- Name: conversation_summaries conversation_summaries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_summaries
    ADD CONSTRAINT conversation_summaries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.user_accounts(id);


--
-- Name: conversations conversations_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(session_id);


--
-- Name: conversations conversations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: feedback feedback_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id);


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- Name: response_feedback response_feedback_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.response_feedback
    ADD CONSTRAINT response_feedback_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 5uzTSp3Me2U2z7FmzLCKz51Kd0gewDpnS9MlY813IMXxMSsIxTDYVfzZ9JorBxF

